Super Pickaxe! Add Custom Tools to Minecraft with Fabric
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/minecraft-custom-tool-mod.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Super Pickaxe! Add Custom Tools to Minecraft with Fabric

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Right-click the crystalmod package → New → Java Class. Name it ModToolMaterials. When prompted for type, choose Enum.
- Replace the entire file with:
- Open ModItems.java. Add these imports:
- Add the Crystal Pickaxe field below your other items:
- Add entries.add(CRYSTAL_PICKAXE); inside registerModItems().
- Cannot find symbol: PickaxeItem press Alt+Enter on the red word → Import → net.minecraft.item.PickaxeItem.
- createAttributeModifiers not found make sure you're using Fabric for Minecraft 1.21.1. Older tutorials use a different API.
- Cannot find symbol: ModToolMaterials check ModToolMaterials.java is in the same package and the file has no compile errors of its own first.
- Tool deals wrong damage in-game the attackDamage in createAttributeModifiers is a bonus on top of the tool's base. A pickaxe with +1 deals 1 + 4 (base) = 5 total.
- In ModItems.java, add the Crystal Sword below the pickaxe:
- Add entries.add(CRYSTAL_SWORD); inside registerModItems().

## Textures
- Use Pixel Studio to draw a 16✨16 pickaxe sprite. The classic pickaxe shape has a diagonal handle and a T-shaped head. Use cyan/blue crystal colours for the head and brown for the stick.
- Save as crystal_pickaxe.png in assets/crystalmod/textures/item/.
- Draw a sword sprite a diagonal blade pointing top-right with a crossguard. Use crystal blue/cyan for the blade.
- Save as crystal_sword.png in the same folder.

## Model JSON files
- Create crystal_pickaxe.json in assets/crystalmod/models/item/:
- Create the same for crystal_sword.json (change texture path to crystal_sword).
- Add both names to en_us.json: "item.crystalmod.crystal_pickaxe": "Crystal Pickaxe" "item.crystalmod.crystal_sword": "Crystal Sword"
- Create crystal_pickaxe.json in data/crystalmod/recipe/:
- Create crystal_sword.json in the same folder:
- Launch Minecraft Client. Create a creative world.
- Search for Crystal Pickaxe and Crystal Sword in the creative inventory.
- Switch to survival (/gamemode survival). Give yourself the pickaxe: /give @p crystalmod:crystal_pickaxe.
- Mine some stone it should be noticeably faster than diamond!
- Hover over the pickaxe in your inventory check the Attack Speed and Attack Damage stats shown in the tooltip.
- Try the crafting recipe in a crafting table with Crystal Gems and sticks.
- Test anvil repair: put the pickaxe in an anvil with a Crystal Gem durability should restore!
- In ModItems.java, add: import net.minecraft.item.AxeItem;
- Add the Crystal Axe field using AxeItem (same structure as pickaxe, change attack damage to 5 and speed to -3.0f).
- Draw a 16✨16 axe texture and create the model JSON.
- Add to en_us.json.
- Create a crafting recipe (axe pattern: two gems in top-left column, stick below).
- Test in-game!
- In data/minecraft/tags/block/, create the file mineable/pickaxe.json:
- Correct path is critical the file must be at data/minecraft/tags/block/mineable/pickaxe.json. It's minecraft, not crystalmod! You're extending Minecraft's own tag list.
- "replace" must always be false setting it to true would remove ALL vanilla blocks from pickaxe mining. Always use false.
- Folders don't exist yet you may need to create data/minecraft/tags/block/mineable/ one folder at a time. Right-click → New Directory in IntelliJ.
- Still slow after adding the tag hot-reload may not pick up tag changes. Fully stop and restart the game from the Gradle panel.

## What you built
- ✓A custom ToolMaterial enum with 5 stats
- ✓Crystal Pickaxe faster than diamond, enchants well
- ✓Crystal Sword strong attack damage
- ✓Block tag so the pickaxe mines Crystal Blocks efficiently
- ✓Anvil repair using Crystal Gem
