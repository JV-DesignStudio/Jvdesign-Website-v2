CORRUPTED: Build a Neon Glitch Obby in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-corruption-obby-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: CORRUPTED: Build a Neon Glitch Obby in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## The big idea: a world that erases itself
- Open Roblox Studio → Baseplate. Delete the Baseplate (we'll replace it). Keep SpawnLocation for now.
- The twist: platforms are tagged "Destroyable". A script watches the player's position. The moment a platform is far enough behind you, it fades and vanishes. The world literally cannot exist without you.
- On top of that, a huge Corruption Zone wall slides forward. If it catches you, a glitch-screen effect plays and you respawn.
- In Explorer, create these folders under Workspace: Map, Checkpoints, Shards, Hazards. In ReplicatedStorage create a Folder called Remotes and a ModuleScript called Config.
- Inside the Config ModuleScript, type the code below. This is the one place you'll tune every number in the game.

## Neon colour palette
- Select Workspace → Baseplate and delete it. Add a giant void floor: Part, Size 300, 1, 800, Y = -20, BrickColor Really black, Material SmoothPlastic, Anchored true. This is the void below the course.
- Use this neon palette for your platforms: Zone 1 (Boot Sequence) = Cyan / Bright blue / Medium blue. Zone 2 (Memory Lane) = Magenta / Hot pink / Bright violet. Zone 3 (Kernel Panic) = Bright red / Neon orange / Hot pink. All platforms: Material = Neon, Anchored = true.
- Build about 18-22 platforms running in the +Z direction. Zone 1 (platforms 1-7): size 8×1×8, gaps 6-8 studs, close together. Zone 2 (platforms 8-14): size 6×1×6, gaps 8-10 studs. Zone 3 (platforms 15-22): size 5×1×5, gaps 10-12 studs, with sharp turns. Parent all to the Map folder.
- Add a PointLight inside each platform (Insert Object → PointLight). Set Brightness to 2 and Range to 16. Change the light colour to match the platform. This makes the world glow in the dark.
- Add a SpawnLocation at the start (size 8×1×8, Neon, Bright blue). Add 4 Checkpoint Parts (size 4×0.5×4, Neon, Lime green, Anchored true, CanCollide false, Transparency 0.5). Name them Checkpoint1 through Checkpoint4. Parent them to the Checkpoints folder. Place the last one at the end of Zone 3 as the win pad.
- Add this CheckpointManager script in ServerScriptService:

## Create a Data Shard
- Create a Part: Size 1.5, 1.5, 1.5, Shape Ball, BrickColor Cyan, Material Neon, Anchored true. Name it Shard. Add a PointLight inside (Brightness 3, Range 12, Color cyan).
- Go to View → Tag Editor. Select your Shard part and click + to add a tag: type Shard and press Enter. Duplicate the Shard 14 times and scatter along risky jump edges. Parent all to the Shards folder.
- Create 3 larger rare shards: Size 2, 2, 2, BrickColor Hot pink, Material Neon, Anchored true. Name each CoreShard. Tag them CoreShard in the Tag Editor. Hide them in tricky secret spots.
- In ServerScriptService create a Script called LeaderStats:
- Create a Script called CollectSystem in ServerScriptService:

## Tag every platform
- Open View → Tag Editor. Select all your platforms in the Map folder (click one, Ctrl+A to select all in the folder, or hold Ctrl and click each). With all selected, click + in the Tag Editor and type Destroyable, then Enter. Every platform now has the tag.
- Do NOT tag Checkpoints, the SpawnLocation or the void floor. Those must stay.
- In ServerScriptService create a Script called PlatformManager:

## Build the wall
- Insert a Part. Name it CorruptionZone (exact name, the script needs it). Size: 150, 60, 4. BrickColor: Hot pink or Magenta. Material: Neon. Transparency: 0.25. Anchored: true. CanCollide: false. CanTouch: true.
- Place the wall behind the SpawnLocation (lower Z value). Centre it on the course (X = 0). Make it tall enough to cover the full height range.
- Set up the RemoteEvent. In ReplicatedStorage → Remotes folder insert a RemoteEvent. Name it OnCorrupted. This lets the server tell a specific player's screen to glitch.
- In ServerScriptService create a Script called CorruptionZone:

## Glitch Spinners
- Create a Part: Size 8, 0.5, 1, BrickColor Hot pink, Material Neon, Anchored true. Name it GlitchSpinner. Parent it to the Hazards folder. Position it floating above a platform gap in Zone 2 or 3.
- Insert a Script directly inside the GlitchSpinner part (not in ServerScriptService). Use this code:
- Duplicate the GlitchSpinner 2-4 times and place in different spots. You can change SPEED inside each one for variety. Try 80, 120, and 160!

## Flicker Platforms
- Create a platform: Size 6, 1, 6, BrickColor Bright violet, Material Neon, Anchored true. Name it FlickerPlatform. Place a few in Zone 2 and Zone 3 over gaps.
- Insert a Script inside the FlickerPlatform part:

## Create the glitch screen
- In Explorer go to StarterPlayer → StarterPlayerScripts. Insert a LocalScript. Name it CorruptionEffect. This runs on each player's own computer.
- Type the code below into the LocalScript:

## Speed-run Timer (LocalScript)
- In StarterGui insert a ScreenGui. Name it HUD. Inside it add a TextLabel. Name it TimerLabel. Position: AnchorPoint = 0.5,0 | Position = 0.5,0,0,12 | Size = 0.2,0,0.06,0. Font = Code. TextScaled = true. BackgroundTransparency = 0.5. BackgroundColor3 = black.
- Inside StarterGui → HUD insert a LocalScript called TimerScript:

## Final Polish Checklist
- Lighting: In Explorer → Lighting, set Ambient to 0, 0, 0 (pitch black), OutdoorAmbient to 0, 0, 0, Brightness to 0. The only light comes from your neon platforms. Eerie!
- Atmosphere: Insert Atmosphere inside Lighting. Set Density to 0.35, Color to dark purple. This adds a foggy glow around the neon light.
- Play test: Press F5 to play. Check that platforms near the start fade as you run forward. Check the Corruption Zone starts moving after the delay. Check shards collect. If the wall moves too fast, raise CORRUPTION_DELAY or lower CORRUPTION_SPEED in Config.
- Publish: File → Publish to Roblox. Set Name, Description and Genre. Set Playable Devices to Computer and Phone. Set Access to Public. Share the link!
- Config ModuleScript: one place to tune every number in your game
- CollectionService Tags: one script handles all tagged objects (shards, platforms)
- TweenService: smooth fade-and-shrink animations for platform destruction
- RunService.Heartbeat with delta time: frame-rate-independent rotation for spinners
- RemoteEvents: server fires OnCorrupted, LocalScript reacts on the player's screen only
- LocalScript vs Script: client-side screen effects vs server-side game logic
- RenderStepped timer with proximity colour change for tension
