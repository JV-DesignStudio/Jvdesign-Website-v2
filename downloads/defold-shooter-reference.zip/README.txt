Space Shooter in Defold
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/defold-shooter-workshop.html

Reference project files for this workshop.
These are the Defold files (.script, .go, .collection and so on) shown step by step
in the lesson. Create the project and game objects as the steps describe, then
attach each script to the matching component.

Files:
- player.script
- bullet.script
- spawner.script
- enemy.script
- powerup.script
- snippet-07.txt
- snippet-08.txt
- snippet-10.txt
- snippet-11.txt

How to use:
1. Create the Defold project and game objects exactly as the workshop steps describe.
2. Create each script with the same name and paste the code in.
3. Stuck? Compare your file to the reference here.
