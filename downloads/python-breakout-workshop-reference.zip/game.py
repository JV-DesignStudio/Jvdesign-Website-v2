# ===== Part 1 of 8 (as shown in the lesson) =====
paddle = pygame.Rect(295, 480, 110, 14)

keys = pygame.key.get_pressed()
if keys[pygame.K_LEFT]:
    paddle.x -= 8
if keys[pygame.K_RIGHT]:
    paddle.x += 8
paddle.x = max(0, min(700 - paddle.width, paddle.x))

# ===== Part 2 of 8 (as shown in the lesson) =====
import pygame
pygame.init()
screen = pygame.display.set_mode((700, 520))
pygame.display.set_caption("My Python Game")
clock = pygame.time.Clock()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((25, 30, 60))      # everything you build below is drawn here
    pygame.display.flip()
    clock.tick(60)                 # 60 frames per second

pygame.quit()

# ===== Part 3 of 8 (as shown in the lesson) =====
ball = pygame.Rect(340, 300, 14, 14)
bvx, bvy = 4, -4

ball.x += bvx
ball.y += bvy
if ball.left <= 0 or ball.right >= 700:
    bvx = -bvx
if ball.top <= 0:
    bvy = -bvy

# ===== Part 4 of 8 (as shown in the lesson) =====
if ball.colliderect(paddle) and bvy > 0:
    bvy = -bvy
    offset = ball.centerx - paddle.centerx
    bvx = offset // 12
    if bvx == 0:
        bvx = 1

# ===== Part 5 of 8 (as shown in the lesson) =====
colours = [(248,113,113),(251,146,60),(250,204,21),(74,222,128),(96,165,250)]
bricks = []
for row in range(5):
    for col in range(10):
        bricks.append({
            "rect": pygame.Rect(col*68 + 12, row*26 + 50, 64, 22),
            "row": row
        })

for b in bricks:
    pygame.draw.rect(screen, colours[b["row"]], b["rect"])

# ===== Part 6 of 8 (as shown in the lesson) =====
score = 0

for b in bricks[:]:
    if ball.colliderect(b["rect"]):
        bricks.remove(b)
        score += (5 - b["row"]) * 10
        bvy = -bvy
        break

# ===== Part 7 of 8 (as shown in the lesson) =====
lives = 3
state = "PLAY"

if ball.top > 520:
    lives -= 1
    ball.center = (350, 300)
    bvx, bvy = 4, -4
    if lives == 0:
        state = "LOSE"

if len(bricks) == 0:
    state = "WIN"

# ===== Part 8 of 8 (as shown in the lesson) =====
import pygame
pygame.init()
screen = pygame.display.set_mode((700, 520))
pygame.display.set_caption("Brick Breaker")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 32)
big_font = pygame.font.SysFont(None, 64)

colours = [(248, 113, 113), (251, 146, 60), (250, 204, 21), (74, 222, 128), (96, 165, 250)]

def build_bricks():
    b = []
    for row in range(5):
        for col in range(10):
            b.append({"rect": pygame.Rect(col*68 + 12, row*26 + 50, 64, 22), "row": row})
    return b

paddle = pygame.Rect(295, 480, 110, 14)
ball = pygame.Rect(340, 300, 14, 14)
bvx, bvy = 4, -4
bricks = build_bricks()
score = 0
lives = 3
state = "PLAY"

def reset():
    global paddle, ball, bvx, bvy, bricks, score, lives, state
    paddle = pygame.Rect(295, 480, 110, 14)
    ball = pygame.Rect(340, 300, 14, 14)
    bvx, bvy = 4, -4
    bricks = build_bricks()
    score = 0
    lives = 3
    state = "PLAY"

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_r and state != "PLAY":
            reset()

    if state == "PLAY":
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            paddle.x -= 8
        if keys[pygame.K_RIGHT]:
            paddle.x += 8
        paddle.x = max(0, min(700 - paddle.width, paddle.x))

        ball.x += bvx
        ball.y += bvy
        if ball.left <= 0 or ball.right >= 700:
            bvx = -bvx
        if ball.top <= 0:
            bvy = -bvy

        if ball.colliderect(paddle) and bvy > 0:
            bvy = -bvy
            offset = ball.centerx - paddle.centerx
            bvx = offset // 12
            if bvx == 0:
                bvx = 1

        for b in bricks[:]:
            if ball.colliderect(b["rect"]):
                bricks.remove(b)
                score += (5 - b["row"]) * 10
                bvy = -bvy
                break

        if ball.top > 520:
            lives -= 1
            ball.center = (350, 300)
            bvx, bvy = 4, -4
            if lives == 0:
                state = "LOSE"

        if len(bricks) == 0:
            state = "WIN"

    # draw
    screen.fill((25, 30, 60))
    for b in bricks:
        pygame.draw.rect(screen, colours[b["row"]], b["rect"])
    pygame.draw.rect(screen, (255, 119, 0), paddle)
    pygame.draw.ellipse(screen, (255, 255, 255), ball)
    screen.blit(font.render("Score: " + str(score), True, (255, 255, 255)), (12, 8))
    screen.blit(font.render("Lives: " + str(max(0, lives)), True, (255, 255, 255)), (560, 8))
    if state != "PLAY":
        text = "YOU WIN!" if state == "WIN" else "GAME OVER"
        msg = big_font.render(text, True, (255, 209, 102))
        screen.blit(msg, msg.get_rect(center=(350, 235)))
        sub = font.render("Press R to play again", True, (255, 255, 255))
        screen.blit(sub, sub.get_rect(center=(350, 290)))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()