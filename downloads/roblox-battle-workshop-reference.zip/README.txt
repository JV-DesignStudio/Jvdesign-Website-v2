Sword Fight! Build a Battle Arena in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-battle-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Sword Fight! Build a Battle Arena in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Delete the default Baseplate. Add a flat Part size 80, 1, 80, BrickColor Dark stone grey, Material Cobblestone. Name it ArenaFloor.
- Add 4 wall parts around it (size 80, 12, 2 for front/back, 2, 12, 80 for sides). BrickColor Medium stone grey, Material Brick. All Anchored = true.
- Add 6 pillar parts (size 2, 14, 2) around the inside of the walls for cover to hide behind. BrickColor Dark stone grey.
- Add 4 SpawnLocations spread around the arena so players start in different corners.
- In Lighting, set Ambient to a dark red-orange. Add a PointLight to a central pillar with orange colour and Range 40 for dramatic battle lighting.
- In ServerScriptService, add a Script named StatsSetup. Paste:

## Get the Classic Sword
- In the Home tab, click Toolbox. Search for "Classic Sword". This is Roblox's built-in sword tool click it to insert it.
- The sword appears in Workspace. Drag it into StarterPack in Explorer. Now every player spawns with it!
- Press Play to test you should have a sword in your hotbar. Press 1 or click it to equip, then click to swing.
- In ServerScriptService, add a new Script named KillTracker. Paste:

## Set respawn time
- In Explorer, find Players (near the top). Click it and in Properties, set RespawnTime to 5. Players now wait 5 seconds before respawning.

## Respawn countdown GUI
- In StarterGui, add a ScreenGui named RespawnGui. Add a TextLabel named CountdownLabel. Size: {0.3, 0}, {0.1, 0}. Position: centre screen. Text: empty. Font: GothamBold. TextSize: 40. TextColor: red. BackgroundTransparency: 1.
- Add a LocalScript inside RespawnGui:

## Add more weapons from Toolbox
- Open the Toolbox and search for another Roblox tool try "Linked Sword" or "Darkheart" (free Roblox tools).
- Insert it. Move it to a corner of the arena. Place it on a pedestal (a flat glowing Part underneath it).
- Build a small room/alcove for the weapon rack using a few wall parts. Add a sign saying "Weapon Shop" using a SurfaceGui TextLabel.
- Players can simply walk into the weapon and pick it up Roblox Tools auto-equip when touched. No scripting needed!
- Add a third weapon too give players variety. Try a Gravity Coil tool for movement or a "Bazooka".
- In StarterGui, right-click → Insert Object → ScreenGui. Name it HealthBar. Set ResetOnSpawn to true.
- Add a Frame (the background bar): Size {0.3, 0}, {0.03, 0}. Position {0.35, 0}, {0.92, 0}. BG Colour: dark red. UICorner 0.5.
- Add another Frame inside the first (the fill bar). Same size. BG Colour: bright red. Name it Fill.
- Add a TextLabel on top of the fill bar. Text: ❤️ 100. TextScaled true. BackgroundTransparency 1. TextColor white.
- Add a LocalScript inside HealthBar:
- In ReplicatedStorage, add a RemoteEvent. Name it KillAnnounce.
- Update the KillTracker script after incrementing the kill, add:
- In StarterGui, add a ScreenGui → TextLabel for announcements. Position it top-centre, large text, BackgroundTransparency 1.
- Add a LocalScript inside the GUI:
- Add Fire effects: click a part → right-click in Explorer → Insert Object → Fire. Put fire in torches made from cylinder parts.
- Add banners (tall thin parts, BrickColor bright red, with team emblems made from smaller parts attached).
- Add a lava pit trap in the centre using the kill brick script from Episode 1.
- Add a raised platform in the centre as a high ground advantage spot.
- Use Lighting → Atmosphere (Insert Object → Atmosphere) to add dust and haze for a battle atmosphere.
- Add a flat Part (size 4, 0.5, 4), BrickColor Cyan, Material Neon. Name it SpeedPad. Add a Script:
- Add a HealPad (BrickColor Bright green, Neon) with a Script that sets hum.Health = hum.MaxHealth when touched.
- Add BillboardGui labels above each pad: "⚡ Speed!" and "❤️ Heal!".
- In Workspace, right-click → Insert Object → Sound. Name it BattleMusic.
- In Properties, set SoundId. Go to the Roblox Library (toolbox → Audio), search for "battle" or "epic" and find a free audio. Copy its ID (a number like rbxassetid://142376088).
- Paste the SoundId. Set Looped to true. Set Volume to 0.5.
- Add a Script in ServerScriptService named MusicPlayer:
- Go to Test tab → click the Players dropdown → set to 2 Players. This opens 2 windows so you can test multiplayer!
- Fight yourself check kills and deaths track correctly. Check the kill announcement appears.
- Test the speed pad, heal pad and weapon shop.
- Press File → Publish to Roblox → Public. Share with friends and have a battle!
