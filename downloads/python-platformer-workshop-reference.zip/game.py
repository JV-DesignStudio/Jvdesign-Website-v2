import pygame
pygame.init()
screen = pygame.display.set_mode((800, 480))
pygame.display.set_caption("Sky Hopper")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 32)
big_font = pygame.font.SysFont(None, 72)

player = pygame.Rect(100, 380, 34, 44)
speed = 5
vy = 0
on_ground = False

platforms = [
    pygame.Rect(0, 440, 800, 40),      # ground
    pygame.Rect(150, 340, 140, 16),
    pygame.Rect(380, 260, 140, 16),
    pygame.Rect(610, 180, 140, 16),
]
coins = [pygame.Rect(205, 300, 18, 18),
         pygame.Rect(435, 220, 18, 18),
         pygame.Rect(665, 140, 18, 18)]
flag = pygame.Rect(660, 130, 16, 50)
score = 0
won = False

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and on_ground and not won:
                vy = -16
                on_ground = False

    if not won:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player.x -= speed
        if keys[pygame.K_RIGHT]:
            player.x += speed
        if player.left < 0:
            player.left = 0
        if player.right > 800:
            player.right = 800

        vy += 1                 # gravity
        player.y += vy

        on_ground = False
        for plat in platforms:
            if player.colliderect(plat) and vy > 0 and player.bottom - vy <= plat.top:
                player.bottom = plat.top
                vy = 0
                on_ground = True

        for coin in coins[:]:            # loop over a COPY
            if player.colliderect(coin):
                coins.remove(coin)
                score += 1

        if player.colliderect(flag) and len(coins) == 0:
            won = True

        if player.top > 480:             # fell into a pit
            player.x, player.y = 100, 380
            vy = 0

    # draw
    screen.fill((25, 30, 60))
    for plat in platforms:
        pygame.draw.rect(screen, (6, 214, 160), plat)
    for coin in coins:
        pygame.draw.rect(screen, (255, 209, 102), coin)
    pygame.draw.rect(screen, (247, 160, 30), flag)
    pygame.draw.rect(screen, (255, 119, 0), player)
    screen.blit(font.render("Score: " + str(score), True, (255, 255, 255)), (12, 12))
    if won:
        msg = big_font.render("YOU WIN!", True, (255, 209, 102))
        screen.blit(msg, (250, 190))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()