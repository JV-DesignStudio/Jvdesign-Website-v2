Custom Keychain
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/tinkercad-ep7-keychain.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Custom Keychain

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Get started
- Go to tinkercad.com and sign in. Click Create new design.
- You'll see the Workplane (the blue grid) where you build your 3D models.
- On the right side, you'll see the Shape Panel with Basic Shapes. Drag a Box onto the workplane, this will be your keychain base.
- Want a different shape? Click Shape Generators in the dropdown at the top of the shape panel to find hearts, stars, and more!
- Give your design a name, click the title at the top left and type "My Keychain".

## Resize your shape
- Click on your shape to select it. You'll see white square handles on the corners and edges.
- Click one of the corner handles and look at the dimension boxes that appear, these show the size in millimeters.
- Click a dimension box and type 50 for the length (the long side).
- Set the width to about 25mm, roughly half the length.
- Click the top white handle (the small square on top of the shape) and set the height to 4mm. This makes it thick enough to be strong but not too bulky.
- 50 mm 25 mm side: 4 mm Credit-card long, two fingers wide, pound-coin thick. 50 ✨ 25 × 4 mm survives life on a school bag. Type the numbers, the white handles are for grabbing, the dimension boxes are for precision. 💡50mm is about thumb-length, hold your thumb next to a ruler to get a feel for the real size. A keychain that's too thin will snap, too thick will feel clunky. ⚡ True or False? +15 XP Keychains should be as thin as paper for best results. TrueFalse 50mm is about thumb-length. TrueFalse Thickness affects how durable a 3D printed keychain is. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP Why do we make the keychain 4mm thick? AIt's strong enough not to snap BIt looks prettier CTinkerCAD requires exactly 4mm Check Answer ✅ Correct! Next Step → 3 🕳️ Add a Keyring Hole Create a hole so a keyring can go through Locked 🎯 Goal for this stepAdd a cylinder hole near one edge of the keychain so a keyring can pass through it. Add the hole From the Basic Shapes panel, drag a Cylinder onto the workplane.
- Resize the cylinder to 5mm diameter (width and length both 5mm). Set the height to at least 5mm (taller than your keychain).
- With the cylinder selected, look at the top right of the screen, click Hole to change it from a solid shape to a hole. It turns striped/transparent!
- Drag the hole cylinder to one end of your keychain, near the edge but not too close (leave about 3mm from the edge so it doesn't break).
- Select both shapes (click the keychain, then hold Shift and click the hole). Click Group (or press Ctrl+G). The hole cuts through the keychain!
- VIEW FROM ABOVE 5 mm Hole cylinder, taller than the tag 3 mm of plastic between hole and edge, or it snaps the keyring threads through here Near the end, never AT the end. If the hole touches the edge, the thin sliver of plastic left will snap the first time the keys jangle. Group after placing to punch the hole through. 💡If the hole doesn't go all the way through, make sure the cylinder is taller than the keychain. It needs to poke out both sides to cut completely through. 💻 Fill-in Challenge +20 XP Fill in the blanks for the keyring hole settings: Cylinder diameter: mm Shape type: 🔍 Check Answers 💡 Hint: The hole needs to be wide enough for a keyring (about 5mm) and set to a type that cuts through other shapes. 🧠 Knowledge Check +15 XP What happens if you forget to make the cylinder a Hole before grouping? AThe keychain disappears BIt stays solid, no ring can go through CTinkerCAD shows an error Check Answer ✅ Correct! Next Step → 4 📝 Add Text Drag a Text shape onto your keychain and type your name Locked 🎯 Goal for this stepAdd a 3D Text shape to the workplane and type your name or initials. Add your name In the Shape Panel on the right side, scroll down or search for the Text shape (it looks like the letter "A").
- Drag the Text shape onto the workplane. It appears as 3D text saying "Text" by default.
- With the text selected, look at the Shape inspector window that appears. Find the text field and type your name (or initials if your name is long).
- You can also change the font in the shape inspector, try different ones to see which looks coolest!

## Resize and align
- Click on your text shape and use the corner handles to make it smaller or bigger until it fits on the keychain surface.
- Make sure the text is not wider than the keychain, leave a small gap on each side.
- Set the text height to about 2mm, this is how much the text will stick up (or cut in) from the surface.
- Select both the keychain and the text (click one, Shift+click the other).
- Click the Align tool (the "L" icon in the top toolbar). Black dots appear, click the center dots for both the horizontal and vertical axes to center the text perfectly.

## Solid vs Hole text
- Raised text (Solid): If the text stays as a Solid shape, it sits on top of the keychain surface. When grouped, it sticks up, you can feel it with your finger!
- Engraved text (Hole): If you change the text to a Hole shape, it cuts into the keychain surface when grouped. The letters are carved in.
- To try engraved: click your text, click Hole in the shape inspector (top right). The text turns striped/transparent.
- Position the text so it slightly overlaps the top surface of the keychain (raise it up on the Z axis if needed).
- Try both! You can always Undo (Ctrl+Z) to switch between raised and engraved to see which you prefer.

## Group and color
- Press Ctrl+A to select all shapes on the workplane (keychain base + text + any decorations).
- Click the Group button in the top toolbar (or press Ctrl+G). All shapes merge into one solid object!
- With the grouped object selected, click the color swatch in the shape inspector (top right).
- Pick any color you like! This color shows in TinkerCAD and some slicer programs. The actual print color depends on your filament.

## Export and print settings
- Click the Export button in the top right corner of TinkerCAD.
- Choose .STL as the file format. This is the standard format that 3D printers understand.
- Save the file to your computer. You'll load this into a slicer program (like Cura or PrusaSlicer) to prepare it for printing.
- In your slicer, the most important setting for text keychains is Layer Height:
- 0.1mm layer height = Fine detail. Small text is crisp and readable. Takes longer to print.
- 0.2mm layer height = Faster print. Good for big text but small letters may look blobby.
- For keychains with text, we recommend 0.1mm, the extra time is worth it for readable letters!
