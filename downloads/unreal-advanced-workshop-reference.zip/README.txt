My First Unreal Game Ep 8: Advanced Systems
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/unreal-advanced-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First Unreal Game Ep 8: Advanced Systems

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- The problem: your player casts to BP_Door, BP_Chest, BP_NPC, BP_Lever… every new interactable means editing the player. Spaghetti.
- The fix: a Blueprint Interface (BPI_Interact) with one function: Interact.
- Each interactable implements it its own way: door opens, chest loots, NPC talks. The player just sends Interact (Message) at whatever it traces, no casts, no knowledge of types.
- Add interact detection: a line trace forward from the camera on E press; send the interface message to the hit actor.
- New interactable tomorrow? Implement the interface. Player code: unchanged. THAT is architecture.
- Problem two: the boss dies → update HUD, open gate, play music, grant achievement. Should the boss know about ALL those? No!
- Event Dispatcher on the boss: OnBossDied. The boss just Calls it when hp hits 0, and has no idea who cares.
- The HUD, the gate and the music manager each Bind to it at BeginPlay (get boss reference → Bind Event to OnBossDied).
- One broadcast, any number of listeners, zero coupling. This is the observer pattern, MonoBehaviour events/C# delegates/JS addEventListener are all the same idea.
- Refactor your coin pickup to use one: OnCoinCollected → the HUD binds instead of the coin writing player variables.
- Health for player, enemies AND breakable crates, copy-paste three times? Never. Build an Actor Component: BP_HealthComponent.
- Inside it: MaxHealth + CurrentHealth variables, a TakeDamage function, and two dispatchers, OnDamaged and OnDied.
- Any actor adds the component and binds the events: the player’s OnDied → respawn logic; the crate’s OnDied → spawn loot + destroy.
- Same component, wildly different owners. Composition over duplication, Unity components, Unreal components, same philosophy.
- Wire your Episode-series weapons to call TakeDamage on anything with the component (FindComponentByClass → valid check).
- Create a Blueprint class from SaveGame: BP_MySave, with variables: PlayerLocation, CoinCount, Health, LevelName.
- Saving: Create Save Game Object → fill its variables from the world → Save Game to Slot ("slot1").
- Loading: Does Save Game Exist → Load Game from Slot → cast to BP_MySave → apply values (teleport player, set counts).
- Trigger saves at checkpoints (a trigger volume calling a SaveGame function in the Game Mode) and load from the main menu Continue button.
- Test the full loop: play, collect, save, QUIT COMPLETELY, relaunch, continue. Progress intact = players trust your game.
- One giant level = huge load times and memory. Real games STREAM: the world is sublevels loaded/unloaded as needed.
- Window → Levels: create sublevels (Zone_A, Zone_B), move geometry into them (select actors → Move Selection to Level).
- Trigger volumes at zone borders: Load Stream Level (the one ahead) and Unload Stream Level (the one behind).
- Hide the seam: doorways, corridors and elevators, every "mysteriously slow door" in AAA games is a streaming mask!
- Watch memory drop in the stats while zones unload. Same idea as UE5’s World Partition, learned by hand.
- The golden rule: measure before optimising. Feelings lie; profilers do not.
- Console (backtick key): stat fps, stat unit, is the frame spent on Game (your logic), Draw (CPU render prep) or GPU (shading)?
- GPU-bound: heavy materials/lights/resolution. Game-bound: your Blueprints, usually Tick abuse!
- Tick medicine: does that coin REALLY need Event Tick? Rotating meshes → a RotatingMovement component (C++-fast); timed logic → Timers, not Tick counting.
- Try Unreal Insights (bundled) for a full flame-graph trace. Fix the top item only, re-measure, repeat. That loop is the whole discipline.
