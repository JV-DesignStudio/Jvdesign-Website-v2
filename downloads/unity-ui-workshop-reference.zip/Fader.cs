IEnumerator FadeAndLoad(string scene)
{
    for (float a = 0; a < 1; a += Time.unscaledDeltaTime * 2f)
    {
        black.color = new Color(0, 0, 0, a);
        yield return null;
    }
    SceneManager.LoadScene(scene);
    for (float a = 1; a > 0; a -= Time.unscaledDeltaTime * 2f)
    {
        black.color = new Color(0, 0, 0, a);
        yield return null;
    }
}