using UnityEngine;

public class PauseManager : MonoBehaviour
{
    public GameObject pausePanel;
    bool paused;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            paused = !paused;
            pausePanel.SetActive(paused);
            Time.timeScale = paused ? 0f : 1f;
        }
    }
}