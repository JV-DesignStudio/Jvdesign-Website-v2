using UnityEngine;

public class SettingsMenu : MonoBehaviour
{
    public void SetVolume(float value)
    {
        AudioListener.volume = value;
    }

    public void SetQuality(int index)
    {
        QualitySettings.SetQualityLevel(index);
    }

    public void SetFullscreen(bool isOn)
    {
        Screen.fullScreen = isOn;
    }
}