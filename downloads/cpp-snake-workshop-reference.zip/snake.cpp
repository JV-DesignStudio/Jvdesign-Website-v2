// Complete C++ Snake for SFML 3. Build:
//   g++ snake.cpp -o snake -lsfml-graphics -lsfml-window -lsfml-system
#include <SFML/Graphics.hpp>
#include <optional>
#include <deque>
#include <cstdlib>

int main() {
    const int GRID = 25, CELL = 20;
    sf::RenderWindow window(sf::VideoMode({500, 500}), "C++ Snake");
    window.setFramerateLimit(60);

    std::deque<sf::Vector2i> snake = {{12,12},{11,12},{10,12}};
    sf::Vector2i dir = {1, 0};
    sf::Vector2i food = {5, 5};
    bool dead = false;
    sf::Clock clock;
    float acc = 0.f;

    auto spawnFood = [&]() {
        while (true) {
            sf::Vector2i f = {std::rand() % GRID, std::rand() % GRID};
            bool onSnake = false;
            for (auto& c : snake) if (c == f) onSnake = true;
            if (!onSnake) { food = f; return; }
        }
    };
    spawnFood();

    auto reset = [&]() {
        snake = {{12,12},{11,12},{10,12}}; dir = {1,0}; dead = false; spawnFood();
    };

    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) window.close();
            if (const auto* k = event->getIf<sf::Event::KeyPressed>()) {
                using K = sf::Keyboard::Key;
                if (k->code == K::Up    && dir.y != 1)  dir = {0,-1};
                if (k->code == K::Down  && dir.y != -1) dir = {0, 1};
                if (k->code == K::Left  && dir.x != 1)  dir = {-1,0};
                if (k->code == K::Right && dir.x != -1) dir = {1, 0};
                if (k->code == K::Space && dead) reset();
            }
        }

        acc += clock.restart().asSeconds();
        if (!dead && acc >= 0.12f) {
            acc = 0.f;
            sf::Vector2i head = snake[0] + dir;
            if (head.x < 0 || head.x >= GRID || head.y < 0 || head.y >= GRID) dead = true;
            for (auto& c : snake) if (c == head) dead = true;
            if (!dead) {
                snake.push_front(head);
                if (head == food) spawnFood();
                else snake.pop_back();
            }
        }

        window.clear(sf::Color(10, 14, 20));
        sf::CircleShape f(8.f);
        f.setPosition({food.x * (float)CELL + 2, food.y * (float)CELL + 2});
        f.setFillColor(sf::Color(255, 84, 112));
        window.draw(f);
        for (auto& c : snake) {
            sf::RectangleShape cell({CELL - 2.f, CELL - 2.f});
            cell.setPosition({c.x * (float)CELL + 1, c.y * (float)CELL + 1});
            cell.setFillColor(sf::Color(51, 209, 122));
            window.draw(cell);
        }
        window.display();
    }
}