Jump & Run! Build a Platformer in Scratch
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/scratch-platformer-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Jump & Run! Build a Platformer in Scratch

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Create the project
- Go to scratch.mit.edu and click Start Creating.
- Name the project "Jump and Run Platformer".
- Delete the Scratch Cat sprite (right-click → Delete).
- Click the Stage backdrop area and choose a backdrop. Pick "Blue Sky" or "Colorful City", something with a sky feel.
- Click Choose a Sprite and search for "Pico", "Tera" or any character you like. Add it.
- Set the Size to 60 in the properties area.
- Drag the sprite to the bottom-left of the stage. This is the starting position.
- In the sprite's Costumes tab, check it has at least 2 costumes (for walking animation). If not, you can duplicate the costume and flip it.
- Select the player sprite. Drag in a "when 🏳 clicked" block, then a "forever" loop.
- Inside forever: add "if key [right arrow] pressed? then". Inside: "change x by (5)" and "point in direction (90)" and "next costume".
- Add another if: "if key [left arrow] pressed? then". Inside: "change x by (-5)" and "point in direction (-90)" and "next costume".

## Create variables
- Make two variables: YVelocity and OnGround. Uncheck both so they don't show on stage.

## Add the gravity script (separate script stack)
- Drag a new "when 🏳 clicked" block. Set YVelocity to 0. Add a forever loop.
- Inside forever: "change YVelocity by (-1)" (gravity pulls down), then "change y by (YVelocity)".
- Add: "if touching color [green]? then" we'll draw green platforms next step. Inside: "set YVelocity to 0" and "set OnGround to 1" and "change y by 2" (push out of floor).
- Otherwise (else): "set OnGround to 0".

## Add jump (inside your first forever loop)
- Inside your movement forever loop, add: "if key [up arrow] pressed? and OnGround = 1 then set YVelocity to 12".
- Click Paint (paintbrush icon) in the sprite menu to draw a new sprite.
- In the costume editor, use the Rectangle tool. Set the fill colour to solid green.
- Draw a wide rectangle at the bottom of the costume this is the floor.
- Draw several smaller rectangles at different heights these are your platforms to jump to.
- Name this sprite Platforms.
- In the Code tab, add "when 🏳 clicked → go to x: 0 y: 0" so it stays fixed.
- Press Green Flag, your player should land on the green floor and be able to jump to the platforms!
- Make a variable called Score.
- Click Choose a Sprite and search for "Ball" or paint a small yellow circle. Name it Coin.
- Set size to 30. In the Code tab, add: "when 🏳 clicked → show → go to x: (50) y: (20)", position it on a platform.
- Add a forever loop with: "if touching [Player]? then change Score by 1 → hide".
- Right-click the Coin sprite in the Sprite Panel and choose Duplicate several times. Move each copy to a different platform.
- In the Platforms sprite costume editor, draw some red triangles as spikes on top of some platforms.
- In the player's gravity script, add: "if touching color [red]? then go to x: (-180) y: (-100)" (the starting position).
- Also add: "if y position < -170 then go to x: (-180) y: (-100)" this catches the player if they fall off the bottom.
- Click Choose a Sprite and search for "Flag". Add it and set size to 80.
- Drag the flag to the far right of the stage, on top of the highest platform.
- In the flag's code: "when 🏳 clicked → forever → if touching [Player]? then say [You Win! 🎉] for 3 seconds → stop all".
- Make a variable called Timer.
- In the Stage's scripts (click the Stage, not a sprite): add "when 🏳 clicked → set Timer to 60 → repeat until Timer = 0 → wait 1 second → change Timer by -1 → end".
- After the repeat: "say [Time's Up! Game Over] for 2 seconds → stop all".
- Press Green Flag and play through the whole level. Try to collect every coin and reach the flag!
- If the jump feels too floaty, lower the jump power (change 12 to 10). Too snappy? Raise it.
- If the level is too easy, move platforms further apart or add more red spikes.
- Click File → Save now then the orange Share button to publish.
