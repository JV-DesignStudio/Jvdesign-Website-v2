#include "Kismet/GameplayStatics.h"

// -- GET THE PLAYER ------------------------
ACharacter* PC = UGameplayStatics::GetPlayerCharacter(
    GetWorld(), 0); // 0 = player index

// -- FIND ALL ACTORS OF A TYPE -------------
TArray<AActor*> Enemies;
UGameplayStatics::GetAllActorsOfClass(
    GetWorld(), AEnemy::StaticClass(), Enemies);

// -- PLAY A SOUND --------------------------
UGameplayStatics::PlaySoundAtLocation(
    GetWorld(), ShootSound, GetActorLocation());

// -- SPAWN A PARTICLE SYSTEM ---------------
UGameplayStatics::SpawnEmitterAtLocation(
    GetWorld(), ExplosionFX, GetActorLocation());

// -- APPLY RADIAL DAMAGE -------------------
UGameplayStatics::ApplyRadialDamage(
    GetWorld(),
    50.f,                    // base damage
    GetActorLocation(),      // origin
    300.f,                   // radius
    nullptr, {}, this, nullptr);

// -- OPEN A LEVEL --------------------------
UGameplayStatics::OpenLevel(
    this, FName("MainMenu"));