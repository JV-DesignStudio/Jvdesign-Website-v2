public:
    // EditAnywhere = editable in Details Panel
    // Category = organises properties into groups
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Movement")
    float MoveSpeed = ; // UE units/sec

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat")
    float FireRate = ;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat")
    int32 MaxHealth = ;

private:
    // VisibleAnywhere = read-only in Details
    UPROPERTY(VisibleAnywhere, Category="Combat")
    int32 CurrentHealth = 100;

    float FireTimer = 0.f; // no UPROPERTY = not visible