// ===== Part 1 of 3 (as shown in the lesson) =====
#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "TopDownCharacter.generated.h"

UCLASS()
class ATopDownCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    // Sets default values, called once on spawn
    ATopDownCharacter();

protected:
    // Called when the game starts
    virtual void BeginPlay() override;

public:
    // Called every frame
    virtual void Tick(float DeltaTime) override;
};

// ===== Part 2 of 3 (as shown in the lesson) =====
public:
    // EditAnywhere = editable in Details Panel
    // Category = organises properties into groups
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Movement")
    float MoveSpeed = 500; // UE units/sec

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat")
    float FireRate = 0.2;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat")
    int32 MaxHealth = 100;

private:
    // VisibleAnywhere = read-only in Details
    UPROPERTY(VisibleAnywhere, Category="Combat")
    int32 CurrentHealth = 100;

    float FireTimer = 0.f; // no UPROPERTY = not visible

// ===== Part 3 of 3 (as shown in the lesson) =====
#include "InputActionValue.h"

protected:
    // Assign these in the Blueprint Details panel
    UPROPERTY(EditAnywhere, Category="Input")
    class UInputMappingContext* MappingContext;

    UPROPERTY(EditAnywhere, Category="Input")
    class UInputAction* IA_Move;

    UPROPERTY(EditAnywhere, Category="Input")
    class UInputAction* IA_Shoot;

    UPROPERTY(EditAnywhere, Category="Input")
    class UInputAction* IA_Dash;

    // Bound to IA_Move:
    void Move(const FInputActionValue& Value);
    void Shoot(const FInputActionValue& Value);