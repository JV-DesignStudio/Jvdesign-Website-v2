Build a Nuclear Throne Shooter in Unreal
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/unreal-top-down-shooter.html

Reference project files for this workshop.
These are the finished code files shown step by step in the lesson, so you can
compare your own version or copy a section you are stuck on.

Files:
- Bullet.cpp
- Bullet.h
- Enemy.cpp
- Enemy.h
- EnemyAIController.cpp
- GameStatics.cpp
- LoopExamples.cpp
- MathExamples.cpp
- Source_ Project Structure
- TopDownCharacter.cpp
- TopDownCharacter.h
- TopDownGameMode.cpp
- TopDownHUD.h
- WaveConfig.h
- WaveSpawner.cpp
- WaveSpawner.h

How to use:
1. Unzip this folder somewhere easy to find.
2. Follow the workshop steps and type the code yourself.
3. Stuck? Open the matching file here and compare it line by line.
4. Every code block on the workshop page also has a Copy button.
