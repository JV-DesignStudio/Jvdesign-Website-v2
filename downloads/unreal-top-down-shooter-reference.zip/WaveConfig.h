USTRUCT(BlueprintType)
struct FEnemySpawnEntry
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TSubclassOf<AEnemy> EnemyClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 Count = 3;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float SpawnDelay = 0.5f; // stagger spawns
};

USTRUCT(BlueprintType)
struct FWaveConfig
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TArray<FEnemySpawnEntry> Entries;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float TimeTillNextWave = 8.f;
};

// In WaveSpawner, designer configures waves in editor:
UPROPERTY(EditAnywhere, Category="Waves")
TArray<FWaveConfig> WaveConfigs;