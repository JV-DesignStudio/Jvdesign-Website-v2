UENUM(BlueprintType)
enum class EEnemyType : uint8
{
    Grunt    UMETA(DisplayName="Grunt"),
    Runner   UMETA(DisplayName="Runner"),
    Tank     UMETA(DisplayName="Tank"),
    Shooter  UMETA(DisplayName="Shooter"),
};

// Use in AEnemy:
UPROPERTY(EditAnywhere, Category="AI")
EEnemyType EnemyType = EEnemyType::Grunt;

void AEnemy::ConfigureFromType()
{
    switch (EnemyType)
    {
        case EEnemyType::Grunt:
            MaxHealth=3; MoveSpeed=300; break;
        case EEnemyType::Runner:
            MaxHealth=1; MoveSpeed=550; break;
        case EEnemyType::Tank:
            MaxHealth=8; MoveSpeed=160; break;
        case EEnemyType::Shooter:
            MaxHealth=2; MoveSpeed=200; break;
    }
}