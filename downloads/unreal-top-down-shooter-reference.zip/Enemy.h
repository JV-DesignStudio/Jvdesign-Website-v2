// ===== Part 1 of 2 (as shown in the lesson) =====
UCLASS()
class AEnemy : public ACharacter
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, Category="AI")
    float MoveSpeed  = 300;

    UPROPERTY(EditAnywhere, Category="Combat")
    int32 MaxHealth = 3;

    // Override UE's built-in damage system:
    UFUNCTION()
    virtual float TakeDamage(
        float DamageAmount,
        struct FDamageEvent const& DamageEvent,
        AController* EventInstigator,
        AActor*        DamageCauser
    ) override;

    UFUNCTION(BlueprintImplementableEvent)
    void OnDeath(); // override in Blueprint!

private:
    int32 CurrentHealth;
};

// ===== Part 2 of 2 (as shown in the lesson) =====
UENUM(BlueprintType)
enum class EEnemyType : uint8
{
    Grunt    UMETA(DisplayName="Grunt"),
    Runner   UMETA(DisplayName="Runner"),
    Tank     UMETA(DisplayName="Tank"),
    Shooter  UMETA(DisplayName="Shooter"),
};

// Use in AEnemy:
UPROPERTY(EditAnywhere, Category="AI")
EEnemyType EnemyType = EEnemyType::Grunt;

void AEnemy::ConfigureFromType()
{
    switch (EnemyType)
    {
        case EEnemyType::Grunt:
            MaxHealth=3; MoveSpeed=300; break;
        case EEnemyType::Runner:
            MaxHealth=1; MoveSpeed=550; break;
        case EEnemyType::Tank:
            MaxHealth=8; MoveSpeed=160; break;
        case EEnemyType::Shooter:
            MaxHealth=2; MoveSpeed=200; break;
    }
}