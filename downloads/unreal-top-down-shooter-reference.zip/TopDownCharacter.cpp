float DashDistance = ; // UE units
float DashCooldown = 1.5f;
float ShieldDuration = 2.f;

// Called by IA_Dash input binding:
void ATopDownCharacter::Dash()
{
    if (!GetWorldTimerManager().IsTimerActive(DashHandle))
    {
        FVector Dir = GetLastMovementInputVector();
        if (Dir.IsNearlyZero()) Dir = GetActorForwardVector();

        LaunchCharacter(Dir * DashDistance, true, true);

        // Start cooldown timer:
        GetWorldTimerManager().SetTimer(
            DashHandle, DashCooldown, false);

        SpawnDashVFX(); // particles!
    }
}

// Shield blocks all damage for duration:
void ATopDownCharacter::ActivateShield()
{
    bShieldActive = true;
    GetWorldTimerManager().SetTimer(
        ShieldHandle,
        [this](){ bShieldActive = false; },
        ShieldDuration, false);
}