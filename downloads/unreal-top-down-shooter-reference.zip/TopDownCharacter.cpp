// ===== Part 1 of 7 (as shown in the lesson) =====
void ATopDownCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime); // always call parent first!

    // DeltaTime at 60fps · 0.0167 seconds
    // DeltaTime at 30fps · 0.0333 seconds
    // Multiply by it so movement is ALWAYS the same

    FireTimer += DeltaTime;

    // Move 500 units per SECOND, not per frame:
    float Step = MoveSpeed * DeltaTime;

    UE_LOG(LogTemp, Log, TEXT("DeltaTime: %f"), DeltaTime);
}

// ===== Part 2 of 7 (as shown in the lesson) =====
void ATopDownCharacter::SetupPlayerInputComponent(UInputComponent* Input)
{
    auto* EI = CastChecked<UEnhancedInputComponent>(Input);

    // Bind Move action to the Move function:
    EI->BindAction(IA_Move, ETriggerEvent::Triggered,
                   this, &ATopDownCharacter::Move);

    EI->BindAction(IA_Shoot, ETriggerEvent::Started,
                   this, &ATopDownCharacter::Shoot);
}

// ===== Part 3 of 7 (as shown in the lesson) =====
void ATopDownCharacter::Move(const FInputActionValue& Value)
{
    // IA_Move returns a 2D axis value:
    FVector2D MoveInput = Value.Get<FVector2D>();

    // For top-down: X = right, Y = forward
    if (MoveInput.X != 0.f)
        AddMovementInput(FVector::RightVector, MoveInput.X);

    if (MoveInput.Y != 0.f)
        AddMovementInput(FVector::ForwardVector, MoveInput.Y);
}

// In the constructor, set speed:
GetCharacterMovement()->MaxWalkSpeed = MoveSpeed;

// ===== Part 4 of 7 (as shown in the lesson) =====
void ATopDownCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    // Get mouse position in world space:
    APlayerController* PC = GetWorld()->GetFirstPlayerController();
    if (!PC) return;

    FHitResult Hit;
    PC->GetHitResultUnderCursor(
        ECC_Visibility, // trace channel
        false,           // complex collision?
        Hit);

    if (Hit.bBlockingHit)
    {
        // Rotate to face the hit point:
        FVector Dir = Hit.ImpactPoint
                       - GetActorLocation();
        Dir.Z = 0.f; // ignore height

        FRotator AimRot = Dir.Rotation();
        SetActorRotation(FMath::RInterpTo(
            GetActorRotation(), AimRot, DeltaTime,
            20.f)); // smooth at speed 20
    }
}

// ===== Part 5 of 7 (as shown in the lesson) =====
bool bWantsFire = false; // set by Shoot() input binding

void ATopDownCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    FireTimer += DeltaTime;

    if (bWantsFire
        && FireTimer >= FireRate
        && CurrentHealth > 0)
    {
        FireTimer = 0.f;
        FireBullet();
    }
    else if (CurrentHealth <= 0)
    {
        // Dead, trigger game over
        OnDeath();
    }
}

// Fire rate is editable:
UPROPERTY(EditAnywhere, Category="Combat")
float FireRate = 0.18; // seconds

// ===== Part 6 of 7 (as shown in the lesson) =====
// In the header, hold a reference to the bullet class:
UPROPERTY(EditAnywhere, Category="Combat")
TSubclassOf<ABullet> BulletClass;

void ATopDownCharacter::FireBullet()
{
    if (!BulletClass) return; // guard: always check!

    // Muzzle = position in front of the player:
    FVector Muzzle = GetActorLocation()
                     + GetActorForwardVector() * 50.f;
    FRotator Rot = GetActorRotation();

    FActorSpawnParameters Params;
    Params.Owner = this; // bullet knows its owner
    Params.Instigator = GetInstigator();

    ABullet* Bullet = GetWorld()->SpawnActor<ABullet>(
        BulletClass, Muzzle, Rot, Params);
}

// ===== Part 7 of 7 (as shown in the lesson) =====
float DashDistance = 500; // UE units
float DashCooldown = 1.5f;
float ShieldDuration = 2.f;

// Called by IA_Dash input binding:
void ATopDownCharacter::Dash()
{
    if (!GetWorldTimerManager().IsTimerActive(DashHandle))
    {
        FVector Dir = GetLastMovementInputVector();
        if (Dir.IsNearlyZero()) Dir = GetActorForwardVector();

        LaunchCharacter(Dir * DashDistance, true, true);

        // Start cooldown timer:
        GetWorldTimerManager().SetTimer(
            DashHandle, DashCooldown, false);

        SpawnDashVFX(); // particles!
    }
}

// Shield blocks all damage for duration:
void ATopDownCharacter::ActivateShield()
{
    bShieldActive = true;
    GetWorldTimerManager().SetTimer(
        ShieldHandle,
        [this](){ bShieldActive = false; },
        ShieldDuration, false);
}