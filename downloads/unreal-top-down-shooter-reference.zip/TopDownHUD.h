#include "Blueprint/UserWidget.h"
#include "Components/TextBlock.h"
#include "Components/ProgressBar.h"

UCLASS()
class UTopDownHUD : public UUserWidget
{
    GENERATED_BODY()

public:
    // BindWidget: name must match UMG widget name exactly
    UPROPERTY(meta=(BindWidget))
    UTextBlock* ScoreText;

    UPROPERTY(meta=(BindWidget))
    UProgressBar* HealthBar;

    UPROPERTY(meta=(BindWidget))
    UTextBlock* WaveText;

    // Called from player C++ to update UI:
    UFUNCTION(BlueprintCallable)
    void UpdateHealth(float Pct)
    {
        HealthBar->SetPercent(Pct);
        FSlateColor Colour = Pct > 0.5f
            ? FLinearColor::Green
            : FLinearColor::Red;
        HealthBar->SetFillColorAndOpacity(Colour);
    }
};