ATopDownGameMode::ATopDownGameMode()
{
    // Set default classes, can override in Project Settings:
    DefaultPawnClass       = ATopDownCharacter::StaticClass();
    PlayerControllerClass  = ATopDownController::StaticClass();
    GameStateClass         = ATopDownGameState::StaticClass();
}

void ATopDownGameMode::PlayerDied(ATopDownCharacter* Player)
{
    // Show game over after 2s:
    FTimerHandle Th;
    GetWorldTimerManager().SetTimer(Th, [this, Player]()
    {
        RestartPlayer(Player->GetController());
    }, 2.f, false);
}

// In GameState, shared across all players:
UPROPERTY(Replicated)
int32 GlobalScore = 0;

UPROPERTY(Replicated)
int32 WaveNumber = 0;