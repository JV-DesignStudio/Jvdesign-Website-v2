// ===== Part 1 of 2 (as shown in the lesson) =====
// Declare in header, UPROPERTY for GC safety:
UPROPERTY()
TArray<AEnemy*> ActiveEnemies;

void AWaveSpawner::TrackEnemy(AEnemy* E)
{
    ActiveEnemies.Add(E);
}

void AWaveSpawner::RemoveDeadEnemies()
{
    // Remove invalid (destroyed) pointers:
    ActiveEnemies.RemoveAll([](const AEnemy* E){
        return !IsValid(E);
    });
}

int32 AWaveSpawner::GetEnemyCount() const
{
    return ActiveEnemies.Num(); // .Num() not .size()!
}

// Iterate all enemies:
for (AEnemy* Enemy : ActiveEnemies)
{
    if (IsValid(Enemy)) Enemy->UpdateBehavior();
}

// ===== Part 2 of 2 (as shown in the lesson) =====
private:
    FTimerHandle WaveTimerHandle;
    int32        WaveNumber = 0;

void AWaveSpawner::BeginPlay()
{
    Super::BeginPlay();

    // Start first wave after 2s, then repeat:
    GetWorldTimerManager().SetTimer(
        WaveTimerHandle,         // handle to cancel later
        this,                    // object
        &AWaveSpawner::SpawnWave, // function
        6.f,               // interval (seconds)
        true);                   // repeat?
}

void AWaveSpawner::SpawnWave()
{
    WaveNumber++;
    int32 Count = FMath::Min(2 + WaveNumber, 8);

    for (int32 i = 0; i < Count; i++)
        SpawnEnemyAtEdge();

    UE_LOG(LogTemp, Log, TEXT("Wave %d, %d enemies"),
           WaveNumber, Count);
}