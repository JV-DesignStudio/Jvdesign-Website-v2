private:
    FTimerHandle WaveTimerHandle;
    int32        WaveNumber = 0;

void AWaveSpawner::BeginPlay()
{
    Super::BeginPlay();

    // Start first wave after 2s, then repeat:
    GetWorldTimerManager().SetTimer(
        WaveTimerHandle,         // handle to cancel later
        this,                    // object
        &AWaveSpawner::SpawnWave, // function
        .f,               // interval (seconds)
        true);                   // repeat?
}

void AWaveSpawner::SpawnWave()
{
    WaveNumber++;
    int32 Count = FMath::Min(2 + WaveNumber, 8);

    for (int32 i = 0; i < Count; i++)
        SpawnEnemyAtEdge();

    UE_LOG(LogTemp, Log, TEXT("Wave %d, %d enemies"),
           WaveNumber, Count);
}