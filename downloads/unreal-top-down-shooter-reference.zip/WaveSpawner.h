public:
    // Designer assigns BP_EnemyGrunt in the editor:
    UPROPERTY(EditAnywhere, Category="Spawning")
    TSubclassOf<AEnemy> GruntClass;

    UPROPERTY(EditAnywhere, Category="Spawning")
    TSubclassOf<AEnemy> RunnerClass;

    UPROPERTY(EditAnywhere, Category="Spawning")
    TSubclassOf<AEnemy> TankClass;

    // Array of all possible classes to pick from:
    UPROPERTY(EditAnywhere, Category="Spawning")
    TArray<TSubclassOf<AEnemy>> AllEnemyClasses;

void AWaveSpawner::SpawnRandom(FVector Loc)
{
    if (AllEnemyClasses.Num() == 0) return;
    int32 Idx = FMath::RandRange(0, AllEnemyClasses.Num()-1);
    GetWorld()->SpawnActor<AEnemy>(AllEnemyClasses[Idx], Loc, FRotator::ZeroRotator);
}