#include "Navigation/PathFollowingComponent.h"

void AEnemyAIController::BeginPlay()
{
    Super::BeginPlay();

    // Find the player and start chasing:
    PlayerActor = UGameplayStatics::GetPlayerCharacter(
                       GetWorld(), 0);

    // Use navigation mesh, pathfinds around walls:
    MoveToActor(PlayerActor,
        150.f,       // acceptable radius (stop here)
        true,        // use pathfinding
        true);       // can strafe
}

void AEnemyAIController::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
    // Re-chase every second (player moved):
    ChaseTimer += DeltaTime;
    if (ChaseTimer >= 1.f) {
        ChaseTimer = 0.f;
        MoveToActor(PlayerActor, 150.f);
    }
}