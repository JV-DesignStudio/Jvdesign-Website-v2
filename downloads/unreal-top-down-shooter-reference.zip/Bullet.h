#include "GameFramework/ProjectileMovementComponent.h"

UCLASS()
class ABullet : public AActor
{
    GENERATED_BODY()
public:
    ABullet();

    UPROPERTY(VisibleAnywhere)
    UProjectileMovementComponent* ProjectileMovement;

    UPROPERTY(EditAnywhere, Category="Combat")
    float InitialSpeed = 1200;
};