float AEnemy::TakeDamage(
    float DamageAmount,
    struct FDamageEvent const& DamageEvent,
    AController* Instigator, AActor* Causer)
{
    float Actual = Super::TakeDamage(
        DamageAmount, DamageEvent, Instigator, Causer);

    CurrentHealth -= (int32)Actual;

    if (CurrentHealth <= 0)
    {
        // Award score to the player:
        ATopDownCharacter* Killer =
            Cast<ATopDownCharacter>(Instigator->GetPawn());
        if (Killer) Killer->AddScore(10);

        OnDeath(); // Blueprint: play VFX, drop loot
        Destroy();
    }
    return Actual;
}