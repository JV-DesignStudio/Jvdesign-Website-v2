// -- DISTANCE ------------------------------
FVector ToEnemy = EnemyLoc - PlayerLoc;
float Dist = ToEnemy.Size();        // magnitude
FVector Dir  = ToEnemy.GetSafeNormal(); // unit vector

// -- CLAMP (keep in bounds) -----------------
float ClampedX = FMath::Clamp(RawX, -800.f, 800.f);

// -- INTERPOLATION (smooth follow) ---------
FVector Smooth = FMath::VInterpTo(
    Current, Target, DeltaTime, 5.f); // speed=5

// -- DOT PRODUCT (angle check) -------------
float Dot = FVector::DotProduct(DirA, DirB);
// Dot == 1: same dir, 0: perpendicular, -1: opposite

// -- RANDOM --------------------------------
float Spread = FMath::RandRange(-5.f, 5.f);
FVector RandDir = FMath::VRandCone(
    AimDir, FMath::DegreesToRadians(5));