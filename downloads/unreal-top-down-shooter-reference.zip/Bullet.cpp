// ===== Part 1 of 2 (as shown in the lesson) =====
ABullet::ABullet()
{
    // Create and attach the component:
    ProjectileMovement = CreateDefaultSubobject
        <UProjectileMovementComponent>(TEXT("ProjMove"));

    ProjectileMovement->InitialSpeed     = InitialSpeed;
    ProjectileMovement->MaxSpeed          = InitialSpeed;
    ProjectileMovement->bRotationFollowsVelocity = true;
    ProjectileMovement->ProjectileGravityScale = 0.f; // top-down = no gravity

    // Self-destruct after 2 seconds:
    InitialLifeSpan = 2.f;
}

// ===== Part 2 of 2 (as shown in the lesson) =====
void ABullet::BeginPlay()
{
    Super::BeginPlay();

    // Bind the overlap event:
    SphereCollider->OnComponentBeginOverlap
        .AddDynamic(this, &ABullet::OnHit);
}

// UFUNCTION required for AddDynamic delegates:
UFUNCTION()
void ABullet::OnHit(
    UPrimitiveComponent* Comp,
    AActor*              Other,
    UPrimitiveComponent* OtherComp,
    int32                OtherBodyIndex,
    bool                 bFromSweep,
    const FHitResult&    SweepResult)
{
    // Is it an enemy?
    AEnemy* Enemy = Cast<AEnemy>(Other);
    if (Enemy)
    {
        UGameplayStatics::ApplyDamage(
            Enemy, 1.f, GetInstigatorController(),
            this, nullptr);
        Destroy(); // destroy the bullet
    }
}