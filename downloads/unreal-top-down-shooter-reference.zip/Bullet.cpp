void ABullet::BeginPlay()
{
    Super::BeginPlay();

    // Bind the overlap event:
    SphereCollider->OnComponentBeginOverlap
        .AddDynamic(this, &ABullet::OnHit);
}

// UFUNCTION required for AddDynamic delegates:
UFUNCTION()
void ABullet::OnHit(
    UPrimitiveComponent* Comp,
    AActor*              Other,
    UPrimitiveComponent* OtherComp,
    int32                OtherBodyIndex,
    bool                 bFromSweep,
    const FHitResult&    SweepResult)
{
    // Is it an enemy?
    AEnemy* Enemy = Cast<AEnemy>(Other);
    if (Enemy)
    {
        UGameplayStatics::ApplyDamage(
            Enemy, 1.f, GetInstigatorController(),
            this, nullptr);
        Destroy(); // destroy the bullet
    }
}