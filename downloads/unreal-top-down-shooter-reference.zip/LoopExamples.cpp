// -- RANGE-FOR (read each element) ----------
for (AEnemy* E : ActiveEnemies)
{
    if (IsValid(E)) E->Tick(DeltaTime);
}

// -- INDEX-FOR (safe removal while iterating) -
for (int32 i = ActiveEnemies.Num()-1; i >= 0; --i)
{
    if (!IsValid(ActiveEnemies[i]))
        ActiveEnemies.RemoveAt(i); // safe backwards removal
}

// -- LAMBDA predicate ----------------------
AEnemy* Closest = *ActiveEnemies.FindByPredicate(
    [&](AEnemy* E)
    {
        return IsValid(E)
            && FVector::Dist(E->GetActorLocation(),
                            PlayerLoc) < 500.f;
    });

// -- while loop (wave condition) -----------
while (ActiveEnemies.Num() < MaxEnemiesOnScreen)
{
    SpawnEnemy();
}