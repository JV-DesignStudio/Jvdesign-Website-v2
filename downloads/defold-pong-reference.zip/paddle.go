# The paddle game object has two components:
components {
  id: "sprite"
  component: "/game.atc"
  position {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}