Pong Clone in Defold
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/defold-pong-workshop.html

Reference project files for this workshop.
These are the Defold files (.script, .go, .collection and so on) shown step by step
in the lesson. Create the project and game objects as the steps describe, then
attach each script to the matching component.

Files:
- paddle.go
- paddle.script
- ball.script
- paddle2.script
- gui.script

How to use:
1. Create the Defold project and game objects exactly as the workshop steps describe.
2. Create each script with the same name and paste the code in.
3. Stuck? Compare your file to the reference here.
