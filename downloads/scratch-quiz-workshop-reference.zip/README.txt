Know It All! Build a Quiz Game in Scratch
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/scratch-quiz-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Know It All! Build a Quiz Game in Scratch

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Write your questions
- Choose a topic together something your child is passionate about works best.
- Write 10 questions with one correct answer each. Keep answers short (one word or a small number works best).
- Example: "What is the fastest land animal? (cheetah)" or "How many legs does a spider have? (8)".
- Once you have 10 questions written down, open scratch.mit.edu and start a new project. Name it "[Topic] Quiz".
- Click the Stage and choose a backdrop that fits your theme. (Space quiz? Pick "Stars". Animals? Pick "Savanna".)
- Delete the Scratch Cat. Click Choose a Sprite and pick a character who will be your quiz host. Add it to the stage.
- Size it to about 80 and drag it to the left side of the stage.
- This sprite will use say blocks to ask questions and give feedback.
- Click Variables → Make a Variable. Create: Score, QuestionNumber, and TimeLeft.
- Keep Score and QuestionNumber checked (visible on stage). Uncheck TimeLeft for now we'll display it differently.
- You'll see the Score and QuestionNumber displays appear on the stage. Drag them to tidy positions.
- Select your quiz host sprite. Drag in "when 🏳 clicked".
- Add: set Score to 0, set QuestionNumber to 1.
- Add Sensing → "ask [What is your first question?] and wait" replace the text with your actual Question 1.
- Add an "if / else" block. For the condition: Operators → "answer = [correct answer]".
- In the if branch: say [✅ Correct!] for 1 second → change Score by 1.
- In the else branch: say (join [❌ Wrong! The answer was ] [correct answer]) for 2 seconds.
- After the if/else: change QuestionNumber by 1.
- Beneath question 1 in the same script, add ask [Question 2] and wait, fill in your second question.
- Add the same if answer = correct else wrong blocks, changing the question text and correct answer.
- Add change QuestionNumber by 1 again at the end.
- Repeat for all 10 questions. You can right-click on a block group and Duplicate it to save time, then just change the question text and answer.
- Create a new sprite (paint a simple rectangle) called TimerBar. Give it a bright colour. Position it at the top of the stage, wide and short.
- Check the TimeLeft variable on stage (tick it in Variables panel). Drag it to sit near the timer bar.
- Before each ask block in your quiz script, add: set TimeLeft to 15.
- In the TimerBar sprite, add a separate script: "when 🏳 clicked → forever → if TimeLeft > 0 then wait 1 second → change TimeLeft by -1 → end".
- In the TimerBar sprite, add: "forever → set size to ((TimeLeft ÷ 15) × 100) %" so the bar shrinks from 100% to 0% as time runs out.
- Click your quiz host sprite. Click the Sounds tab at the top.
- Click Choose a Sound (speaker icon). Search for "Cheer" or "Trumpet" add it as your correct-answer sound.
- Search for "Buzz Whir" or "Lose", add it as your wrong-answer sound.
- Go back to the Code tab. In every correct if-branch, add Sound → "play sound [Cheer] until done".
- In every wrong else-branch, add "play sound [Buzz Whir] until done".
- After question 10's if/else block, add: say (join [Quiz Over! You scored ] (join (Score) [ out of 10!])) for 5 seconds.
- Add extra messages based on score. Use "if Score = 10 then say [Perfect Score! Amazing! 🌟] for 3 seconds".
- Add another: "if Score ≥ 7 then say [Great job! 🎉] for 3 seconds".
- And: "if Score < 5 then say [Keep practising! 💪] for 3 seconds".
- End with Control → "stop all".
- Press the Green Flag and answer all 10 questions.
- Check: does the score count up correctly? Does the timer reset each question? Do sounds play?
- If any answers aren't being detected, check the spelling answers are case-sensitive. "Cheetah" won't match "cheetah"!
- Click File → Save now then Share. Send the link to family and challenge them to beat your score!
