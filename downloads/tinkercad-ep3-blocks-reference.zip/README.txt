Magnetic Building Blocks
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/tinkercad-ep3-blocks.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Magnetic Building Blocks

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Get started
- Log in to tinkercad.com, click Create → 3D Design
- Rename the project "My Magnetic Blocks"
- We're designing 25mm cubes, small enough to handle easily, big enough for 6mm magnets
- Drag a Box from the Shapes Panel onto the workplane
- Resize it to exactly 25mm x 25mm x 25mm, a perfect cube
- 25 mm 25 mm 25 mm N 6 mm magnet (for scale) A PERFECT 25 MM CUBE All three numbers must match: 25 ✨ 25 ✨ 25. Click each white handle and type 25. About the size of a big dice, roomy enough inside for the little 6 mm magnets. 💡25mm is about 1 inch, a great size for building blocks that are easy for kids to handle. 🧠 Knowledge Check +15 XP Why is 25mm a good size for building blocks? ASmall enough to handle, big enough to fit magnets inside BIt's the only size TinkerCAD supports CMagnets only come in 25mm sizes Check Answer ✅ Correct! Next Step → 2 🔲 Round the Edges Add a slight radius to make the blocks comfortable to hold Locked 🎯 Goal for this stepRound the cube edges with a 2mm radius for comfort and safety. Round those edges Select the cube and look at the Shape Properties panel
- Find the "Radius" or "Bevel" option
- Set the radius to 2mm, the edges become slightly rounded
- This makes the blocks much more comfortable to hold and safer for small hands
- Rotate the view to check all edges are evenly rounded
- The block should look like a slightly rounded cube, not a sphere!

## Create the magnet holes
- Drag a Cylinder from the Shapes Panel onto the workplane
- Resize it to 6.2mm diameter (6.2mm x 6.2mm) and 3.2mm height
- Wait, why 6.2mm and not 6mm? We'll learn why in the next step!
- Change the cylinder to a "Hole" shape (click Hole in the top-right)
- Position the hole cylinder on the top face of the cube, centered
- Use Align (select both shapes, press L) to center the hole perfectly on the top face
- Make sure the hole goes 3.2mm into the cube, it should sit flush with the surface
- 6.2 mm wide 3.2 mm deep set to "Hole", then Align to centre it on the face MAGNET HOLE · TOP FACE The hole sits flush with the top, sinking 3.2 mm down into the cube. To sink it, select the hole cylinder and drag the little cone handle above it downward, or type the height position directly. ✅Checkpoint: orbit around the cube. The striped cylinder should be swallowed by the top face with nothing poking above the surface. If you can see stripes floating in the air, it has not been lowered into the cube. ✏️ Fill in the Blanks +15 XP The magnet hole is mm in diameter and mm deep. ✏️ Check Answers 🧠 Knowledge Check +15 XP How do you position the hole exactly in the center of a face? AEstimate by eye BUse the Align tool to center on both X and Y axes CType coordinates manually Check Answer ✅ Correct! Next Step → 4 📏 Learn About Tolerances Why 6.2mm not 6mm for a 6mm magnet? Locked 🎯 Goal for this stepUnderstand why 3D printed holes need to be slightly larger than the object they hold. 👨‍👧Parent note: This is a real engineering concept! Tolerances are used in every manufactured product. This step teaches why precision matters. Understanding tolerances Our magnets are exactly 6mm in diameter. So why did we make the hole 6.2mm?
- 3D printers aren't perfectly precise, each layer of plastic is slightly wider than designed
- This means a 6mm hole would actually print slightly smaller, maybe 5.8mm
- A 5.8mm hole is too tight for a 6mm magnet, it won't fit!
- By designing the hole at 6.2mm, it prints at about 6.0-6.1mm, a snug press-fit
- This 0.2mm extra is called a "tolerance", the small gap that accounts for printer imprecision
- Professional engineers use tolerances in everything, from car parts to phone cases!
- the hole is drawn 6.2 mm (dashed circle) 0.2 mm breathing room = the "tolerance". The printer shrinks holes slightly, so the printed hole ends up ~6.05 mm: a snug press-fit for the magnet. (gap hugely exaggerated so you can see it) Design the hole 0.2 mm bigger than the magnet. Printers squeeze holes slightly smaller than drawn, so a 6.2 mm hole prints at about the perfect snug size for a 6 mm magnet. 💡The standard tolerance for press-fit holes in 3D printing is 0.1-0.3mm larger than the object. 0.2mm works well for most printers. ⚡ True or False? +15 XP "A 3D printed hole usually comes out slightly smaller than designed." TrueFalse "Tolerance means making things exactly the right size." TrueFalse "0.2mm tolerance means making the hole 0.2mm larger than the magnet." TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP Why do we design the hole at 6.2mm for a 6mm magnet? ABecause 6.2 is a rounder number BBecause magnets expand when warm CBecause 3D printers aren't perfectly precise, so the hole will shrink slightly when printed Check Answer ✅ Correct! Next Step → 5 ⊕ Align Holes on Each Face Use the Align tool to center holes perfectly Locked 🎯 Goal for this stepAdd magnet holes to multiple faces of the cube using Align. Add holes to more faces We currently have one hole on the top face. Let's add holes to more faces
- Duplicate the hole cylinder (Ctrl+D)
- Rotate the duplicate 90 degrees so it faces a different direction (use the rotation handles)
- Use Align to center it on the front face of the cube
- Repeat: Ctrl+D, rotate 90°, Align to center on the right face
- For a basic set, add holes on the top, front, and right faces (3 holes total)
- This lets blocks connect on 3 of their 6 faces
- 1 · top 2 · front 3 · right 3 MAGNET HOLES · 3 FACES Duplicate, rotate 90°, Align, repeat. Each copy of the hole cylinder gets rotated to face out of a different side, then centred on that face with Align. Three holes lets blocks connect three ways. 💡For advanced builders, you can add holes on all 6 faces. But 3 faces is plenty to start with, it keeps the block strong. 🔢 Put It In Order +15 XP Click these steps in the correct order to add holes to multiple faces: Rotate the duplicate 90 degrees Duplicate the hole cylinder with Ctrl+D Use Align to center on the face 🔍 Check Order↺ Reset 🧠 Knowledge Check +15 XP Why do we only put magnet holes on 3 faces instead of all 6? ATinkerCAD only allows 3 holes BIt keeps the block structurally strong while still allowing connections CMagnets don't work on all faces Check Answer ✅ Correct! Next Step → 6 🪞 Duplicate & Mirror the Block Create a matching block with opposite magnet polarity Locked 🎯 Goal for this stepDuplicate the block and understand why magnets need opposite polarity to attract. Duplicate and understand polarity Before grouping, let's understand polarity: magnets have North and South poles
- North attracts South, but North repels North. So adjacent blocks need opposite orientations
- Select all shapes of your first block (cube + holes). Group them (Ctrl+G)
- Press Ctrl+D to duplicate the entire grouped block
- Move the copy to the right, leaving space between them
- The hole positions are identical, when you insert magnets, you'll put them in with opposite poles facing out
- Label your blocks mentally: Block A has North poles facing out, Block B has South poles facing out

## Build pegs and sockets
- Create a new Cylinder: 5mm diameter, 4mm tall, this is the connector peg
- Position it on the top face of Block A, centered (use Align)
- Now create the matching socket: another Cylinder, 5.2mm diameter (tolerance!), 4.2mm deep
- Change the socket cylinder to a Hole shape
- Position the socket hole on the bottom face of Block B, centered
- When Block A sits on top of Block B, the peg fits snugly into the socket
- Group each block with its peg or socket (select block + connector, Ctrl+G)
- peg · 5 mm wide Block B socket · 5.2 mm wide (0.2 mm tolerance again!) Peg on top of A, socket in the bottom of B. Same tolerance trick as the magnets: the socket is 0.2 mm wider than the peg so they click together instead of jamming. ✏️ Fill in the Blanks +15 XP The peg is mm in diameter, and the socket is mm, the extra 0.2mm is the . ✏️ Check Answers 🧠 Knowledge Check +15 XP What is the purpose of the connector peg and socket? AJust decoration BTo hold the magnets in place CTo physically interlock blocks for stacking, even without magnets Check Answer ✅ Correct! Next Step → 8 🧪 Test the Fit Place blocks next to each other to check alignment Locked 🎯 Goal for this stepPosition blocks adjacent and stacked to verify the design works. Test your design Move Block A next to Block B so their magnet-hole faces touch
- Check that the holes line up, the magnets would sit face-to-face
- Now stack Block A on top of Block B
- Check that the peg from Block A lines up with the socket in Block B
- Use the Align tool to verify the peg is centered over the socket
- If anything is misaligned, ungroup (Ctrl+Shift+G), adjust, and regroup
- ✓ holes on the same line STACKED ✓ peg dead centre over the socket Two quick checks before exporting: put the blocks side by side (magnet holes should sit on one straight line), then stack them (the peg should be exactly over the socket). Fix any misalignment with Align. 💡In TinkerCAD, you can't actually test magnetic force, but visually confirming alignment ensures your printed blocks will connect properly. 🧠 Knowledge Check +15 XP How do you ungroup shapes that have been grouped? APress Delete BPress Ctrl+Shift+G CClick the Hole button Check Answer ✅ Correct! Next Step → 9 🎨 Add Colour Coding Use different colours for different block types Locked 🎯 Goal for this stepApply colours to distinguish block types visually. Colour your blocks Select Block A. In the Shape Properties panel, click the colour swatch
- Choose a bright colour, red, blue, green, or yellow work great
- Select Block B and choose a different colour
- You could create a colour system: red = 2 magnets, blue = 3 magnets, green = peg blocks
- Colour coding helps builders know which blocks connect where
- Try creating a third block in a new colour with a different configuration

## Export and print settings
- Important: export each block as a separate STL file, not all together
- Select Block A only. Click Export → STL. Save as "block-A.stl"
- Select Block B only. Click Export → STL. Save as "block-B.stl"
- Print orientation matters: lay each block on its largest flat face
- This means the magnet holes on top/bottom faces print vertically, they'll be the most accurate
- Recommended settings: 0.2mm layer height, 40% infill (blocks need to be sturdy!), PLA material
- After printing, press 6mm magnets into the 6.2mm holes, they should click in with a satisfying snap!
