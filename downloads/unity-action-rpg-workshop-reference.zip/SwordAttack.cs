using UnityEngine;
using System.Collections;

public class SwordAttack : MonoBehaviour
{
    public GameObject hitbox;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            StartCoroutine(Swing());
    }

    IEnumerator Swing()
    {
        hitbox.SetActive(true);
        yield return new WaitForSeconds(0.15f);
        hitbox.SetActive(false);
    }
}