public IEnumerator Hurt(int dmg, Vector2 knockDir)
{
    if (invincible) yield break;
    hp -= dmg;
    UpdateHeartsUI();
    if (hp <= 0) { GameOver(); yield break; }

    invincible = true;
    for (int i = 0; i < 6; i++)     // flash 6 times
    {
        sprite.enabled = !sprite.enabled;
        yield return new WaitForSeconds(0.12f);
    }
    sprite.enabled = true;
    invincible = false;
}