Adventure Calls! Unity Action RPG
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/unity-action-rpg-workshop.html

Reference project files for this workshop.
These are the finished code files shown step by step in the lesson, so you can
compare your own version or copy a section you are stuck on.

Files:
- PlayerMove.cs
- PlayerMove.cs (additions).txt
- SwordAttack.cs
- Enemy.cs
- PlayerHealth.cs
- Door.cs

How to use:
1. Unzip this folder somewhere easy to find.
2. Follow the workshop steps and type the code yourself.
3. Stuck? Open the matching file here and compare it line by line.
4. Every code block on the workshop page also has a Copy button.
