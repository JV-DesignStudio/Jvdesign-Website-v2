using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int hp = 3;
    public float speed = 2.2f, aggroRange = 4f;
    Transform player;
    Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void FixedUpdate()
    {
        float dist = Vector2.Distance(transform.position, player.position);
        if (dist < aggroRange)
            rb.linearVelocity = (player.position - transform.position)
                                .normalized * speed;
        else
            rb.linearVelocity = Vector2.zero;
    }

    public void TakeDamage(int amount, Vector2 fromDirection)
    {
        hp -= amount;
        rb.AddForce(fromDirection * 8f, ForceMode2D.Impulse);
        if (hp <= 0) Destroy(gameObject);
    }
}