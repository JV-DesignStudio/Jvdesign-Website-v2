using UnityEngine;

public class PaddleMouse : MonoBehaviour
{
    void Update()
    {
        Vector3 world = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        transform.position = new Vector3(
            Mathf.Clamp(world.x, -7f, 7f),
            -4.2f,
            0f);
    }
}