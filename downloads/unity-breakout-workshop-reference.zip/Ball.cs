using UnityEngine;

public class Ball : MonoBehaviour
{
    public float speed = 6f;
    Rigidbody2D rb;

    void OnCollisionEnter2D(Collision2D hit)
    {
        Brick brick = hit.gameObject.GetComponent<Brick>();
        if (brick != null)
        {
            GameManager.Instance.AddScore(brick.points);
            Destroy(brick.gameObject);
        }

        if (hit.gameObject.CompareTag("Paddle"))
        {
            float offset = transform.position.x - hit.transform.position.x;
            Vector2 dir = new Vector2(offset * 1.2f, 1f).normalized;
            rb.linearVelocity = dir * speed;
        }
    }
}