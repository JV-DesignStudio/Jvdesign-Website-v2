using UnityEngine;

public class WallBuilder : MonoBehaviour
{
    public Brick brickPrefab;
    public Color[] rowColors = new Color[5];

    void Start()
    {
        for (int row = 0; row < 5; row++)
        {
            for (int col = 0; col < 10; col++)
            {
                Vector3 pos = new Vector3(-6.75f + col * 1.5f,
                                           4f - row * 0.6f, 0f);
                Brick b = Instantiate(brickPrefab, pos, Quaternion.identity);
                b.SetRow(row, rowColors[row]);
                b.transform.parent = transform;   // tidy hierarchy
            }
        }
    }
}