using UnityEngine;

public class Brick : MonoBehaviour
{
    public int points = 10;

    public void SetRow(int row, Color color)
    {
        points = (5 - row) * 10;
        GetComponent<SpriteRenderer>().color = color;
    }
}