# ===== Part 1 of 6 (as shown in the lesson) =====
import pygame
pygame.init()

screen = pygame.display.set_mode((800, 480))
pygame.display.set_caption("My Python Game")
clock = pygame.time.Clock()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((25, 30, 60))
    pygame.display.flip()
    clock.tick(60)          # 60 frames per second

pygame.quit()

# ===== Part 2 of 6 (as shown in the lesson) =====
basket = pygame.Rect(370, 430, 90, 26)
speed = 7

# inside the while loop, after event handling:
keys = pygame.key.get_pressed()
if keys[pygame.K_LEFT]:
    basket.x -= speed
if keys[pygame.K_RIGHT]:
    basket.x += speed
basket.x = max(0, min(800 - basket.width, basket.x))

screen.fill((25, 30, 60))
pygame.draw.rect(screen, (255, 119, 0), basket)
pygame.display.flip()

# ===== Part 3 of 6 (as shown in the lesson) =====
import random

fruit = pygame.Rect(random.randint(20, 760), -30, 24, 24)
fall_speed = 4

# inside the loop:
fruit.y += fall_speed
if fruit.y > 480:
    fruit.y = -30
    fruit.x = random.randint(20, 760)

pygame.draw.ellipse(screen, (248, 113, 113), fruit)

# ===== Part 4 of 6 (as shown in the lesson) =====
score = 0
font = pygame.font.Font(None, 36)

# inside the loop:
if basket.colliderect(fruit):
    score += 1
    fruit.y = -30
    fruit.x = random.randint(20, 760)

text = font.render(f"Score: {score}", True, (255, 255, 255))
screen.blit(text, (16, 12))

# ===== Part 5 of 6 (as shown in the lesson) =====
lives = 3

# replace the bottom check:
if fruit.y > 480:
    lives -= 1
    fruit.y = -30
    fruit.x = random.randint(20, 760)

fall_speed = 4 + score // 5

hearts = font.render("?" * lives, True, (248, 113, 113))
screen.blit(hearts, (700, 12))

# ===== Part 6 of 6 (as shown in the lesson) =====
game_over = False
big_font = pygame.font.Font(None, 72)

# in the event loop:
if event.type == pygame.KEYDOWN and event.key == pygame.K_r and game_over:
    score, lives, game_over = 0, 3, False
    fruit.y = -30

# update only while playing:
if not game_over:
    # ... all movement / catching code ...
    if lives == 0:
        game_over = True

if game_over:
    msg = big_font.render("GAME OVER", True, (255, 209, 102))
    screen.blit(msg, (240, 190))