game_over = False
big_font = pygame.font.Font(None, 72)

# in the event loop:
if event.type == pygame.KEYDOWN and event.key == pygame.K_r and game_over:
    score, lives, game_over = 0, 3, False
    fruit.y = -30

# update only while playing:
if not game_over:
    # ... all movement / catching code ...
    if lives == 0:
        game_over = True

if game_over:
    msg = big_font.render("GAME OVER", True, (255, 209, 102))
    screen.blit(msg, (240, 190))