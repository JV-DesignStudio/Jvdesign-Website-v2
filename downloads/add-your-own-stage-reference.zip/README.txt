Add Your Own Stage to MUGEN Beginner's Lesson
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/add-your-own-stage.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Add Your Own Stage to MUGEN Beginner's Lesson

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- A folder inside MUGEN/stages/
- A .def file (the config, plain text)
- A .sff file (your bundled artwork)
- One line added to MUGEN/data/select.def so MUGEN knows it exists
- my-first-stage.def, the config file, fully commented in plain English
- my-first-stage-bg.png, a placeholder background to replace later
- my-first-stage-torch.png, a 3-frame animated torch sprite sheet
- Open Fighter Factory 3 ? File ? New ? Stage
- Click the Sprites tab on the left
- Click Add and select my-first-stage-bg.png
- In the Group/Image fields at the bottom, set Group = 0, Image = 0
- Repeat for each torch frame: Group = 1, Image = 0, 1, 2 in turn
- File ? Save As ? save as my-first-stage.sff in the same folder as your .def
- delta = 0, 0, doesn't move at all. Use for the sky.
- delta = 0.5, 0.5, half speed. Use for distant mountains.
- delta = 1, 1, exactly matches the camera. Use for the floor.
- delta = 1.5, 1.5, faster than the camera. Use for foreground objects.
- Inside MUGEN/stages/, create a new folder called myfirststage
- Move your my-first-stage.def and my-first-stage.sff into that folder
- Open MUGEN/data/select.def in Notepad. Scroll down to [ExtraStages] and add a new line: stages/myfirststage/my-first-stage.def
- Save. Run mugen.exe, pick VS mode, and your stage will appear in the stage select screen!
