pico-8 cartridge // http://www.pico-8.com
version 41
__lua__
-- dungeon.p8  JVDesignStudio
function _init()
  g=16
  rooms={
    {
      {1,1,1,1,1,1,1,1},
      {1,0,0,0,0,0,0,1},
      {1,0,1,0,0,1,0,1},
      {1,0,0,0,0,0,0,2},
      {1,0,0,0,0,0,0,1},
      {1,0,1,0,0,1,0,1},
      {1,0,0,0,0,0,0,1},
      {1,1,1,1,1,1,1,1}
    },
    {
      {1,1,1,1,1,1,1,1},
      {1,0,0,0,0,0,0,1},
      {1,0,1,1,0,1,0,1},
      {1,0,0,0,0,0,0,2},
      {1,1,0,1,1,0,1,1},
      {1,0,0,0,0,0,0,1},
      {1,0,1,0,0,1,0,1},
      {1,1,1,1,1,1,1,1}
    }
  }
  cur_room=1
  room=rooms[cur_room]
  px=2 py=2
  hp=3
  score=0
  invincible=0
  facing_dx=1 facing_dy=0
  enemies={}
  add(enemies,{x=5,y=5,hp=1,timer=0})
  game_over=false
end

function draw_room()
  for y=1,8 do
    for x=1,8 do
      local t=room[y][x]
      local col=0
      if t==1 then col=5 end
      if t==2 then col=12 end
      rectfill((x-1)*g,(y-1)*g,x*g-1,y*g-1,col)
    end
  end
end

function attack()
  sfx(1)
  for e in all(enemies) do
    if e.x==px+facing_dx and e.y==py+facing_dy then
      e.hp=e.hp-1
      if e.hp<=0 then
        del(enemies,e)
        score=score+10
      end
    end
  end
end

function _update()
  if game_over then
    if btnp(4) then _init() end
    return
  end
  if invincible>0 then invincible=invincible-1 end
  nx=px ny=py
  if btnp(0) then nx=nx-1 facing_dx=-1 facing_dy=0 end
  if btnp(1) then nx=nx+1 facing_dx=1 facing_dy=0 end
  if btnp(2) then ny=ny-1 facing_dx=0 facing_dy=-1 end
  if btnp(3) then ny=ny+1 facing_dx=0 facing_dy=1 end
  if nx>=1 and nx<=8 and ny>=1 and ny<=8 then
    local t=room[ny][nx]
    if t==0 then
      px=nx py=ny
    elseif t==2 then
      cur_room=cur_room+1
      if cur_room>#rooms then cur_room=1 end
      room=rooms[cur_room]
      px=2 py=2
      enemies={}
      add(enemies,{x=6,y=6,hp=1,timer=0})
    end
  end
  if btnp(4) then attack() end
  for e in all(enemies) do
    e.timer=e.timer+1
    if e.timer>=15 then
      e.timer=0
      local dir=flr(rnd(4))
      local dxs={0,0,-1,1}
      local dys={-1,1,0,0}
      local ex=e.x+dxs[dir+1]
      local ey=e.y+dys[dir+1]
      if ex>=1 and ex<=8 and ey>=1 and ey<=8 and room[ey][ex]==0 then
        e.x=ex e.y=ey
      end
    end
    if e.x==px and e.y==py and invincible==0 then
      hp=hp-1
      invincible=30
      sfx(0)
      if hp<=0 then game_over=true end
    end
  end
end

function _draw()
  cls(0)
  draw_room()
  for e in all(enemies) do
    rectfill((e.x-1)*g+3,(e.y-1)*g+3,e.x*g-4,e.y*g-4,8)
  end
  if invincible==0 or flr(time()*10)%2==0 then
    rectfill((px-1)*g+2,(py-1)*g+2,px*g-3,py*g-3,11)
  end
  for i=1,hp do
    rectfill(2+i*10,122,9+i*10,126,8)
  end
  print("score "..score,2,2,7)
  if game_over then
    print("game over",38,58,8)
    print("press z",48,68,6)
  end
end
