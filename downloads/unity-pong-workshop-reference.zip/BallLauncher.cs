using UnityEngine;

public class BallLauncher : MonoBehaviour
{
    public float speed = 6f;
    Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        Launch();
    }

    public void Launch()
    {
        float dirX = Random.value < 0.5f ? -1f : 1f;
        float dirY = Random.Range(-0.6f, 0.6f);
        rb.linearVelocity = new Vector2(dirX, dirY).normalized * speed;
    }
}