using UnityEngine;

public class GoalZone : MonoBehaviour
{
    public GameManager manager;
    public bool isLeftGoal;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Ball"))
        {
            manager.ScorePoint(isLeftGoal);
            other.transform.position = Vector3.zero;
            other.GetComponent<BallLauncher>().Launch();
        }
    }
}