using UnityEngine;

public class AIPaddle : MonoBehaviour
{
    public Transform ball;
    public float speed = 5f;       // slower than the player!
    public float deadZone = 0.4f;

    void Update()
    {
        float diff = ball.position.y - transform.position.y;
        if (Mathf.Abs(diff) > deadZone)
        {
            Vector3 pos = transform.position;
            pos.y += Mathf.Sign(diff) * speed * Time.deltaTime;
            pos.y = Mathf.Clamp(pos.y, -3.6f, 3.6f);
            transform.position = pos;
        }
    }
}