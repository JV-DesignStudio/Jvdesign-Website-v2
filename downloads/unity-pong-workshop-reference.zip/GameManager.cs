using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public TMP_Text leftText, rightText, winnerText;
    int leftScore, rightScore;

    public void ScorePoint(bool leftGoalWasHit)
    {
        if (leftGoalWasHit) rightScore++;
        else                leftScore++;

        leftText.text  = leftScore.ToString();
        rightText.text = rightScore.ToString();

        if (leftScore == 7 || rightScore == 7)
        {
            winnerText.text = (leftScore == 7 ? "LEFT" : "RIGHT")
                              + " PLAYER WINS!";
            winnerText.gameObject.SetActive(true);
            Time.timeScale = 0f;      // freeze the game
        }
    }
}