My First Defold Game - starter project

1. Install the free Defold editor from https://defold.com/download/
2. Unzip this folder.
3. In Defold choose File > Open Project and pick game.project.
4. Press F5 (or Build > Build and Launch) to preview.
5. Open main/main.script and look for:
   print("Game initialized!")
   That line should appear in the console.

If the project will not open, open the Defold cheat sheet:
https://jvdesignstudio.co.uk/tools/defold-cheatsheet.html
