Castle Builder Design Your Own Medieval Fortress
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/castle-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Castle Builder Design Your Own Medieval Fortress

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 , IDENTITY - Name Your Castle
- Every great castle has a name. Ironhold. Stormreach. The Dun Cow. Names carry history, legend, and fear. What will your fortress be called?

## STEP 02 , FORTIFICATION - Wall Height
- How tall are your castle walls? Taller walls are harder to scale with ladders and siege towers, but they need more stone and skilled masons.

## STEP 03 , RESILIENCE - Wall Thickness
- Thicker walls can withstand battering rams and catapults. But they cost more stone and reduce the interior courtyard space.

## STEP 04 , APPEARANCE - Wall Colour
- Choose the colour of your castle walls. Limestone is pale, granite is grey, sandstone is warm. The stone colour sets the entire mood of your fortress.

## STEP 05 , DETAIL - Stone Colour
- The secondary stone colour appears on decorative bands, window frames, and trim. A contrasting stone adds visual richness to the walls.

## STEP 06 , WATCHTOWERS - Towers
- Towers give height advantage for archers and lookouts. More towers mean more defensive positions. Round towers are harder to undermine; square towers are easier to build.

## STEP 07 , ENTRANCE - Gate Style
- The gate is the castle\

## STEP 08 , CRENELLATIONS - Battlements
- The notched pattern along the wall top is called crenellation. The solid parts (merlons) give cover, while the gaps (crenels) let archers fire.

## STEP 09 , STRONGHOLD - The Keep
- The keep is the innermost stronghold , the lord\

## STEP 10 , WATER DEFENCE - The Moat
- A moat surrounds the castle with water or a deep ditch, preventing miners from tunneling under the walls and stopping siege towers from reaching them.

## STEP 11 , CROSSING - Drawbridge
- A drawbridge spans the moat and can be raised to seal the gate. Counterweighted bridges could be raised by a single person with a windlass mechanism.

## STEP 12 , HERALDRY - Banners & Flags
- Banners identify the lord of the castle and display their coat of arms. Coloured flags flying from towers were a sign of wealth and power.

## STEP 13 , LIGHT - Windows
- Windows let light into the castle but also create weak points. Early windows were narrow arrow slits. Later castles had larger decorative windows.

## STEP 14 , ILLUMINATION - Torches
- Torches light the castle walls and courtyards. They can be lit in the final step for a dramatic fire-lit scene. Set the count and position now.

## STEP 15 , OVERVIEW - Stats & Preview
- Your castle is complete. Review its statistics , Defense, Grandeur, Comfort, and Accessibility , then head to the final step to light the torches.

## STEP 16 , ILLUMINATION - Light the Torches!
- The sun has set. Your garrison stands ready. It\
