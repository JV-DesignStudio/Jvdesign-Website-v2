Top-Down Adventure , Build an RPG in GDevelop
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gdevelop-adventure-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Top-Down Adventure , Build an RPG in GDevelop

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Create scene "World". Add Sprite "Player" (a character facing down).
- Add "Top-Down movement" behavior. This gives you arrow key movement automatically!
- In behaviors settings, set speed to 150.
- Add Sprite "Wall" (brown rectangles). Set "Solid" behavior on it.
- Place walls around the edges of the scene and create buildings/trees.
- The Top-Down behavior automatically collides with solid objects!
- Add Sprite "NPC_Villager". Place it in the world.
- Add event: Condition "Player is in collision with NPC_Villager" AND "Key pressed: E". Action: "Set DialogueText to "Hello traveler! Can you find my lost gem?".
- Add event: Condition "Key pressed: Escape" OR "Timer DialogueTimer > 3". Action: "Hide DialogueText".
- Add Sprite "Gem". Place several around the map.
- Create global variable "GemsCollected" = 0.
- Event: Condition "Player collides with Gem". Actions: "Delete Gem", "Change GemsCollected: Add 1".
- Create global variables: "Quest1Active" = 0, "Quest1Complete" = 0.
- Event: Talk to Villager AND Quest1Active = 0 → Set Quest1Active = 1, show "Quest started!"
- Event: GemsCollected >= 3 AND Quest1Active = 1 → Set Quest1Complete = 1, show "Quest complete!"
- Add Sprite "Zone_House". Make it semi-transparent. Set it as non-collidable.
- Event: Condition "Player is in collision with Zone_House". Action: "Change scene to HouseInterior".
- Create the HouseInterior scene with furniture objects and a "Back" door trigger.
- Create scene "HouseInterior". Add furniture sprites.
- Add a door trigger. Event: Player collides with Door → Change scene to World.
- Save the player's position before entering so they come back at the door.
- Add Text objects: "HealthText", "GemsText", "QuestText".
- Add "Always" events to update each text with the current variable values.
- Position them at the top of the screen. Use fixed camera or separate UI layer.
- Create scene "Victory" with congratulations text.
- Event: Condition "Variable Quest1Complete = 1". Action: "Change scene to Victory".
- Play the complete game from start to finish.
- Test: movement, wall collisions, NPC dialogue, gem collection, quest completion, scene transitions.
- Share it with friends and family!
