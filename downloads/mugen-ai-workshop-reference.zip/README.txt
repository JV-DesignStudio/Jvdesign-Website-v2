MUGEN AI Workshop JVDesignStudio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/mugen-ai-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: MUGEN AI Workshop JVDesignStudio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## What is MUGEN AI?
- Understand how CPU characters think in MUGEN

## The [AILevel] Header
- Add the foundation that tells MUGEN where your AI code starts

## Writing AI Triggers
- Write your first ChangeState action to make the AI attack

## Attack Priorities & Special Moves
- Layer your AI rules so supers, specials, and normals fire in the right order

## Defensive AI, Jumping & Blocking
- Make your AI react defensively and move around the stage

## Testing & Tuning Your AI
- Launch MUGEN, watch your AI fight, and fine-tune the Random values
