Marble Run
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/tinkercad-ep6-marblerun.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Marble Run

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Sketch your marble run
- Grab a piece of paper and draw a tall rectangle, this represents your back plate.
- Starting from the top, draw a funnel shape where the marble enters.
- Draw angled lines going left and right in a zigzag pattern, these are your ramps.
- Think about gravity, the marble needs to roll downhill on every ramp.
- Add a landing area at the bottom where the marble finishes its run.

## Build the back plate
- Open TinkerCAD and create a new design. Name it "Marble Run".
- Drag a Box shape onto the workplane from the shapes panel on the right.
- Click the box and use the white corner handles to resize it to approximately 100mm wide ✨ 150mm tall ✨ 5mm deep.
- You can type exact dimensions in the size fields that appear when you drag a handle. The back plate should be thin, only 5mm deep.
- This back plate is the foundation, all ramps and funnels will be attached to the front of it.
- 100 mm 150 mm side: 5 mm everything attaches to this A tall thin canvas. 100 ✨ 150 × 5 mm, like a postcard stood upright. All the ramps, tubes and funnels stick onto the front of it. 💡Hold Shift while dragging a corner to resize proportionally. You can also click a dimension number and type an exact value. ⚡ True or False? +15 XP The back plate holds all the ramps in place. TrueFalse The back plate should be thin (about 5mm deep). TrueFalse Marble runs don't need a back plate. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP What is the main purpose of the back plate? ATo make the marble run heavier BTo act as a ramp for the marble CTo provide a mounting surface for all the ramps and channels Check Answer ✅ Correct! Next Step → 3 📐 Build the First Ramp Create a channel shape and rotate it 15 degrees for a gentle slope Locked 🎯 Goal for this stepBuild your first ramp by resizing a box into a channel shape and rotating it to create a gentle downward slope. Create and angle the ramp Drag a new Box onto the workplane. This will become your first ramp.
- Resize it to approximately 60mm long ✨ 24mm wide ✨ 3mm tall, a flat, elongated shape.
- Look for the curved rotation handles around the shape, they appear as arcs near the corners.
- Grab the rotation handle and rotate the ramp by 15 degrees. You'll see the angle displayed as you rotate.
- Position the ramp near the top of the back plate, tilting downward to one side.
- FRONT VIEW · the marble rolls down the tilt, left to right 15° is the sweet spot: steep enough that the marble never stalls, gentle enough that it does not fly off the end. Watch the angle readout as you drag the rotation handle. 💡A 15-degree angle creates a gentle slope, steep enough for the marble to roll, but slow enough to be fun to watch! ✏️ Fill in the Blanks +15 XP To angle a ramp, you rotate it by degrees. The tilt direction should be so the marble rolls along it. ✏️ Check Answers 🧠 Knowledge Check +15 XP What angle creates a gentle slope for a marble run ramp? A90 degrees, straight down B15 degrees, a gentle tilt C0 degrees, completely flat Check Answer ✅ Correct! Next Step → 4 🧱 Add Walls to the Channel Place thin tall boxes along each side of the ramp to keep the marble on track Locked 🎯 Goal for this stepAdd two thin walls along each side of the ramp to create a channel that guides the marble. Build the channel walls Drag a new Box onto the workplane. This will become one wall of the channel.
- Resize it to be the same length as your ramp, but only 2mm thick and 10mm tall.
- Position it along one edge of the ramp, so it sits on top like a guardrail.
- Duplicate the wall (Ctrl+D) and move the copy to the other edge of the ramp.
- Select both walls and the ramp, then click Group (Ctrl+G) to combine them into one piece.
- 20 mm between the walls · marble is 16 mm · ✓ room to roll walls: 2 mm thick, 10 mm tall Walls turn a ramp into a channel. One guardrail on each long edge, grouped with the ramp. With the 24 mm ramp, the inside gap stays a marble-friendly 20 mm. 💡Without walls, the marble would roll off the side of the ramp! The walls create a channel that guides it along the path. 💻 Design Challenge +20 XP Fill in the blanks for the channel wall dimensions: Wall height = mm Wall thickness = mm 🔍 Check Design 💡 Hint: Walls need to be tall enough to stop the marble but thin enough to not waste material. 🧠 Knowledge Check +15 XP Why do ramps need walls on each side? ATo keep the marble on track and prevent it from rolling off the edge BTo make the ramp stronger CWalls are only decorative Check Answer ✅ Correct! Next Step → 5 🔽 Create a Funnel at the Top Build a cone and cylinder hole to make a funnel entry point Locked 🎯 Goal for this stepCreate a funnel shape at the top of the marble run where the marble enters and gets guided onto the first ramp. Build the funnel Drag a Cone shape onto the workplane. Resize it to about 30mm diameter ✨ 25mm tall.
- Now drag a Cylinder onto the workplane. Make it about 20mm diameter ✨ 30mm tall.
- Click the cylinder and change it to a Hole (click the "Hole" button in the inspector panel).
- Position the cylinder hole inside the centre of the cone, so it cuts through the middle.
- Select both the cone and the cylinder hole, then click Group (Ctrl+G). The hole cuts through the cone, creating a funnel!
- Position the funnel at the very top of your marble run, above the first ramp.
- CONE + CYLINDER HOLE Group FUNNEL · CUT AWAY marble drops in the crater, shoots out the bottom The cylinder hole must run all the way through the cone, top to bottom, before you Group. You end up with a volcano shape whose crater guides the marble onto ramp one. 💡The funnel makes it easy to drop the marble in, the wide top guides it down to the narrow opening and onto the first ramp. 🔢 Put It In Order +15 XP Click these steps in the correct order to create a funnel: Group the cone and cylinder hole together Place a cone shape on the workplane Position the funnel at the top of the marble run Add a cylinder hole inside the cone 🔍 Check Order↺ Reset 🧠 Knowledge Check +15 XP What is the purpose of the funnel at the top of the marble run? ATo make the marble spin BTo guide the marble from a wide opening down onto the first ramp CTo hold multiple marbles at once Check Answer ✅ Correct! Next Step → 6 ↔️ Connect Ramp Sections Alternate left-right zigzag ramps, each angled in the opposite direction Locked 🎯 Goal for this stepDuplicate your first ramp and arrange multiple ramps in a zigzag pattern, alternating the tilt direction. Build the zigzag Select your completed ramp (with walls) and press Ctrl+D to duplicate it.
- Move the duplicate below the first ramp and flip it, rotate it so it tilts in the opposite direction.
- The end of the first ramp should be directly above the start of the second ramp, so the marble drops from one to the next.
- Duplicate and flip again to create a third ramp below the second. Keep alternating!
- Aim for 4-5 ramps in total, forming a zigzag path from top to bottom.

## Build the drop tube
- Drag a Cylinder onto the workplane. Make it about 22mm diameter ✨ 40mm tall.
- Drag another Cylinder and make it 18mm diameter ✨ 45mm tall. Set it as a Hole.
- Centre the hole cylinder inside the solid cylinder. The hole must be slightly taller to cut through both ends.
- Group them (Ctrl+G) to create a hollow tube.
- Position the tube so its top opening is at the end of one ramp and its bottom opening leads to the next ramp below.
- CYLINDER + TALLER HOLE Group THE DROP SECTION top opening under a ramp end · bottom over the next ramp The hole is 5 mm taller than the tube on purpose, so it pokes out both ends and cuts a clean passage. 18 mm inner diameter gives the 16 mm marble a smooth fall. 🎉Drop sections add drama! The marble disappears into the tube and pops out below. Kids love this part! ⚡ True or False? +15 XP The tube's inner diameter must be bigger than the marble. TrueFalse Drops slow the marble down. TrueFalse Tubes are made by grouping two cylinders (one solid, one hole). TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP How do you create a hollow tube in TinkerCAD? AUse the tube shape from the library BPlace a smaller cylinder hole inside a larger cylinder, then group them CStretch a ring shape vertically Check Answer ✅ Correct! Next Step → 8 🛬 Create Landing Pads Add flat platforms at each level transition to catch the marble after drops Locked 🎯 Goal for this stepAdd flat landing pads at each level transition so the marble has a surface to land on after dropping from a tube or ramp. Build landing pads Drag a Box onto the workplane. Resize it to about 25 mm × 25 mm × 3mm, a small flat platform.
- Position it directly below a drop tube, so the marble lands on it after falling.
- Add walls on the sides that face open air, the marble shouldn't bounce off the pad!
- Make sure the landing pad connects to the next ramp, the marble needs to roll from the pad onto the ramp.
- Duplicate and position landing pads at every level transition in your marble run.
- wall on the open side, no bouncing away! 25 ✨ 25 × 3 mm pad · catches the drop, feeds the next ramp Every drop needs a catcher. The pad sits directly under the tube, has a wall on any side facing open air, and touches the next ramp so the marble rolls straight on. ✏️ Fill in the Blanks +15 XP A landing pad catches the marble after a . It connects the tube exit to the next . ✏️ Check Answers 🧠 Knowledge Check +15 XP What is the purpose of a landing pad? ATo make the marble bounce higher BTo slow the marble to a complete stop CTo catch the marble after a drop and guide it onto the next ramp Check Answer ✅ Correct! Next Step → 9 🎯️ Add Side Supports Build L-shaped brackets or triangle supports so the structure stands freely Locked 🎯 Goal for this stepAdd structural supports so the marble run can stand upright on its own without falling over. Build the supports Drag a Box onto the workplane. This will form the base of an L-shaped support.
- Resize it to about 20mm wide ✨ 40mm long ✨ 5mm tall, a flat foot.
- Add another box standing upright: 20mm wide ✨ 5mm deep ✨ 40mm tall. Position it at one end of the flat foot.
- Group both pieces to create an L-shaped bracket. Position it at the bottom edge of the back plate.
- Duplicate the support and place one on each side of the back plate for stability.
- SIDE VIEW L-bracket: flat foot + upright grouped, hugging the plate use TWO, one at each side edge, so the run stands up on its own The plate cannot balance on a 5 mm edge. Two L-brackets, one per side, act like bookends. The foot points forward, the upright glues flat against the plate. 💡The support should touch both the base (the surface it sits on) and the back plate, creating a stable triangle of force. 💻 Design Challenge +20 XP Fill in the blanks for structural support design: Support width = mm The support should touch both the and the back plate. 🔍 Check Design 💡 Hint: The support creates an L-shape connecting the flat surface to the vertical back plate. 🧠 Knowledge Check +15 XP Why does the marble run need side supports? ASo the structure can stand upright without falling over BTo make the marble go faster CTo add more ramps Check Answer ✅ Correct! Next Step → 10 📏 Test Marble Clearance Check that channels are wide enough for a 16mm marble to pass through Locked 🎯 Goal for this stepVerify that every channel, tube, and opening is wide enough for a standard 16mm marble to pass through smoothly. Check all clearances A standard marble is 16mm in diameter. All channels and tubes need to be at least 18mm wide.
- Use the Ruler tool in TinkerCAD (click the ruler icon on the right toolbar) to measure channel widths.
- Check the inner diameter of any tubes, it should be at least 18mm.
- Check the channel width between walls on every ramp, at least 18mm between the inside edges.
- Check the funnel opening at the bottom, wide enough for the marble to pass through.
- 18 mm minimum everywhere the marble goes ✓ 1 mm of daylight each side keeps it rolling smoothly Play quality inspector before exporting. Measure every channel, tube and funnel exit with the Ruler tool: anything under 18 mm WILL trap the marble on the printed model. 💡The extra 2mm clearance (18mm channel for a 16mm marble) accounts for 3D printing tolerances, printed parts are never perfectly exact. ✏️ Fill in the Blanks +15 XP A standard marble diameter is mm, so channels need a minimum width of mm. ✏️ Check Answers 🧠 Knowledge Check +15 XP Why should channels be 2mm wider than the marble? ATo allow tolerance for 3D printing imperfections BTo make the marble go faster CSo two marbles can fit side by side Check Answer ✅ Correct! Next Step → 11 🏛️ Add Decorative Elements Add arches, pillars, and a flag at the finish using various shapes Locked 🎯 Goal for this stepMake your marble run look amazing by adding decorative elements like arches, pillars, and a flag at the finish line. Decorate your marble run Create an arch: place a cylinder, add a cylinder hole halfway through it, and group. Position it over a ramp section.
- Add pillars: use thin, tall cylinders placed at the corners of the back plate.
- Create a flag: use a thin box (pole) with a small flat box (flag) at the top. Place it at the finish.
- Try adding small spheres as decorative balls along the edges.
- Make sure decorations don't block the marble path, they should be purely visual!

## Export and prepare for printing
- In TinkerCAD, click Export (top right). Choose .STL format and save the file.
- Open your slicer software (e.g., Cura, PrusaSlicer). Import the STL file.
- Your marble run has overhangs, the ramps stick out from the back plate with nothing underneath. These need support material.
- Enable Supports in your slicer settings. The slicer will automatically add temporary support structures under overhangs.
- Check the preview in your slicer, you'll see the supports highlighted in a different colour.
- After printing, carefully remove the support material by snapping or cutting it away.
