GML Shooter Trainer
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gml_shooter_trainer_project.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: GML Shooter Trainer

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Move Right
- Your ship is stuck. Write one line of code to move it right.\nIn GML-style code, x is the horizontal position. Adding to x moves right.

## Keyboard Input
- Moving on its own is no good. Now make the ship move only when you press the right arrow key.\nUse keyboard_check() it returns true if that key is held down.

## Move in All Directions
- One direction is not enough. Add all four arrow keys up, down, left, right.\nEach key changes a different axis: left/right = x, up/down = y.

## Change Your Speed
- The speed variable controls how fast you move.\nYou can change it! Try setting speed to different values at the top of your code.

## Shoot Bullets
- Dodging is not enough. Time to fight back.\nshoot() is a function it creates a bullet that flies upward from the player.\nCall it when the spacebar is pressed.

## Aim Your Shots
- Shooting straight up is limiting. shoot_at(x, y) fires a bullet toward a target position.\nTo aim at the nearest enemy, you need to find them first.

## Spawn Rate
- Enemies spawn on a timer. You can control the spawn rate lower = more enemies, faster.\nThe game gets harder over time automatically, but you set the starting difficulty.

## Understanding Collisions
- The game already handles bullet-enemy and enemy-player collisions for you.\nBut understanding how is important it is the same pattern used in every game engine.

## Health System
- You have 5 hearts. Each time an enemy touches you, you lose one.\nYou can change your max HP by setting G.maxHp and G.hp.

## Score System
- Score is tracked automatically 10 points per kill, bonus for tough enemies.\nThe score shows in the top-right. Now think about what makes a high score run.

## Enemy Types
- From this level, enemies come in three types:\n⭐ Normal standard speed, 1 HP\n⭐ Fast quick but fragile\n⭐ Tank slow but takes 4 hits and gives bonus score.\nYour strategy needs to adapt.

## Your Game!
- This is your final code. Everything you have learned movement, input, functions, aiming, spawn rate, health, score, enemy types is in your hands.\nTweak everything. Beat your high score. This is your game.
