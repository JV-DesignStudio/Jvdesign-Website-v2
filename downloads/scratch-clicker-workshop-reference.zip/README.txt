Click Frenzy! Build an Idle Clicker Game in Scratch
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/scratch-clicker-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Click Frenzy! Build an Idle Clicker Game in Scratch

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Open scratch.mit.edu, start a new project, name it "Click Frenzy". Delete the cat.
- Go to Variables ? Make a Variable. Create these one by one: Coins, CoinsPerClick, AutoEarner1, AutoEarner2, Multiplier.
- Keep Coins visible (ticked). Uncheck all others, we'll display them differently.
- Also create Upgrade1Cost, Upgrade2Cost, Upgrade3Cost, these will be the prices of upgrades.
- Click Paint to draw a new sprite. Draw a big circle in gold/yellow, about half the stage width. Add a coin symbol or star inside.
- Name the sprite CoinButton. Set its size to 150 and centre it on stage.
- In the Code tab, add: "when 🎮 clicked ? set Coins to 0 ? set CoinsPerClick to 1 ? set Multiplier to 1 ? set Upgrade1Cost to 10 ? set Upgrade2Cost to 50 ? set Upgrade3Cost to 200".
- Add a second event block: "when this sprite clicked ? change Coins by (CoinsPerClick - Multiplier)".
- Also add a bounce effect: "when this sprite clicked ? change size by (-10) ? wait 0.05 seconds ? change size by (10)".
- Click Paint to draw a new sprite. Draw a tall dark rectangle to fill the right third of the stage (roughly x: 120 to 240, full height). Use a dark colour like dark grey.
- Add white text labels in the costume: "UPGRADES" at the top. Name the sprite ShopPanel.
- In Code: "when 🎮 clicked ? go to x: 170 y: 0" to pin it to the right.
- Add a backdrop, choose something simple like "Blue Sky" or paint a gradient background.
- Paint a new sprite, a rounded rectangle button. Add text: "Better Click -?" and "Cost: 10". Name it Upgrade1.
- Position it in the top section of the shop panel: x: 170, y: 100.
- In the Code tab: "when 🎮 clicked ? go to x: 170 y: 100 ? forever ? if Coins = Upgrade1Cost then set colour effect to 0 else set colour effect to 25", this dims the button when you can't afford it.
- Add: "when this sprite clicked ? if Coins = Upgrade1Cost then change Coins by (-Upgrade1Cost) ? change CoinsPerClick by 1 ? change Upgrade1Cost by 10".
- Paint Upgrade2 button. Text: "Auto Clicker -", "Cost: 50". Position at x: 170, y: 30.
- Same affordability dimming script as Upgrade1 (copy and adjust).
- Buy script: "if Coins = Upgrade2Cost then change Coins by (0 - Upgrade2Cost) ? change AutoEarner1 by 1 ? change Upgrade2Cost by 50".
- Now create the auto-earn loop. Add a NEW script stack in Upgrade2: "when 🏳 clicked → forever → wait 1 second → change Coins by (AutoEarner1)".
- Paint Upgrade3 button. Text: "-2 Multiplier ?", "Cost: 200". Position at x: 170, y: -40.
- Same affordability dimming script.
- Buy script: "if Coins = Upgrade3Cost then change Coins by (0 - Upgrade3Cost) ? change Multiplier by 1 ? change Upgrade3Cost by 200".
- Paint a new sprite called StatsDisplay. Draw a dark rectangle for the left side of the stage. Position at x: -155, y: 0.
- In Code, add: "when 🎮 clicked ? forever ? switch costume to [blank] ? stamp", actually, use Looks ? say blocks instead.
- Simpler approach: tick the CoinsPerClick, AutoEarner1 and Multiplier variables in the Variables panel so they show on stage. Drag them to tidy positions below the coin counter.
- Right-click each variable display on stage and choose "large readout" for Coins, and "normal readout" for the others.
- Name the sprite CoinButton. Set its size to 150 and centre it on stage.
- Create a variable Milestone1 (hidden) so this only triggers once.
- Add more milestones at 5000 and 10000 for extra rewards, copy the same pattern.
- Paint a tiny sprite, a small gold circle with "+1" text. Name it CoinParticle. Hide it in the sprite panel (tick "hide" in properties).
- In CoinButton's click script, add: "create clone of [CoinParticle]".
- In CoinParticle's code: "when I start as a clone ? go to [CoinButton] ? show ? repeat 20 ? change y by 5 ? change ghost effect by 5 ? end ? delete this clone".
- Select CoinButton → Sounds tab → Choose a Sound. Add "Coin" or "Ding".
- In the click script, add "start sound [Coin]" (not "play until done", that would pause clicking!).
- Click the Stage → Sounds → add a fun upbeat loop like "Dance Around" or "Bossa Nova".
- Stage code: "when 🎮 clicked ? forever ? play sound [Dance Around] until done".
- Press Green Flag. Click until you can buy Upgrade 1 (10 coins). Buy it, notice each click earns more!
- Keep going until Upgrade 2 (50 coins). Buy the auto clicker, watch coins tick up on their own!
- Grind to 200 coins for the Multiplier. Notice the explosive growth after buying it.
- Check the 1000-coin milestone triggers. Does the floating +1 particle look good?
- Click File ? Save now then Share. Challenge a friend to reach 10,000 coins!
