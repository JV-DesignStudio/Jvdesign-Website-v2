My First Unreal Game Ep 1: Blueprint Basics
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/unreal-basics-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First Unreal Game Ep 1: Blueprint Basics

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Install the Epic Games Launcher, then Unreal Engine (latest 5.x) from its Library tab. It is big (~30 GB), start it downloading!
- New Project → Games → Third Person template, Blueprint, no starter content needed. You begin with a WORKING playable character, Unreal’s gift.
- Viewport flying: hold Right Mouse + WASD (Q/E for down/up), scroll to change fly speed.
- The panels: Outliner (everything in the level), Details (edit the selected thing, Unity’s Inspector), Content Drawer (Ctrl+Space, all assets).
- Press Play (or Alt+P) and run around with the mannequin. You are inside a AAA engine.
- Everything placed in a level is an Actor (Unity’s GameObject, roughly).
- Place basic shapes: the + button → Shapes → Cube/Cylinder. Move (W), Rotate (E), Scale (R), note: Unreal’s gizmo keys differ from Blender’s!
- Snap to grid (the magnet toggles, top-right of the viewport), build a small arena: floor, four walls, some pillars and ramps.
- Materials: drag any material from the Content Drawer onto a surface.
- Duplicate quickly: Alt+Drag a gizmo arrow clones as you pull. Build time drops 10×-.
- Content Drawer → right-click → Blueprint Class → Actor → name it BP_Coin. Double-click: the Blueprint editor opens.
- Add components: a Static Mesh (cylinder, squashed flat, gold material), component thinking again!
- The Event Graph is code as nodes: Event Tick (runs every frame) → drag off it → AddActorLocalRotation (Z = 2).
- White wires = execution order; coloured wires = data. That IS programming, visually.
- Compile, Save, drag BP_Coins into the arena. Play: they all spin.
- In BP_Coin add a Box Collision component around the mesh.
- Select it → Details → Events → + On Component Begin Overlap, a red event node appears (GameMaker’s collision event, Unreal-style).
- From Other Actor, drag → Cast To BP_ThirdPersonCharacter, "was it the player?" (the tag check / GetComponent-null-check of Unreal).
- Cast success → DestroyActor (self). Play and run through coins: collected!
- Add a pickup sound: PlaySoundAtLocation before the destroy (the template has sounds to borrow).
- Open the player Blueprint (BP_ThirdPersonCharacter). Add a variable: CoinCount, Integer, default 0.
- In BP_Coin’s overlap (after the successful cast): drag from the cast output → Get CoinCount → +1 → Set CoinCount. Variables read/write across Blueprints through references, the cast GAVE you the reference.
- HUD: create a Widget Blueprint (WBP_HUD) with a Text block. Bind its text to the player’s CoinCount (Create Binding → get player → get CoinCount → ToText).
- Show it: player’s Event BeginPlay → Create Widget (WBP_HUD) → Add to Viewport.
- Play: a live coin counter. You just built UI, data flow and events, no text code at all.
- The Branch node is Blueprint’s if-statement. After incrementing CoinCount: Branch, is CoinCount == 10 (an Equal node)?
- True → show a "YOU WIN!" widget + Open Level (reload for replay) after a 2-second Delay node.
- Level design pass with your arena: place 10 coins so collecting them TOURS the space, heights, behind pillars, up the ramps (bonus: the mannequin can jump!).
- Playtest: can a friend find all 10 without hints? Watch where they get lost; move coins accordingly. That is real level design iteration.
- Episode complete, the shooter awaits in Episode 2!
