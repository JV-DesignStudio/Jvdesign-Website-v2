# build_scene.py - Blender 4.x
# My First 3D Model Ep 7: Complete Scene
import bpy
import math

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Ground
bpy.ops.mesh.primitive_plane_add(size=30, location=(0, 0, 0))

# A ring of pillars
for i in range(8):
    angle = i * (2 * math.pi / 8)
    x, y = math.cos(angle) * 6, math.sin(angle) * 6
    bpy.ops.mesh.primitive_cylinder_add(radius=0.4, depth=3, location=(x, y, 1.5))

# A central monument
bpy.ops.mesh.primitive_cone_add(radius1=1.6, depth=4, location=(0, 0, 2))

# Sky-ish world colour
world = bpy.data.worlds["World"] if "World" in bpy.data.worlds else bpy.data.worlds.new("World")
bpy.context.scene.world = world
world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (0.35, 0.55, 0.85, 1)

# Lighting
bpy.ops.object.light_add(type='SUN', location=(6, -6, 12))
bpy.context.active_object.data.energy = 4.0

# Camera framing the monument
bpy.ops.object.camera_add(location=(12, -12, 7), rotation=(1.15, 0, 0.78))
bpy.context.scene.camera = bpy.context.active_object

print("Scene complete! Press F12 to render your finished model.")
