My First 3D Model Ep 7: Complete Scene
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/blender-scene-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First 3D Model Ep 7: Complete Scene

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Pick a one-line story: "My character waits at a lonely bus stop at dusk." A story makes a scene; objects alone make a screenshot.
- Collect 3-5 reference images (real bus stops, dusk photos, styles you love) into a folder. Every professional does this, imagination plus reference beats imagination alone.
- Thumbnail it: a 2-minute pencil scribble of the framing. Where is the character? Where does light come from?
- List the needed assets: character (done in Ep 2-4!), bench, sign, lamppost, ground, backdrop. Small list, big mood.
- Blocking = the whole scene as grey primitives: box bench, cylinder lamppost, plane ground, box backdrop buildings.
- Add the CAMERA NOW and compose with boxes. Composition is the hardest thing to fix later, so fix it first.
- Append your character: File ? Append ? your character-rigged.blend ? Object ? select the mesh + armature. Your Episode 2-4 work enters the scene!
- Pose the character to the story (sitting, slumped slightly, lonely, remember).
- Stare at the blocked frame. Move boxes until the frame FEELS right. Only then model.
- Replace each box using Episode 2 skills: bench (cubes + loop cuts), lamppost (cylinder + extrusions), sign (flat box + emission panel).
- Materials from Episode 5: worn wood nodes on the bench, metal on the post, glass on the lamp head.
- Set dressing, the small "life" details: a puddle (flat glossy plane), litter, a distant trash can. Imperfection reads as REAL.
- Keep polygons where the camera looks: detail the bench, keep the backdrop buildings as simple boxes with windows painted by emission strips. Camera-first economy!
- Turn on the camera-s Composition Guides (camera properties ? Viewport Display ? Thirds).
- Rule of thirds: put the character on a third-line intersection, not dead centre.
- Leading lines: angle the kerb/bench edges so they point AT the character, the eye follows lines.
- Depth layers: something close (foreground lamppost edge), the subject (mid), the backdrop (far). Three layers = instant depth.
- Add subtle Depth of Field: camera ? DOF on, focus on the character, f-stop 2.8, background melts away.
- Base: a dusk HDRI from Poly Haven, instant believable ambient.
- Practicals (lights that exist IN the scene): the lamppost gets a warm emission bulb + a matching warm Point light; the sign glows cool.
- The character needs a subtle rim light, a soft cool Area behind them (motivate it as "sky light").
- Mood check: warm pool of lamp light in a big cool dusk = cosy-in-the-lonely. Colour psychology doing the story-s work.
- Thin volumetric haze (density 0.01) so the lamp gets a gentle halo. Dusk complete.
- Final settings (Cycles): 1920×1080, samples 256 with Denoise ON (Render Properties ? Sampling), denoising lets modest samples look clean.
- F12. Make tea. Then compositor pass (Episode 6): gentle glare, teal-orange balance, vignette.
- Export PNG. Then the brave part: SHOW IT, family, friends, an art community. Feedback is how artists level up.
- Series wrap, you now hold: navigation, modelling, rigging, animation, materials, lighting, composition, rendering. That is the complete 3D pipeline.
- Final quiz below completes the entire series. Then go make the next scene, the one that is entirely YOUR idea. 🎮


--------------------------------------------------------------------
BONUS: BLENDER PYTHON BUILDER
--------------------------------------------------------------------
This pack also includes build_scene.py, a script that builds a "Complete Scene" setup for you.

How to run it:
1. Open Blender 4.x.
2. Go to the Scripting tab, click Open, and choose build_scene.py.
3. Click Run Script (the play button). The model appears in your scene.
4. Press F12 to render, or keep building on top of it.
