Pop-It Fidget
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/tinkercad-ep2-popit.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Pop-It Fidget

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Get started
- Log in to tinkercad.com (or create a free account if this is your first time).
- Click "Create" then "3D Design". A new empty workplane opens.
- Notice the blue grid on the workplane, the default grid size is 20mm.
- Rename your project by clicking "Untitled" at the top left, call it "My Pop-It Fidget".
- Take a moment to orbit the view (right-click drag) and zoom (scroll wheel) to get comfortable.

## Build the base
- In the Shapes Panel on the right, find "Box" under Basic Shapes (we'll round it).
- Actually, look for "Round Roof" or use a "Box", drag it onto the workplane.
- Click the shape to select it. Set the width to 80mm, the depth to 60mm, and the height to 4mm.
- Use the dimension boxes that appear when you click the white handles to type exact values.
- You should now have a flat, rectangular base plate sitting on the workplane.
- 4 mm THE BASE PLATE What you should see: a wide, flat slab, like a chocolate bar lying on the grid. Type the numbers into the dimension boxes: 80 wide, 60 deep, 4 tall. If yours looks like a tall tower, the 4 went into the wrong box. 💡A 4mm thick base gives enough material for the bubbles to push into while staying thin enough to feel satisfying when popped. ⚡ True or False? +15 XP A thicker base makes the pop-it harder to pop. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP What are the dimensions of the base plate? A60mm x 40mm x 8mm B100mm x 80mm x 4mm C80mm x 60mm x 4mm Check Answer ✅ Correct! Next Step → 3 🫧 Create One Bubble Use a half-sphere, 10mm diameter, for the first bubble Locked 🎯 Goal for this stepCreate a single bubble shape using a sphere, sized to 10mm diameter. Make the first bubble In the Shapes Panel, find the "Sphere" under Basic Shapes.
- Drag the sphere onto the workplane, placing it near (but not on) the base plate.
- Resize the sphere to 10mm x 10mm x 10mm, this gives a 10mm diameter bubble.
- We only need the top half, we'll position it so the bottom half sinks into the base plate later.
- This single bubble is the template we'll duplicate to create the full grid.
- 10 mm one bubble keep it OFF the plate for now Drop the sphere on empty grid, not on the plate. We will line everything up properly with the Align tool in step 7, so a rough position is fine here. 💡The sphere creates a nice rounded bubble shape, just like on a real pop-it toy! 🧠 Knowledge Check +15 XP Which shape do you use for a bubble? ACylinder BBox CSphere Check Answer ✅ Correct! Next Step → 4 📋 Duplicate a Row of 4 Bubbles Learn Ctrl+D to duplicate, space bubbles 15mm apart Locked 🎯 Goal for this stepUse the Duplicate feature to create a row of 4 bubbles, each spaced 15mm apart. Duplicate your bubble Select your bubble sphere. Press Ctrl+D to duplicate it.
- A copy appears on top of the original. Don't click away! Move it 15mm to the right using the arrow keys or by dragging.
- Press Ctrl+D again, TinkerCAD remembers the 15mm move and creates another copy spaced perfectly!
- Press Ctrl+D one more time for the 4th bubble. You now have a row of 4 bubbles spaced 15mm apart.
- Check that all 4 bubbles are in a straight line and evenly spaced.
- 15 mm centre to centre 15 mm centre to centre leaves a 5 mm gap between the 10 mm bubbles. Bubble ① is your original; each Ctrl+D repeats the copy AND the 15 mm move, so ②, ③ and ④ land perfectly spaced. 💡The Ctrl+D repeat trick remembers your last move, this is how pros create evenly spaced patterns quickly! ✏️ Fill in the Blanks +15 XP Press to duplicate. Space each bubble apart. ✏️ Check Answers 🧠 Knowledge Check +15 XP What keyboard shortcut duplicates a shape in TinkerCAD? ACtrl+D BCtrl+C CCtrl+G Check Answer ✅ Correct! Next Step → 5 🔢 Create a 4x3 Grid of Bubbles Duplicate the row to make 12 bubbles total Locked 🎯 Goal for this stepDuplicate the row of 4 bubbles to create a 4x3 grid, 12 bubbles total. Build the grid Select all 4 bubbles in the row, click and drag a selection box around them, or hold Shift and click each one.
- Press Ctrl+D to duplicate the entire row.
- Move the duplicated row 15mm forward (toward you) to create the second row.
- Press Ctrl+D again, TinkerCAD repeats the duplication and the 15mm forward move automatically!
- You now have a 4x3 grid of 12 bubbles, all evenly spaced. Count them to verify!
- 15 mm 4 columns ✨ 3 rows = 12 bubbles Select the whole row first (drag a box around all 4), then Ctrl+D and move the copy toward you. TinkerCad treats the row as one thing, so the spacing inside the row stays perfect. ✅Checkpoint: count your bubbles, there should be exactly 12, in 3 neat rows of 4. A wonky bubble means a drag slipped; click it and nudge it with the arrow keys (each press moves 1 mm). 💡4 columns times 3 rows = 12 bubbles. The Ctrl+D repeat trick works with multiple selected shapes too! 🧠 Knowledge Check +15 XP How many bubbles are in a 4x3 grid? A7 B12 C16 Check Answer ✅ Correct! Next Step → 6 🕳️ Change Bubbles to Holes Select all bubbles and set them as "Hole" in the inspector Locked 🎯 Goal for this stepConvert all 12 bubble spheres into holes so they'll punch through the base plate when grouped. Make the holes Select all 12 bubble spheres, drag a selection box around all of them, or use Ctrl+A then Shift-click the base plate to deselect it.
- With all bubbles selected, look at the shape properties in the top-right corner of the screen.
- Click "Hole", all the spheres turn translucent with a striped pattern.
- This means they are now holes, when grouped with the base plate, they will subtract material.
- The bubble shapes are still there, but they'll cut into the base plate to create the pop-it dimples.
- solid bubble Hole now a Hole , stripey and see-through click it in Shape Properties All 12 at once: drag one big selection box around just the bubbles, then click "Hole". Every sphere should turn grey and stripey. If the base plate turned stripey too, it got caught in your selection, undo and try again. 💡The Hole feature in TinkerCAD works like a cookie cutter, it removes material from solid shapes when they are grouped together. ⚡ True or False? +15 XP Holes subtract material when grouped with solid shapes. TrueFalse Hole shapes appear translucent with stripes in TinkerCAD. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP What happens to holes when you group them with solid shapes? AThey subtract material from the solid shapes BThey become solid CThey disappear completely Check Answer ✅ Correct! Next Step → 7 📐 Align Bubbles on the Base Plate Center the bubble holes on top of the base using Align Locked 🎯 Goal for this stepPosition the bubble grid centered on the base plate using the Align tool. Center the bubbles Select all 12 bubble spheres first (drag a selection box around them).
- Now hold Shift and click the base plate to add it to the selection.
- Click the "Align" tool in the top toolbar (or press the L key).
- Black alignment dots appear. Click the center dot on the X-axis (left-right) to center horizontally.
- Click the center dot on the Y-axis (front-back) to center vertically.
- The bubble grid should now be perfectly centered on the base plate!
- BEFORE · OFF CENTRE AFTER · ALIGN CENTRE DOTS click the two purple CENTRE dots The Align tool shows little black dots along each edge and centre. Click the centre dot on each axis (shown purple above) and the bubble grid snaps to the exact middle of the plate. 💡The Align tool is essential for precision. It removes the guesswork of centering objects manually. 🔢 Put It In Order +15 XP Put these in the correct order to align bubbles on the base: Click Align (or press L) Select all bubbles Center vertically (Y-axis) Shift-click the base plate to add it Center horizontally (X-axis) 🔍 Check Order↺ Reset 🧠 Knowledge Check +15 XP What keyboard shortcut opens the Align tool? AA BL CG Check Answer ✅ Correct! Next Step → 8 🎯 Group Everything Together Group so holes punch through the base plate Locked 🎯 Goal for this stepGroup the base plate and all bubble holes together so the holes punch into the base. Group and verify Press Ctrl+A to select everything on the workplane, the base plate and all 12 bubble holes.
- Press Ctrl+G to group them all together.
- The holes cut into the base plate, leaving 12 round dimples, your pop-it bubbles!
- Orbit the view to check your design, you should see neat, rounded indentations in the base.
- If something looks wrong, press Ctrl+Z to undo, fix the issue, then group again.

## Create the rim
- First, Ctrl+Z to ungroup if needed, or start fresh: create a new box the same size as your base (80mm x 60mm x 4mm).
- Duplicate the base plate shape with Ctrl+D.
- Scale up the duplicate, make it 5mm larger on each side (so 90mm x 70mm x 6mm for the outer rim).
- Make the original-sized shape a Hole.
- Align both shapes centered, then Group them, the inner hole cuts away, leaving just a border rim!
- Position this rim around your pop-it base and group everything together.
- bigger box (90 ✨ 70) 80 ✨ 60 Hole inside, centred group → a border rim! DUPLICATE · SCALE · SUBTRACT Box minus box = frame. The big solid box, with a plate-sized Hole aligned in its middle, groups into a picture-frame rim that slots around your pop-it. 💡This "duplicate, scale, subtract" technique is used by professional 3D modelers all the time to create hollow shapes and borders. ✏️ Fill in the Blanks +15 XP Duplicate the base, scale it each side, then make the original a . ✏️ Check Answers 🧠 Knowledge Check +15 XP What technique do we use to create a hollow border rim? ADuplicate, scale up, make original a Hole, then Group BDraw a rectangle border by hand CUse the Border tool from the menu Check Answer ✅ Correct! Next Step → 10 ✏️ Add Your Name with Text Use the Text shape to personalize your pop-it and customize colors Locked 🎯 Goal for this stepAdd a personalized text shape with your name and choose fun colors for your pop-it. Personalize your design In the Shapes Panel on the right, look under "Basic Shapes", find the "Text" shape.
- Drag the Text shape onto the workplane near your pop-it.
- Click on it and in the Shape Properties panel, type your name or a short word.
- Resize the text to fit nicely on the border rim of your pop-it. Make it about 2mm tall so it's raised but subtle.
- Position the text on the rim and group it with the pop-it.
- Now select your whole design and choose a fun color from the color picker in the Shape Properties!
- your name in Text shape, about 2 mm raised Keep the letters low (2 mm) so they print cleanly and do not get in the way of popping. Drag the Text shape onto the rim, type your name in Shape Properties, then shrink it to fit the rim band. 💡Try bright colors like purple, teal, or pink, they'll look great when 3D printed! 🧠 Knowledge Check +15 XP Where do you find the Text shape in TinkerCAD? AIn the Edit menu BIn the Basic Shapes panel CIn the Settings menu Check Answer ✅ Correct! Next Step → 11 📤 Export as STL & Learn About TPU Download your design and learn about flexible filament for pop-its Locked 🎯 Goal for this stepExport your pop-it as an STL file and learn why TPU filament is the best choice for flexible pop-its. Export and filament choice Click the "Export" button in the top-right corner of TinkerCAD.
- Choose "STL" as the format and download your file.
- For a pop-it, filament choice matters! PLA is rigid, it works but won't be flexible.
- TPU (Thermoplastic Polyurethane) is a flexible filament, perfect for pop-its that actually pop!
- TPU prints at slightly lower speed and higher temperature than PLA. Ask your printing service about TPU options.
- Recommended slicer settings for TPU: Layer height 0.2mm, Infill 15-20%, Print speed 25mm/s (slower than PLA).
