// Unity calls this when we enter a trigger collider:
void OnTriggerEnter2D(Collider2D other)
{
    // Did we hit an enemy?
    if (other.CompareTag("Enemy"))
    {
        // Get the enemy script and deal damage:
        EnemyController enemy =
            other.GetComponent<EnemyController>();

        if (enemy != null)
            enemy.TakeDamage(1);

        // Destroy the bullet:
        Destroy(gameObject);
    }
}