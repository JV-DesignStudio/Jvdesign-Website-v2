// ===== Part 1 of 2 (as shown in the lesson) =====
public class BulletController : MonoBehaviour
{
    public float speed = 10f;

    void Update()
    {
        // Move upward every frame
        transform.Translate(Vector2.up * speed
            * Time.deltaTime);

        // Destroy if off screen (tidy up!)
        if (transform.position.y > 12f)
            Destroy(gameObject);
    }
}

// ===== Part 2 of 2 (as shown in the lesson) =====
// Unity calls this when we enter a trigger collider:
void OnTriggerEnter2D(Collider2D other)
{
    // Did we hit an enemy?
    if (other.CompareTag("Enemy"))
    {
        // Get the enemy script and deal damage:
        EnemyController enemy =
            other.GetComponent<EnemyController>();

        if (enemy != null)
            enemy.TakeDamage(1);

        // Destroy the bullet:
        Destroy(gameObject);
    }
}