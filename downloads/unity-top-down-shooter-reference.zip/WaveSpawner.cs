public class WaveSpawner : MonoBehaviour
{
    public GameObject enemyPrefab;
    public float      timeBetweenWaves = 5;
    private int       _waveNumber      = 0;

    void Start()
    {
        // Start the coroutine:
        StartCoroutine(SpawnWaves());
    }

    // IEnumerator marks this as a coroutine:
    IEnumerator SpawnWaves()
    {
        while (true)  // run forever
        {
            // ? PAUSE here, game keeps running!
            yield return new WaitForSeconds(timeBetweenWaves);

            _waveNumber++;
            int count = 2 + _waveNumber;

            for (int i = 0; i < count; i++)
                SpawnEnemy();
        }
    }
}