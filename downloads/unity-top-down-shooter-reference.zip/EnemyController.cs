public class EnemyController : MonoBehaviour
{
    public float speed  = 2;
    public int   health = 3;

    private Transform _player;

    void Start()
    {
        // Find the player object by tag
        _player = GameObject
            .FindWithTag("Player")
            ?.transform;
    }

    void Update()
    {
        if (_player == null) return;

        // Chase the player:
        Vector2 dir = (_player.position
                      - transform.position).normalized;
        transform.Translate(dir * speed
            * Time.deltaTime);
    }

    public void TakeDamage(int amount)
    {
        health -= amount;
        if (health 0) Destroy(gameObject);
    }
}