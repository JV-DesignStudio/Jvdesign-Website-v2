void Update()
{
    // Read input axes (-1 to 1)
    float h = Input.GetAxis("Horizontal"); // A/D keys
    float v = Input.GetAxis("Vertical");   // W/S keys

    // Build a movement vector:
    Vector2 move = new Vector2(h, v);

    // Normalize so diagonal isn't faster:
    if (move.magnitude > 1f)
        move = move.normalized;

    // Apply movement:
    transform.position += (Vector3)(move * moveSpeed
        * Time.deltaTime);

    // Clamp to screen
    float clampX = Mathf.Clamp(transform.position.x, , );
    transform.position = new Vector3(clampX, transform.position.y, 0);
}