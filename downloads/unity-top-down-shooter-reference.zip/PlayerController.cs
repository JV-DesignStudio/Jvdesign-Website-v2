// ===== Part 1 of 6 (as shown in the lesson) =====
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Unity calls these automatically:

    void Start()
    {
        // Runs ONCE when the game starts
        Debug.Log("Player ready!");
    }

    void Update()
    {
        // Runs EVERY FRAME (~60x per second)
        // This is where movement goes
    }
}

// ===== Part 2 of 6 (as shown in the lesson) =====
public class PlayerController : MonoBehaviour
{
    // public = visible in Unity Inspector
    public float moveSpeed  = 5;
    public float bulletSpeed = 10;
    public int   health      = 100;

    // private = only this script can use it
    private float _fireTimer = 0f;
    private bool  _isAlive   = true;
}

// ===== Part 3 of 6 (as shown in the lesson) =====
void Update()
{
    // Time.deltaTime = seconds since last frame
    // Multiplying by it keeps speed consistent
    // whether the game runs at 30fps or 120fps

    float dt = Time.deltaTime;

    // Move 5 units per second, not 5 per frame:
    float step = moveSpeed * dt;

    // Update fire timer:
    _fireTimer += dt;

    Debug.Log("Frame! dt=" + dt);
}

// ===== Part 4 of 6 (as shown in the lesson) =====
void Update()
{
    // Read input axes (-1 to 1)
    float h = Input.GetAxis("Horizontal"); // A/D keys
    float v = Input.GetAxis("Vertical");   // W/S keys

    // Build a movement vector:
    Vector2 move = new Vector2(h, v);

    // Normalize so diagonal isn't faster:
    if (move.magnitude > 1f)
        move = move.normalized;

    // Apply movement:
    transform.position += (Vector3)(move * moveSpeed
        * Time.deltaTime);

    // Clamp to screen
    float clampX = Mathf.Clamp(transform.position.x, -8, 8);
    transform.position = new Vector3(clampX, transform.position.y, 0);
}

// ===== Part 5 of 6 (as shown in the lesson) =====
public float fireRate = 0.25; // seconds between shots

void Update()
{
    _fireTimer += Time.deltaTime;

    if (Input.GetKey(KeyCode.Space)
        && _fireTimer >= fireRate
        && _isAlive)
    {
        _fireTimer = 0f;  // reset timer
        Shoot();
    }
}

void Shoot()
{
    // Spawn a bullet at our position
    // (we wire this up in Step 6)
    Debug.Log("Pew!");
}

// ===== Part 6 of 6 (as shown in the lesson) =====
public GameObject bulletPrefab; // drag prefab here in Inspector

void Shoot()
{
    // Create bullet at player position + small offset up:
    Vector3 spawnPos = transform.position
                       + new Vector3(0, 0.5f, 0);

    Instantiate(bulletPrefab, spawnPos,
                Quaternion.identity);
}