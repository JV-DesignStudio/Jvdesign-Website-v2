Crystal Block! Add a Custom Glowing Block to Minecraft
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/minecraft-custom-block-mod.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Crystal Block! Add a Custom Glowing Block to Minecraft

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Files we'll create this episode
- ModBlocks.java registers the Crystal Block (and its BlockItem)
- models/block/crystal_block.json the 3D cube model
- models/item/crystal_block.json the item version model
- blockstates/crystal_block.json links state → model
- textures/block/crystal_block.png the 16✨16 texture
- loot_table/blocks/crystal_block.json what drops when mined
- recipe/crystal_block.json crafting recipe
- Open your CrystalMod project in IntelliJ. Right-click the crystalmod package → New → Java Class. Name it ModBlocks.
- Replace the file contents with:
- Open CrystalMod.java.
- In the onInitialize() method, add a call to ModBlocks.registerModBlocks(); put it before the ModItems line:
- Cannot find symbol: ModBlocks check ModBlocks.java is in the com.example.crystalmod package and the package declaration at the top of the file matches.
- Block not in creative inventory confirm registerModBlocks() adds the block via ItemGroupEvents with entries.add(CRYSTAL_BLOCK).
- Game crashes on startup make sure ModBlocks.registerModBlocks() is called before ModItems.registerModItems() in CrystalMod.java.
- Block is invisible when placed the blockstate or model JSON is missing or named wrong. Check Step 6.
- In your project's resources/assets/crystalmod folder, create a new subfolder: textures/block.
- Use Pixel Studio or any image editor to draw a 16✨16 crystal texture. Try cyan/teal shades with lighter spots for a crystal-like appearance.
- Save it as crystal_block.png in the textures/block/ folder.

## Block model (the 3D cube)
- In assets/crystalmod, create the folder models/block.
- Create the file crystal_block.json inside it:

## Item model (what you hold)
- In assets/crystalmod/models/item (which you created in Episode 1), create crystal_block.json:
- In assets/crystalmod, create the folder blockstates.
- Inside it create the file crystal_block.json:
- Add the block's name to your en_us.json language file: "block.crystalmod.crystal_block": "Crystal Block"
- Pink checkerboard = missing texture. The PNG must be at assets/crystalmod/textures/block/crystal_block.png folder is block, not blocks.
- Blockstate not found the JSON must be at assets/crystalmod/blockstates/crystal_block.json folder is blockstates (with an s, unlike texture).
- JSON syntax error a missing comma or bracket breaks the whole file. Paste your JSON at jsonlint.com to check.
- Block model not found block model goes in models/block/ and the item model goes in models/item/. Two separate files in two separate folders!
- In src/main/resources, navigate to the data folder. Create the path: data/crystalmod/loot_table/blocks/
- Create the file crystal_block.json inside it:
- In data/crystalmod, create a recipe folder.
- Create the file crystal_block.json inside it:
- In IntelliJ, select Minecraft Client from the run dropdown and click ✨ Play.
- Create or open a creative world.
- Press E → search for Crystal Block. It should appear in the Building Blocks tab.
- Place it in the world. It should look like your texture and glow in the dark!
- Switch to Survival mode (/gamemode survival) and try to mine it you'll need a pickaxe, and it should drop a Crystal Gem when broken.
- Test the crafting recipe: open a crafting table and fill all 9 slots with Crystal Gems you should get 1 Crystal Block.
- Glow: Change luminance(state -> 10) to 15 for maximum brightness, or 4 for a subtle glow.
- Hardness: Change strength(3.0f, 4.0f) to strength(50.0f, 1200.0f) to make it as hard as obsidian!
- Sound: Try BlockSoundGroup.GLASS, BlockSoundGroup.METAL or BlockSoundGroup.STONE each gives a different sound when walked on and mined.
- Map colour: Try MapColor.BLUE, MapColor.PURPLE or MapColor.EMERALD_GREEN this changes the colour the block shows on a map.
- Reload Minecraft after each change to see it work.
