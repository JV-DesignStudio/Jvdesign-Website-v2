Magic Cookie! Add Custom Food with Potion Effects to Minecraft
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/minecraft-custom-food-mod.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Magic Cookie! Add Custom Food with Potion Effects to Minecraft

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Open ModItems.java. Add these imports at the top (use Alt+Enter on any red text to auto-import):
- Below your CRYSTAL_GEM field, add the Magic Cookie:
- In registerModItems(), add: entries.add(MAGIC_COOKIE); inside the lambda.
- Save the file.
- Cannot find symbol: FoodComponent Alt+Enter → Import → net.minecraft.component.type.FoodComponent.
- Cannot find symbol: StatusEffects Alt+Enter → Import → net.minecraft.entity.effect.StatusEffects.
- Cannot find symbol: StatusEffectInstance Import → net.minecraft.entity.effect.StatusEffectInstance.
- Builder chain has a red squiggle on one line check every line except the last ends with a dot (not a semicolon) and the final line is .build(). Missing or extra dots break the whole chain.
- Cookie appears but doesn't give effects the second parameter in statusEffect(instance, probability) is 1.0f = 100% chance. If you put 0.0f it never applies!
- Use Pixel Studio to draw a 16✨16 cookie. Brown base, darker chips, maybe some sparkly cyan/purple pixels to show it's magical!
- Save as magic_cookie.png in assets/crystalmod/textures/item/.
- Create magic_cookie.json in assets/crystalmod/models/item/:
- Add to en_us.json: "item.crystalmod.magic_cookie": "Magic Cookie"
- In data/crystalmod/recipe/, create magic_cookie.json:
- Launch Minecraft Client from IntelliJ.
- Create a world in Survival mode so hunger is active (food only works in survival!).
- Use /give @p crystalmod:magic_cookie to get some cookies.
- Eat the cookie and watch the speed and jump boost effects appear in the top-right corner!
- Try jumping you should be able to jump much higher than normal.
- Check the crafting recipe works: gather wheat, sugar and a Crystal Gem and open a crafting table.
- Add one or two more effects to your Magic Cookie. Pick ones that sound fun to you!
- Relaunch Minecraft and test them.
- In ModItems.java, find your Magic Cookie's FoodComponent. After .nutrition(4), add .alwaysEdible():
- Relaunch Minecraft. Try eating the cookie with a completely full hunger bar it should work now!
- Add a new item field in ModItems.java with its own FoodComponent.
- Create the texture, model JSON and language entry.
- Add a crafting recipe.
- Test it in-game!

## What you learned this episode
- ✓How to use FoodComponent.Builder to define hunger, saturation and effects
- ✓How StatusEffectInstance sets the effect, duration and level
- ✓How to use a shapeless crafting recipe
- ✓How .alwaysEdible() overrides hunger requirements
