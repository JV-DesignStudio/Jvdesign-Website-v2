pico-8 cartridge // http://www.pico-8.com
version 41
__lua__
-- pong.p8  JVDesignStudio
function _init()
  title=true
  py1=54 py2=54
  bx=63 by=63
  bdx=2 bdy=1
  sc1=0 sc2=0
end

function _update()
  if title then
    if btnp(4) then title=false end
    return
  end
  -- left paddle: arrow keys
  if btn(2) then py1=py1-2 end
  if btn(3) then py1=py1+2 end
  py1=mid(0,py1,108)
  -- right paddle: simple ai
  if py2+10<by then py2=py2+1.5 end
  if py2+10>by then py2=py2-1.5 end
  py2=mid(0,py2,108)
  -- ball
  bx=bx+bdx
  by=by+bdy
  if by<1 or by>126 then bdy=-bdy end
  if bx<6 and by>=py1 and by<=py1+19 then bdx=abs(bdx) bx=5 end
  if bx>121 and by>=py2 and by<=py2+19 then bdx=-abs(bdx) bx=122 end
  if bx<0 then sc2=sc2+1 bx=63 by=63 bdx=2 bdy=1 end
  if bx>128 then sc1=sc1+1 bx=63 by=63 bdx=-2 bdy=1 end
end

function _draw()
  cls(0)
  if title then
    print("pong",56,40,7)
    print("press z to start",26,70,6)
    return
  end
  for i=0,128,8 do
    pset(64,i,5)
  end
  print(sc1,54,6,7)
  print(sc2,70,6,7)
  rectfill(2,py1,4,py1+19,7)
  rectfill(123,py2,125,py2+19,7)
  circfill(bx,by,2,7)
end
