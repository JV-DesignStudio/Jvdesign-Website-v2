Build a Python Game Dodge & Collect
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/python-game-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Build a Python Game Dodge & Collect

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Set the Background
- Every game starts with a window \u2014 a blank screen to draw on. Use the colour explorer below to pick your background, then copy the hex code into the code block and press Run!

## Design Your Player
- Now add the player the thing you control.\nYou pick how big it is and what colour.\nBig = easier to control, easier to hit. Small = nimble!

## How Fast Does It Move?
- This is the most important "feel" decision.\nToo slow = frustrating. Too fast = out of control.\nFinding the right speed is game design.

## How Many Lives?
- Lots of lives = relaxed, forgiving game.\n1 life = intense, every mistake costs.\nThis single number changes the whole feeling of your game.

## Design the Coins
- Coins are what you collect for points they fall gently from the top.\nYou decide how big and what colour they are.\nBig coins are easy to collect. Small coins feel rewarding when you grab them.

## Design the Hazards
- Hazards fall from the top and the player must dodge them.\nYou control their size, colour and, most importantly, how fast they fall.\nThis is what makes your game hard or easy.

## How Many Hazards?
- Spawn rate controls how often a new hazard appears.\nLow number = lots of hazards all at once.\nHigh number = fewer hazards, more breathing room.\nThis is called difficulty tuning.

## Fine-Tune Everything
- Youve set all the individual values. Now think about how they work together.\nAre your hazards so big they fill the screen? Is your player too slow to reach the coins?\nChange multiple values here until the game feels right.

## Think Like a Designer
- Youve built a game. Now think about the decisions you made.\nEvery number in a game was chosen by a designer for a reason.\nLets reflect on what your choices created.

## Your Finished Game!
- This is your game. You made every decision.\nBelow is a summary of all your choices. Every students game is different, because every designer makes different decisions.
