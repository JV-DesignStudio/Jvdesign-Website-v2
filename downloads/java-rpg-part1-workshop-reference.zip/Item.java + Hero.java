public class Item {
    String name, type;
    int power;
    public Item(String name, String type, int power) {
        this.name = name; this.type = type; this.power = power;
    }
}

// inside Hero:
private java.util.List<Item> inventory = new java.util.ArrayList<>();

public void pickUp(Item item) { inventory.add(item); }

public boolean useItem(String itemName) {
    for (Item it : inventory) {
        if (it.name.equals(itemName)) {
            if (it.type.equals("potion")) heal(it.power);
            if (it.type.equals("weapon")) attack += it.power;
            inventory.remove(it);
            return true;
        }
    }
    return false;   // did not have one
}