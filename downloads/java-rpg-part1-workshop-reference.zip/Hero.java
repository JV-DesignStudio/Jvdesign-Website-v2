public class Hero {
    private String name;
    private int maxHp = 30, hp = 30;
    private int attack = 5;
    private int gold = 0, xp = 0, level = 1;

    public Hero(String name) { this.name = name; }

    public void takeDamage(int amount) {
        hp = Math.max(0, hp - amount);
    }
    public void heal(int amount) {
        hp = Math.min(maxHp, hp + amount);
    }
    public boolean isAlive() { return hp > 0; }

    public int getHp() { return hp; }
    public int getMaxHp() { return maxHp; }
    public int getAttack() { return attack; }
    public String getName() { return name; }
}