// ===== Part 1 of 3 (as shown in the lesson) =====
int TILE = 40;
    int[][] map = {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,1},
        {1,0,1,1,0,0,0,2,2,2,0,0,1,1,0,0,1},
        {1,0,1,0,0,0,0,2,2,2,0,0,0,1,0,0,1},
        {1,0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
        // ... build yours 14 rows tall!
    };

    // paintComponent:
    for (int r = 0; r < map.length; r++)
        for (int c = 0; c < map[0].length; c++) {
            switch (map[r][c]) {
                case 0 -> g.setColor(new Color(52, 120, 62));
                case 1 -> g.setColor(new Color(90, 90, 100));
                case 2 -> g.setColor(new Color(50, 90, 180));
                case 3 -> g.setColor(new Color(212, 175, 55));
            }
            g.fillRect(c*TILE, r*TILE, TILE, TILE);
        }

// ===== Part 2 of 3 (as shown in the lesson) =====
int heroRow = 1, heroCol = 1;
    Hero hero = new Hero("Aria");

    boolean walkable(int r, int c) {
        if (r < 0 || r >= map.length || c < 0 || c >= map[0].length)
            return false;
        return map[r][c] == 0 || map[r][c] == 3;
    }

    public void keyPressed(KeyEvent e) {
        int r = heroRow, c = heroCol;
        if (e.getKeyCode() == KeyEvent.VK_UP)    r--;
        if (e.getKeyCode() == KeyEvent.VK_DOWN)  r++;
        if (e.getKeyCode() == KeyEvent.VK_LEFT)  c--;
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) c++;
        if (walkable(r, c)) { heroRow = r; heroCol = c; }
        repaint();
    }

// ===== Part 3 of 3 (as shown in the lesson) =====
// after a successful move:
    if (map[heroRow][heroCol] == 3) {
        hero.pickUp(new Item("Potion", "potion", 12));
        map[heroRow][heroCol] = 0;    // chest opened
    }

    // HUD in paintComponent:
    g.setColor(new Color(0, 0, 0, 170));
    g.fillRect(0, 0, 700, 34);
    g.setColor(Color.RED);
    g.fillRect(90, 10, 120, 14);
    g.setColor(new Color(6, 214, 160));
    g.fillRect(90, 10, 120 * hero.getHp() / hero.getMaxHp(), 14);
    g.setColor(Color.WHITE);
    g.drawString(hero.getName(), 12, 22);