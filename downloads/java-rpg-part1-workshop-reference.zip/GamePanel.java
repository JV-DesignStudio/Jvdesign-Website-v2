int TILE = 40;
    int[][] map = {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,1},
        {1,0,1,1,0,0,0,2,2,2,0,0,1,1,0,0,1},
        {1,0,1,0,0,0,0,2,2,2,0,0,0,1,0,0,1},
        {1,0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
        // ... build yours 14 rows tall!
    };

    // paintComponent:
    for (int r = 0; r < map.length; r++)
        for (int c = 0; c < map[0].length; c++) {
            switch (map[r][c]) {
                case 0 -> g.setColor(new Color(52, 120, 62));
                case 1 -> g.setColor(new Color(90, 90, 100));
                case 2 -> g.setColor(new Color(50, 90, 180));
                case 3 -> g.setColor(new Color(212, 175, 55));
            }
            g.fillRect(c*TILE, r*TILE, TILE, TILE);
        }