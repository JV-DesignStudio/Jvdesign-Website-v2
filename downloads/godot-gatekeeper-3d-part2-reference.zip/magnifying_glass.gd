# magnifying_glass.gd: Attach to your MagnifyingGlass Node3D
extends Node3D

@onready var result_label: Label3D = $ResultLabel

func _ready() -> void:
    result_label.visible = false

func _on_area_3d_body_entered(body: Node3D) -> void:
    if body.is_in_group("survivor"):
        var spots: bool = body.hidden_stats.get("has_spots", false)
        if spots:
            result_label.text    = "🔎 GREEN SPOTS DETECTED!"
            result_label.modulate = Color.RED
        else:
            result_label.text    = "🔎 No spots. Clear."
            result_label.modulate = Color.GREEN
        result_label.visible = true

func _on_area_3d_body_exited(body: Node3D) -> void:
    if body.is_in_group("survivor"):
        result_label.visible = false