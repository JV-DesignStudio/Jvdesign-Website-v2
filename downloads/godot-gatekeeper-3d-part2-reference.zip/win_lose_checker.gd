# win_lose_checker.gd: Attach to WinLoseChecker in your safe room
extends Node3D

@onready var banner:    Label3D           = $ResultBanner
@onready var fireworks: GPUParticles3D    = $Fireworks
@onready var sfx:       AudioStreamPlayer = $VictorySound

func check_game_state() -> void:
    var credits = GameManager.shared_credits
    var health  = GameManager.base_health
    var day     = GameManager.current_day

    if credits <= 0 or health <= 0:
        show_game_over()
    elif day > 10:
        show_victory()

func show_game_over() -> void:
    banner.text        = "❌ GAME OVER!\\nThe base has fallen."
    banner.modulate    = Color.RED
    fireworks.emitting = false

func show_victory() -> void:
    banner.text        = "🏆 YOU SURVIVED!\\n10 DAYS COMPLETE!"
    banner.modulate    = Color(1.0, 0.84, 0.0)   # gold
    fireworks.emitting = true
    sfx.play()