Who Goes There? Part 2: The 10-Day Challenge in Godot
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/godot-gatekeeper-3d-part2.html

Reference GDScript files for this workshop.
These are the scripts shown step by step in the lesson. Build the scenes in the
Godot editor as the steps describe, then attach each script to the matching node.

Scripts:
- game_manager.gd
- clock_display.gd
- end_of_day.gd
- rule_generator.gd
- magnifying_glass.gd
- win_lose_checker.gd

How to use:
1. Create the Godot project and scenes exactly as the workshop steps describe.
2. Create a script with the same name and paste (or type) the code in.
3. Stuck? Compare your script to the reference here.
