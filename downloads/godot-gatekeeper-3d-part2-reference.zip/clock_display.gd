# clock_display.gd: Attach to your ClockLabel Label3D
extends Label3D

@onready var day_timer: Timer = %DayTimer

func _process(_delta: float) -> void:
    var s_left := int(day_timer.time_left)
    text = "%02d:%02d" % [s_left / 60, s_left % 60]

    # Flash red when under 30 seconds
    if s_left < 30:
        modulate = Color.RED
    else:
        modulate = Color.WHITE