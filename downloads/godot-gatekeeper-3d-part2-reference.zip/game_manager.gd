# ===== Part 1 of 2 (as shown in the lesson) =====
# Add these to your game_manager.gd Autoload
var visitors_in_line: int = 5

func next_visitor() -> void:
    if visitors_in_line > 0:
        visitors_in_line -= 1
        spawn_survivor()
    else:
        print("Line is empty, the day is nearly over!")

func spawn_survivor() -> void:
    var s = preload("res://survivor_3d.tscn").instantiate()
    s.position = Vector3(0, 0, 15)   # far end of the path
    # randomise the hidden stats each time
    s.hidden_stats["temperature"] = randf_range(96.0, 105.0)
    s.hidden_stats["has_spots"]   = randf() > 0.5
    get_tree().current_scene.add_child(s)

# ===== Part 2 of 2 (as shown in the lesson) =====
# Add these to your existing game_manager.gd
var shared_credits: int = 50

func correct_stamp() -> void:
    shared_credits += 10
    _update_credits_display()
    print("✅ +10 coins! Total: %d" % shared_credits)

# Replace your old mistake_made() with this version
func mistake_made() -> void:
    shared_credits -= 20
    base_health    -= 20
    _update_credits_display()
    _update_health_display()
    print("❌ -20 coins! Total: %d" % shared_credits)
    if shared_credits <= 0 or base_health <= 0:
        game_over()

func _update_credits_display() -> void:
    var lbl = get_tree().get_first_node_in_group("credits_label")
    if lbl:
        lbl.text = "💰 %d coins" % shared_credits