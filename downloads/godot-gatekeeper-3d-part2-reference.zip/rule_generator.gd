# rule_generator.gd: Register as an Autoload called RuleGenerator
extends Node

func get_rules(day: int) -> String:
    match day:
        1:
            return "DO NOT let in anyone\\nwith temp > 100°F!"
        2:
            return "NO temp > 100°F!\\nNO green spots allowed!"
        3:
            return "ADMIT District 7 residents.\\nDeny all others with temp > 100°F."
        4:
            return "DENY anyone with green spots\\nOR temp > 99°F, stricter today!"
        5:
            return "EMERGENCY LOCKDOWN:\\nOnly pre-approved visitors allowed!"
        _:
            return "Check ALL previous rules.\\nStay alert, rules are stacking!"