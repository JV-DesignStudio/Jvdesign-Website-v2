# end_of_day.gd: Attach to EndOfDayScreen in your safe room
extends Node3D

const BASE_RENT: int = 20
const FOOD_COST: int = 10

@onready var summary: Label3D = $SummaryScreen

func pay_bills() -> void:
    var before = GameManager.shared_credits
    GameManager.shared_credits -= BASE_RENT
    GameManager.shared_credits -= FOOD_COST
    GameManager._update_credits_display()

    summary.text = (
        "📋 DAY %d COMPLETE\\n"
        + "────────────────\\n"
        + "Coins before bills: %d\\n"
        + "Base Rent:          -%d\\n"
        + "Food:               -%d\\n"
        + "────────────────\\n"
        + "Coins left:         %d"
    ) % [
        GameManager.current_day,
        before,
        BASE_RENT,
        FOOD_COST,
        GameManager.shared_credits
    ]