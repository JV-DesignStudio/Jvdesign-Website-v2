Pong Clone , Build a Pong Game in GDevelop
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gdevelop-pong-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Pong Clone , Build a Pong Game in GDevelop

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Get started
- Go to gdevelop.io and click the Download button for your operating system.
- Run the installer and follow the prompts. Open GDevelop when it's done.
- Click "Create a new project". Choose "Start from a blank project".
- Name your project "Pong Game" and click Create.
- You'll see the Scene Editor in the middle (where you place objects) and the Events Sheet tab at the top (where you build game logic).

## Create the paddle objects
- In the Objects panel (right side), click "Add an object".
- Choose "Sprite" as the object type. Name it "LeftPaddle".
- Click "Edit the object" then "Add an animation". Click "Import from file" and choose a simple rectangle image, or click "Paint" to draw a tall thin rectangle (about 20 pixels wide, 100 pixels tall) in a bright colour.
- Close the animation editor. Drag the LeftPaddle to the left side of the scene, about 30 pixels from the edge.
- Right-click LeftPaddle in the Objects panel and choose "Duplicate". Rename it "RightPaddle". Drag it to the right side of the scene.

## Open the Events Sheet
- Click the "Events" tab at the top of the editor to switch to the Events Sheet.
- Click "Add an event" at the bottom. A new empty event row appears.
- Click "Add condition" on the left side of the event. Search for "Key pressed" and select it.
- In the key dropdown, choose "Up". This event now triggers when the Up key is held down.
- Click "Add action" on the right side. Search for "Change the Y position" of an object.
- Choose LeftPaddle as the object. Set the modification sign to "Add" and value to -5. (Negative Y = up in GDevelop.)
- Repeat for Down key: add another event with condition "Key pressed: Down" and action "Change Y position of LeftPaddle, Add, 5".

## Your events should look like this:

## Add the ball object
- Click "Add an object" in the Objects panel. Choose "Sprite", name it "Ball".
- Edit the object, add an animation, and import or paint a small circle (about 20x20 pixels) in white or yellow.
- Drag the ball to the centre of the scene.
- With the Ball selected, click "Edit object behaviors" in the Properties panel.
- Click "Add a behavior" and choose "Bounce on edges". This makes the ball bounce off the screen borders automatically!
- Also add the "Platformer character" behavior? No we don't need that. Just "Bounce on edges" is enough for now.

## Set the ball moving
- Switch to the Events Sheet. Click "Add a new event".
- Add a condition: "At the beginning of the scene". This event runs once when the game starts.
- Add an action: "Add a force" to Ball. Set X to 200 and Y to 150. This launches the ball diagonally.
- Add a new event. Condition: "Collision" between Ball and LeftPaddle.
- Action: "Bounce the object" on Ball. This makes it bounce back when it hits the left paddle.
- Duplicate that event. Change the collision to Ball and RightPaddle.

## Create score variables
- In the Events Sheet, click "Project Manager" (hamburger menu, top left). Go to Variables → Scene variables.
- Create a variable called LeftScore and set it to 0.
- Create another called RightScore and set it to 0.
- Add a new event. Condition: "X position of Ball" is < -400 (ball went past the left edge).
- Actions: "Change variable RightScore, add 1". Then "Change the position of Ball" to X: 0, Y: 0 (reset to centre).
- Add another event for the right side: Condition: "X position of Ball" is > 400. Actions: "Change variable LeftScore, add 1" and reset ball position.

## Test your game
- Click the Play button (green triangle) at the top to launch the game.
- Test that both paddles move correctly with their keys.
- Watch the ball bounce off walls and paddles. Does it behave correctly?
- Check that scores update when the ball passes a paddle.
- Go back to the Scene Editor. Right-click the background and choose "Change the background color" to something dark.
- Try changing the ball's starting force values to make it faster or slower. Have fun!
- The GDevelop editor: Scene Editor for placing objects, Events Sheet for game logic
- Creating Sprite objects, duplicating them and placing instances in the scene
- Building events with Conditions ("when") and Actions ("what happens")
- Attaching Behaviours like "Bounce on edges" to give objects automatic abilities
- Using scene variables for scoring and collision events for paddle-ball interaction
