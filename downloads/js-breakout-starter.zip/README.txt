Breakout - My First Browser Game Ep 3
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/js-breakout-workshop.html

Files:
- breakout-starter.html : canvas skeleton (Step 1) - start here
- breakout.html : reference - same starter, follow steps 2-5 to add paddle, ball, bricks and scoring

How to use:
1. Open breakout-starter.html in browser - blank board.
2. Follow workshop steps to add paddle, ball, bricks.
3. Compare to breakout.html if stuck.

No install, works on school computers.
