// Complete C++ Breakout for SFML 3. Build:
//   g++ breakout.cpp -o breakout -lsfml-graphics -lsfml-window -lsfml-system
#include <SFML/Graphics.hpp>
#include <optional>
#include <vector>

struct Brick { sf::FloatRect rect; int row; bool alive; };

int main() {
    sf::RenderWindow window(sf::VideoMode({700, 520}), "C++ Breakout");
    window.setFramerateLimit(60);

    sf::Color rowCol[5] = {
        {248,113,113},{251,146,60},{250,204,21},{74,222,128},{96,165,250}
    };

    float padX = 295, bx = 343, by = 300, bvx = 4, bvy = -4;
    int score = 0, lives = 3;

    std::vector<Brick> bricks;
    auto build = [&]() {
        bricks.clear();
        for (int r = 0; r < 5; r++)
            for (int c = 0; c < 10; c++)
                bricks.push_back({ sf::FloatRect({c*68.f+12, r*26.f+50}, {64.f, 22.f}), r, true });
    };
    build();

    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent())
            if (event->is<sf::Event::Closed>()) window.close();

        float mx = (float)sf::Mouse::getPosition(window).x;
        padX = mx - 55.f; // centre the 110px-wide paddle on the mouse
        if (padX < 0) padX = 0; if (padX > 590) padX = 590;

        bx += bvx; by += bvy;
        if (bx <= 0 || bx + 14 >= 700) bvx = -bvx;
        if (by <= 0) bvy = -bvy;

        sf::FloatRect ball({bx, by}, {14.f, 14.f});
        sf::FloatRect pad({padX, 480.f}, {110.f, 14.f});
        if (ball.findIntersection(pad) && bvy > 0) {
            bvy = -bvy;
            float hit = (bx + 7) - (padX + 55);
            bvx = hit / 12.f;
            if (bvx == 0) bvx = 1;
        }
        for (auto& b : bricks) {
            if (b.alive && ball.findIntersection(b.rect)) {
                b.alive = false; score += (5 - b.row) * 10; bvy = -bvy; break;
            }
        }
        if (by - 14 > 520) {
            if (--lives <= 0) { build(); lives = 3; score = 0; }
            bx = 343; by = 300; bvx = 4; bvy = -4;
        }
        bool anyAlive = false; for (auto& b : bricks) if (b.alive) anyAlive = true;
        if (!anyAlive) { build(); bx = 343; by = 300; }

        window.clear(sf::Color(15, 18, 32));
        for (auto& b : bricks) if (b.alive) {
            sf::RectangleShape r(b.rect.size);
            r.setPosition(b.rect.position);
            r.setFillColor(rowCol[b.row]);
            window.draw(r);
        }
        sf::RectangleShape pd({110.f, 14.f}); pd.setPosition({padX, 480.f});
        pd.setFillColor(sf::Color(255,119,0)); window.draw(pd);
        sf::CircleShape ballShape(7.f); ballShape.setPosition({bx, by});
        window.draw(ballShape);
        window.display();
    }
}