Haunted Escape! Build a Horror Maze in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-horror-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Haunted Escape! Build a Horror Maze in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Create the maze layout
- Delete the default Baseplate. Add a new Part (size 100, 1, 100100, 1, 100), BrickColor Really black, Material SmoothPlastic. This is the maze floor. Name it Floor.
- Build maze walls using Parts (size 20, 8, 220, 8, 2 or 2, 8, 202, 8, 20), BrickColor Dark stone grey, Material Brick. All Anchored = true. Arrange them to form corridors dead ends, turns and open rooms.
- Build at least 5 corridors with a few dead ends. Make it feel genuinely maze-like!
- Add a SpawnLocation near one edge of the maze.
- Add an outer wall around the whole maze so players can't leave.

## Make it dark
- Click Lighting in Explorer. Set Brightness to 00. Set Ambient to (0, 0, 0)(0, 0, 0), pure black. Set OutdoorAmbient to (0, 0, 0)(0, 0, 0) too. The world goes completely dark!
- Now add a PointLight to the player. We'll do this in a later step for now just check it's dark by pressing Play.
- In StarterCharacterScripts (inside StarterPlayer in Explorer), add a LocalScript. Name it PlayerTorch. Paste:
- In ServerScriptService, add a Script named GameSetup:
- Add 3 small Parts (size 1, 2, 0.51, 2, 0.5) scattered in dead ends. BrickColor Bright yellow, Material Neon. Name them Key1, Key2, Key3. Anchored = true.
- Add a Script inside each key (same script for all 3):
- Add a Part (size 6, 8, 16, 8, 1) as the door. BrickColor Bright red, Material Neon. Name it EscapeDoor. Anchored = true. Place it at one end of the maze as the exit.
- Add a BillboardGui label: 🚪 Collect all 3 keys!🚪 Collect all 3 keys!.
- Add a Script inside EscapeDoor:

## Build the ghost
- Add a Part (size 3, 4, 33, 4, 3). Right-click → Insert Object → SpecialMesh, MeshType Sphere. BrickColor Institutional white, Material Neon, Transparency 0.5. Name it Ghost. Do NOT anchor it.
- Place it somewhere in the maze, away from the spawn.
- Add a Script inside Ghost:
- In StarterGui, add a ScreenGui named TimerGui. Add a TextLabel at the top of the screen. Font GothamBold, TextSize 32, TextColor white, BackgroundTransparency 1. Name it TimerLabel.
- Add a LocalScript inside TimerGui:
- In StarterGui, add a ScreenGui named KeysGui. Add a TextLabel bottom-left, size {0.2,0},{0.06,0}{0.2,0},{0.06,0}, position {0.02,0},{0.9,0}{0.02,0},{0.9,0}. Text: 🔑 0 / 3🔑 0 / 3. Font GothamBold. BackgroundTransparency 1. TextColor white.
- Add a LocalScript inside KeysGui:
- In Workspace, add a Sound. Name it HorrorMusic. Set SoundId to a free horror ambient audio from the Toolbox (search "horror ambient"). Set Looped = true, Volume = 0.4.
- In ServerScriptService, add a Script named MusicPlay: workspace.HorrorMusic:Play()workspace.HorrorMusic:Play()
- Add another Sound named GhostScream inside the Ghost part. Find a scream/ghost sound from the Toolbox. Set Volume = 1.
- In the Ghost's script, inside the if closest < 3 thenif closest < 3 then block, add ghost.GhostScream:Play()ghost.GhostScream:Play() before killing the player.
- Fog: In Lighting → Insert Object → Atmosphere. Set Density to 0.5, Color to a dark purple. Spooky fog fills the maze!
- Candles: Add small cylinder parts as candles. Insert a Fire effect into each (right-click → Insert Object → Fire). Set Fire size to 1 and Heat to 3 for small flames.
- Flickering lights: Add PointLights inside candle flames with orange colour and low Range (8). This creates pools of light in the darkness.
- Paintings: Add flat Parts as picture frames on walls. Use BillboardGui with emoji text like 👁️ or 💀 on them.
- Coffins: Build a coffin shape from a few parts and scatter them around. Great for dead ends!
- In ReplicatedStorage, add a RemoteEvent named WinEvent.
- In the EscapeDoor script, after the door opens, add: game.ReplicatedStorage.WinEvent:FireClient(player)game.ReplicatedStorage.WinEvent:FireClient(player).
- In StarterGui, add a ScreenGui named WinScreen. Add a full-screen Frame (dark green, transparency 0.3). Add a big TextLabel: 🎉 YOU ESCAPED!🎉 YOU ESCAPED!. Set Visible = false.
- Add a LocalScript in WinScreen:
- Press Play. Navigate the dark maze. Find keys, avoid the ghost, escape through the door.
- If the ghost is too fast, lower its speed. If the maze is too easy, add more dead ends.
- Try setting the ghost speed to 6 for a fun challenge and 10 for heart-pounding terror!
- Press Stop → File → Publish to Roblox → Public.
- Dare your friends and family to escape your haunted maze!
