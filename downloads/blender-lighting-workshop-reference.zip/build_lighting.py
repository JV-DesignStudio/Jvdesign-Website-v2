# build_lighting.py - Blender 4.x
# My First 3D Model Ep 6: Lighting & Effects
import bpy

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Subject
bpy.ops.mesh.primitive_monkey_add(location=(0, 0, 1))
bpy.ops.object.camera_add(location=(0, -7, 2), rotation=(1.45, 0, 0))
bpy.context.scene.camera = bpy.context.active_object

def add_light(name, kind, loc, energy, size=3.0):
    bpy.ops.object.light_add(type=kind, location=loc)
    light = bpy.context.active_object
    light.name = name
    light.data.energy = energy
    if kind == 'AREA':
        light.data.size = size
    return light

# Classic three-point lighting
add_light("Key", 'AREA', (3, -3, 4), 800, size=4)     # bright main light
add_light("Fill", 'AREA', (-4, -2, 2), 250, size=6)   # softer fill
add_light("Rim", 'AREA', (0, 4, 4), 500, size=3)      # back light for edge glow

# A coloured background world for mood
world = bpy.data.worlds["World"] if "World" in bpy.data.worlds else bpy.data.worlds.new("World")
bpy.context.scene.world = world
world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (0.02, 0.02, 0.06, 1)

print("Three-point lighting ready. Try changing each light's energy.")
