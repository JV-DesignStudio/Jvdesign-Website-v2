My First 3D Model Ep 6: Lighting & Effects
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/blender-lighting-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First 3D Model Ep 6: Lighting & Effects

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Test scene: your character (or a sphere) on a plane, Rendered viewport.
- Point: a bare bulb, light in all directions. Lamps, candles, torches.
- Sun: parallel rays, position irrelevant, only ANGLE matters. Daylight.
- Spot: a cone with edges you control. Stage lights, torch beams, drama.
- Area: a glowing rectangle, SOFT shadows like a window or studio softbox. The secret to flattering light: bigger = softer.
- Cycle through all four on your scene and watch the shadows change character.
- Key: your main light, a big Area light, 45- to the side and above. The scene-s "sun".
- Fill: a weaker (? strength) Area light on the OPPOSITE side, lifts shadows so they are dark, not empty.
- Rim: a Spot BEHIND the character aimed at their back edge, a halo outline that pops them off the background. This one is the "wow" light.
- Turn each on alone to see its job, then all three. Portrait-studio quality.
- Every film interview, game cinematic and product shot you have ever seen: this exact recipe.
- An HDRI is a 360- photo with real brightness data, used as the world, it lights your scene with a real place-s light.
- Get free ones at polyhaven.com (100% free, no account).
- World Properties ? Color ? Environment Texture ? open the HDRI. Rendered view: your scene now sits IN that world, lit by its sky, bounced by its ground.
- Rotate the world (Shading workspace ? World nodes ? add Mapping + Texture Coordinate, rotate Z) to steer where its sun hits.
- One sunset HDRI replaces an hour of lamp fiddling. Use them shamelessly.
- Add a big cube surrounding the scene. Give it a new material, but delete the Principled BSDF and plug a Principled Volume into the VOLUME socket instead.
- Density ~0.02, barely-there fog. Now light TRAVELS visibly through the air.
- Aim a strong Spot through it (a "window"), god rays! In Eevee, also raise Volumetric settings in Render Properties.
- Volumetrics cost render time, use the thinnest density that reads.
- Dusty attic, misty forest, smoky bar: this one technique is half of "cinematic".
- Same scene, three moods, only light colours changed:
- Cosy: warm orange key (like tungsten bulbs), warm fill. Fireplace feeling.
- Tense: cool blue-cyan key, minimal fill (deep shadows). Thriller feeling.
- Neon night: magenta key + cyan rim, the complementary pair every cyberpunk poster uses.
- The teal-and-orange combo dominates film posters because warm skin pops against cool backgrounds, complementary contrast.
- Render all three. Same models, three different films.
- Render a frame (F12), then open the Compositing workspace and tick Use Nodes.
- Glare node (Fog Glow) between Render Layers and Composite: your emission lights bloom softly.
- Color Balance node: push shadows slightly blue, highlights slightly warm, an instant "graded" look.
- Vignette: darken the corners with an Ellipse Mask + Blur into a Mix node, eyes drift to the bright centre.
- Compare raw vs graded. That last 10% is what people call "professional". Save everything for the finale!


--------------------------------------------------------------------
BONUS: BLENDER PYTHON BUILDER
--------------------------------------------------------------------
This pack also includes build_lighting.py, a script that builds a "Lighting & Effects" setup for you.

How to run it:
1. Open Blender 4.x.
2. Go to the Scripting tab, click Open, and choose build_lighting.py.
3. Click Run Script (the play button). The model appears in your scene.
4. Press F12 to render, or keep building on top of it.
