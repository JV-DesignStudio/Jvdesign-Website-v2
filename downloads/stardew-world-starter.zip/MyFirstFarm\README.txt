STARDEW WORLD WORKSHOP - STARTER PACK
=====================================

This pack is the shell of your own Stardew content pack. It does not
include the game's artwork or maps (those belong to the game). You copy
the map you want to edit out of the game and into assets/maps yourself.

HOW TO USE (Episode 1 - 10)
---------------------------
1. Copy this whole "MyFirstFarm" folder into:
   Stardew Valley/Mods

2. In manifest.json, change:
   - Name      -> your mod's name
   - Author    -> your name
   - UniqueID  -> YourName.YourModName  (must be unique)

3. Copy a map from the game:
   Stardew Valley/Content/Maps/Farm.tmx
   ...and paste it into assets/maps/ in this folder.
   Copy the tilesheet images it uses into the same folder too.

4. Edit that copied map in Tiled, then save it.

5. Launch Stardew with SMAPI and read the console. Your LogName
   ("My First Farm") should appear in the loaded mod list.

CONTENT.JSON
------------
"Load" replaces a game file with your own at load time. It never damages
the real game. Each extra map you add needs its own Load block.

CHECKLIST BEFORE YOU SHARE
--------------------------
[ ] manifest.json is at the very top of the mod folder
[ ] No folder inside a folder (no ContentPatcher/ContentPatcher)
[ ] Every FromFile path matches a real file, exactly
[ ] content.json has no trailing commas and uses straight quotes
[ ] Warp names match the Load "Target" names
[ ] Zipped the MOD FOLDER, so unzip gives MyFirstFarm/manifest.json

FULL GUIDE
----------
https://jvdesignstudio.co.uk/workshops/stardew-world-workshop.html

Made for learning. Follow the workshops one episode at a time.
