# build_character.py - Blender 4.x
# My First 3D Model Ep 2: Character Basics
import bpy

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

def part(primitive, name, loc, scale, **kw):
    getattr(bpy.ops.mesh, primitive)(location=loc, **kw)
    o = bpy.context.active_object
    o.name = name
    o.scale = scale
    return o

# Body
part('primitive_cube_add', 'Body', (0, 0, 1.1), (0.5, 0.35, 0.6), size=1)
# Head
part('primitive_uv_sphere_add', 'Head', (0, 0, 2.05), (0.42, 0.42, 0.42), radius=1)
# Arms
part('primitive_cube_add', 'Arm_L', (-0.75, 0, 1.2), (0.18, 0.18, 0.5), size=1)
part('primitive_cube_add', 'Arm_R', ( 0.75, 0, 1.2), (0.18, 0.18, 0.5), size=1)
# Legs
part('primitive_cube_add', 'Leg_L', (-0.22, 0, 0.35), (0.2, 0.2, 0.5), size=1)
part('primitive_cube_add', 'Leg_R', ( 0.22, 0, 0.35), (0.2, 0.2, 0.5), size=1)

# Camera + light
bpy.ops.object.camera_add(location=(5, -5, 3), rotation=(1.15, 0, 0.78))
bpy.context.scene.camera = bpy.context.active_object
bpy.ops.object.light_add(type='SUN', location=(4, -4, 8))
bpy.context.active_object.data.energy = 3.0

print("Character built from simple shapes - now try moving the parts!")
