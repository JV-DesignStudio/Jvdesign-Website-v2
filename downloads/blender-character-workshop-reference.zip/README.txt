My First 3D Model Ep 2: Character Basics
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/blender-character-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First 3D Model Ep 2: Character Basics

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- New scene (File ? New). Select the cube and press Tab, welcome to Edit Mode, inside the mesh.
- Everything is made of three things: vertices (points), edges (lines between them), faces (the surfaces).
- Switch selection modes with 1, 2, 3 (vertex, edge, face). Try selecting one of each.
- G/R/S all work in here, grab one vertex and pull: you are deforming the cube!
- A selects all, Alt+A deselects. Tab returns to Object Mode.
- Scale the cube into a torso first (Object Mode: S, then Shift+Z types, ~0.6 wide, taller than deep).
- In Edit Mode, face select (3), click the BOTTOM face, press E and pull down, you EXTRUDED hips!
- Extrude = grow new geometry out of a face. Click confirms, Esc cancels (but beware: a cancelled extrude still adds hidden verts, undo with Ctrl+Z instead).
- Extrude the top face upward for a chest, then a neck (extrude, then S to shrink it inward).
- A body emerges from ONE cube. That is box modelling.
- Characters are symmetrical, modelling both sides by hand is madness. Enter the Mirror modifier.
- First delete the left half: in Edit Mode, face-select the left-side faces and delete (X ? Faces).
- Modifier Properties (wrench icon) ? Add Modifier ? Mirror, axis X. The missing half reappears, as a live reflection!
- Tick Clipping so centre vertices cannot cross the mirror line and split the seam.
- Now edit the right side and watch the left copy you in real time.
- Shoulder: select the upper-right SIDE face of the torso, extrude outward a little (E), then again for the upper arm, then the forearm, two extrusions make an elbow possible later!
- Hand: one more small extrusion, scaled slightly bigger, mitten style. Low-poly charm!
- Leg: select the right half of the bottom face (you may need a loop cut first, next step), extrude down twice (thigh, shin), then a foot: extrude down short, then extrude the FRONT face of it forward.
- Check proportions from the front (Numpad 1): legs roughly half the height, arms reach mid-thigh.
- Ctrl+R = loop cut: hover the torso, a yellow ring previews; scroll to add more; click, then Esc to leave them centred.
- A loop around the waist lets you pull in a waistline (select the loop with Alt+Click, then S to scale it).
- The head: easiest as a separate object, Object Mode, Shift+A ? Cube, scale ~0.5, place on the neck. Slightly TOO big reads as friendly/stylised, lean into it!
- Optional: one loop cut across the head to shape a jaw.
- Look at your character from all angles. A person! From cubes!
- Material Properties (sphere icon) ? New ? set Base Color. One material for the body (shirt colour!).
- Multiple colours on one mesh: in Edit Mode select the leg faces, click + to add a second material slot, choose a trouser colour, press Assign.
- Repeat for skin (head/hands). Three flat colours = instant low-poly style.
- The pro test: press Z ? Rendered off, view as silhouette (or just squint), can you STILL tell it is a person? Good characters read from shape alone.
- Save as character.blend, Episodes 3 and 4 rig and animate THIS file!


--------------------------------------------------------------------
BONUS: BLENDER PYTHON BUILDER
--------------------------------------------------------------------
This pack also includes build_character.py, a script that builds a "Character Basics" setup for you.

How to run it:
1. Open Blender 4.x.
2. Go to the Scripting tab, click Open, and choose build_character.py.
3. Click Run Script (the play button). The model appears in your scene.
4. Press F12 to render, or keep building on top of it.
