Build a C++ Tower Defence Game
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/cpp-tower-defence-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Build a C++ Tower Defence Game

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Grid Size
- Every tower defence starts with a grid.\nTowers go on grass tiles, enemies walk the path.\nIn C++, we use const int a constant integer.

## Tower Damage
- Each tower fires at enemies in range.\nDamage = HP removed per shot.\nStored as an int an integer variable.

## Tower Range
- Towers only shoot enemies within range (measured in grid cells).\nWe use float because range can be a decimal.

## Fire Rate
- Shots per second. 1.0 = one shot/sec. 3.0 = three.\nDPS = damage • fireRate.

## Enemy Hit Points
- Each enemy has HP. Towers reduce it to zero.\nIn C++, we group related data in a struct.

## Enemy Speed
- How fast enemies walk the path.\nMultiplied by deltaTime for smooth, frame-rate-independent movement.

## Wave Size
- Enemies come in waves. Later waves spawn more.\nUses a C++ for loop to spawn each enemy.

## Starting Gold & Cost
- Gold = your economy. Start with some, earn +5 per kill, spend it on towers.

## Kill Bounty
- Gold earned per kill. Feeds back into economy more kills = more towers.

## Part 1 Fine-Tune
- All foundation values in one place. Balance them.\nAfter this: tower types, upgrades, and bosses!

## Sniper Tower
- 🎮 First new tower type, the Sniper.\nHigh damage, long range, slow fire.\nIn C++, tower types use an enum a named list of options.

## Splash Tower
- 🎮 The Splash tower hits multiple enemies at once.\nDeals damage to target AND nearby enemies within the splash radius.

## Slow Tower
- 🎮 The Slow tower doesn\

## Tower Upgrades
- Towers upgrade to level 2 and 3.\nEach level multiplies damage and range.\nRight-click a tower to upgrade. Stars show the level.

## Upgrade vs New Tower
- Should players upgrade or buy new?\nThe answer depends on gold-per-DPS efficiency.

## Boss Enemies
- Every 4th wave spawns a Boss huge HP, golden crown, armour that reduces damage.\nIf a boss reaches your base, you lose 5 lives.

## Countering Bosses
- Slow towers reduce boss speed. Snipers deal high single-target damage. Splash is weak against bosses.\nGood design = every tower type shines in different situations.

## Wave Scaling
- Later waves get harder. HP and speed scale by a multiplier each wave.\nHP • 1.2^wave small at first, brutal by wave 8.

## Game Length
- How many waves to win?\nMore = longer, higher ceiling. Fewer = quick and intense.

## Your Finished Tower Defence!
- Your game. Every number, every tower, every balance decision.\nNo two students build the same game.\nPress Run My Game!
