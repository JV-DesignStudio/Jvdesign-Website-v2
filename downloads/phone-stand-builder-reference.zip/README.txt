Phone Stand Builder - Design Your Own 3D Printable Stand
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/phone-stand-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Phone Stand Builder - Design Your Own 3D Printable Stand

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 , IDENTITY - Name Your Stand
- Every great 3D print starts with a purpose. Name your phone stand so you can find it later and feel proud when someone asks where you got it.

## STEP 02 , STYLE - Stand Style
- Choose how your stand is shaped. Angled gives a comfortable viewing angle. Flat is a simple 90° back. Cradle wraps around the phone. Foldable has a hinge mechanism.

## STEP 03 , PHONE - Phone Size
- Set your phone's width and thickness. Most modern smartphones are 65-80mm wide. The iPhone 15 is 71.6mm, Samsung S24 is 70.6mm. Include any case thickness!

## STEP 04 , SCALE - Stand Dimensions
- Set the overall size of your stand in millimetres. Width affects stability. Depth affects the footprint. Height determines how tall the back support is.

## STEP 05 , ANGLE - Viewing Angle
- The angle of the back support determines how you view your phone. The optimal viewing angle for video calls is 60-70 degrees from horizontal.

## STEP 06 , BASE - Base Thickness
- The base plate thickness affects stability and print time. Thicker bases are heavier and more stable but use more filament.

## STEP 07 , LIP - Phone Lip
- The lip at the front holds your phone in place. Taller lips hold thicker phones. The angle helps the phone rest securely against the back.

## STEP 08 , CABLE - Cable Slot
- Add a slot at the bottom of the lip for a charging cable. This lets you charge your phone while it's in the stand.

## STEP 09 , TEXTURE - Grip Texture
- Add a texture to the back support where the phone rests. Ridges give the most grip. Dots look modern. Smooth is easiest to print.

## STEP 10 , COLOUR - Colour
- Pick a colour for your stand. This is the filament colour you'll print with. PLA comes in hundreds of colours , pick one that matches your desk.

## STEP 11 , CORNERS - Rounded Corners
- Rounded corners look better and are more comfortable to handle. They also print slightly better as the nozzle doesn't have to make sharp direction changes.

## STEP 12 , TEXT - Brand Text
- Add your name, logo, or a custom message to the back of the stand. This is purely decorative but makes it uniquely yours.

## STEP 13 , REVIEW - Stats & Preview
- Review your stand design. Check the stats, rotate the 3D preview, and make sure everything looks right before exporting.

## STEP 14 , EXPORT - Export STL
- Your phone stand is ready! Export as STL for 3D printing (Cura, PrusaSlicer, Bambu Studio). You can also export OBJ or GLB for 3D viewers.
