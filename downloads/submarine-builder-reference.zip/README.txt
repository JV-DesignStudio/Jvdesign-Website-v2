Submarine Builder Design Your Own Sub
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/submarine-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Submarine Builder Design Your Own Sub

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 \u2014 IDENTITY - Name Your Sub
- Every submarine needs a name. From the Nautilus to the USS Missouri. Famous subs have names that evoke mystery, power, or the deep ocean. What will yours be called?

## STEP 02 \u2014 HYDRODYNAMICS - Hull Shape
- The hull is the main body. Cylinder is classic and strong. Teardrop is the most hydrodynamic. Flat gives a more industrial look.

## STEP 03 \u2014 SCALE - Hull Size
- How big is your submarine? A small research sub might be 6m. A nuclear attack sub is over 100m. Length affects range and capacity. Radius affects interior space.

## STEP 04 \u2014 LIVERY - Body Color
- The main hull colour. Dark grey is stealthy. Navy blue is classic. Black is ominous.

## STEP 05 \u2014 CONTRAST - Accent Color
- The accent colour appears on conning tower details, fins, propeller, and lights.

## STEP 06 \u2014 COMMAND - Conning Tower
- The conning tower (sail) houses the periscope, navigation equipment, and serves as the command centre.

## STEP 07 \u2014 OBSERVATION - Periscope
- The periscope lets the crew see above the waterline while submerged. It extends from the conning tower.

## STEP 08 \u2014 PROPULSION - Propeller
- The propeller drives the submarine through water. More blades = smoother, quieter operation.

## STEP 09 \u2014 STABILITY - Fins
- Fins at the rear stabilise and steer the submarine. They work like rudders.

## STEP 10 \u2014 OBSERVATION - Portholes
- Portholes are circular windows along the hull. More portholes = more visibility but less structural strength.

## STEP 11 \u2014 DETECTION - Sonar Dome
- The sonar dome at the bow houses the active/passive sonar array. It bounces sound waves off objects to detect vessels and obstacles.

## STEP 12 \u2014 FIREPOWER - Torpedo Tubes
- Torpedo tubes launch underwater missiles at targets. More tubes = more firepower.

## STEP 13 \u2014 COMMUNICATION - Antenna
- The antenna extends from the conning tower for communication when surfaced or at periscope depth.

## STEP 14 \u2014 FINISHING TOUCHES - Details
- Add the final details: light colour for bow lights, window tint for darker portholes, and a stripe band.

## STEP 15 \u2014 EVALUATION - Stats & Preview
- Check your submarine\

## STEP 16 \u2014 DIVE! - Dive!
- All systems are go. Your submarine is fully designed. Hit the dive button to submerge.
