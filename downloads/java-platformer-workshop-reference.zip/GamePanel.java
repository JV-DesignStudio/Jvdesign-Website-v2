// ===== Part 1 of 3 (as shown in the lesson) =====
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements ActionListener {
    Timer timer = new Timer(16, this);   // ~60 FPS

    public GamePanel() {
        setPreferredSize(new Dimension(800, 480));
        setBackground(new Color(25, 30, 60)); // night sky
        timer.start();
    }

    public void actionPerformed(ActionEvent e) {
        update();    // move everything
        repaint();   // then draw everything
    }

    void update() { /* movement goes here soon */ }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // drawing goes here soon
    }
}

// ===== Part 2 of 3 (as shown in the lesson) =====
Rectangle[] platforms = {
        new Rectangle(0, 440, 800, 40),     // ground
        new Rectangle(150, 340, 140, 16),
        new Rectangle(380, 260, 140, 16),
        new Rectangle(610, 180, 140, 16)
    };

    void update() {
        // ... movement + gravity from before ...
        onGround = false;
        Rectangle player = new Rectangle(px, py, pw, ph);
        for (Rectangle plat : platforms) {
            if (player.intersects(plat) && vy >= 0
                && py + ph - vy <= plat.y) {
                py = plat.y - ph;   // snap on top
                vy = 0;
                onGround = true;
            }
        }
    }

    // in paintComponent:
    //   g.setColor(new Color(6, 214, 160));
    //   for (Rectangle plat : platforms) g.fillRect(plat.x, plat.y, plat.width, plat.height);

// ===== Part 3 of 3 (as shown in the lesson) =====
java.util.List<Rectangle> coins = new java.util.ArrayList<>(java.util.List.of(
        new Rectangle(205, 300, 18, 18),
        new Rectangle(435, 220, 18, 18),
        new Rectangle(665, 140, 18, 18)));
    int score = 0;

    void update() {
        // ... previous code ...
        coins.removeIf(c -> {
            if (new Rectangle(px, py, pw, ph).intersects(c)) { score += 10; return true; }
            return false;
        });
    }

    protected void paintComponent(Graphics g) {
        // ... player + platforms ...
        g.setColor(new Color(255, 209, 102));
        for (Rectangle c : coins) g.fillRect(c.x, c.y, c.width, c.height);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 18));
        g.drawString("Score: " + score, 16, 26);
        if (coins.isEmpty()) {
            g.setFont(new Font("Arial", Font.BOLD, 48));
            g.drawString("YOU WIN!", 290, 240);
        }
    }