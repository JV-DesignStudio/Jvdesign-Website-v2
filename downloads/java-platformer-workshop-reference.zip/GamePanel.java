java.util.List<Rectangle> coins = new java.util.ArrayList<>(java.util.List.of(
        new Rectangle(205, 300, 18, 18),
        new Rectangle(435, 220, 18, 18),
        new Rectangle(665, 140, 18, 18)));
    int score = 0;

    void update() {
        // ... previous code ...
        coins.removeIf(c -> {
            if (new Rectangle(px, py, pw, ph).intersects(c)) { score += 10; return true; }
            return false;
        });
    }

    protected void paintComponent(Graphics g) {
        // ... player + platforms ...
        g.setColor(new Color(255, 209, 102));
        for (Rectangle c : coins) g.fillRect(c.x, c.y, c.width, c.height);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 18));
        g.drawString("Score: " + score, 16, 26);
        if (coins.isEmpty()) {
            g.setFont(new Font("Arial", Font.BOLD, 48));
            g.drawString("YOU WIN!", 290, 240);
        }
    }