using UnityEngine.SceneManagement;

public void LoadNextLevel()
{
    int next = SceneManager
        .GetActiveScene().buildIndex + 1;

    if (next < SceneManager.sceneCountInBuildSettings)
        SceneManager.LoadScene(next);
    else
        SceneManager.LoadScene(0); // back to start
}

Complete Project:
+-- Scripts/
·   +-- PlayerController.cs   -> movement, jump, damage
·   +-- CameraFollow.cs       -> third-person follow
·   +-- GameManager.cs        -> singleton, coins, health
·   +-- LevelManager.cs       -> scene loading
·   +-- CoinPickup.cs         -> trigger, destroy
·   +-- StarPickup.cs         -> spin, bob, collect
·   +-- PatrolEnemy.cs        -> waypoint patrol
·   +-- HazardZone.cs         -> instant respawn
·   +-- Checkpoint.cs         -> save spawn point
·   +-- MovingPlatform.cs     -> lerp + parent
·   +-- SpringPad.cs          -> launch + coroutine
·   +-- HUD.cs                -> canvas UI update
+-- Scenes/  Level1 · Level2 · Level3
+-- Prefabs / Materials / Audio