public Vector3 pointA, pointB;

// Platform movement speed (0.2 = slow, 1.5 = fast):
public float speed = ;

private float t = 0f;

void Update()
{
    t += Time.deltaTime * speed;
    transform.position = Vector3.Lerp(
        pointA, pointB,
        (Mathf.Sin(t) + 1f) / 2f); // smooth 0..1
}

void OnCollisionEnter(Collision col)
{
    if (col.gameObject.CompareTag("Player"))
        col.transform.parent = transform;
}