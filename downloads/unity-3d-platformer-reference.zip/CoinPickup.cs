// Coin colour:
coinMat.color = ;

// How many coins in the level (1-12):
int coinCount = ;

void OnTriggerEnter(Collider other)
{
    if (!other.CompareTag("Player")) return;
    GameManager.Instance.coins++;
    Destroy(gameObject);
}