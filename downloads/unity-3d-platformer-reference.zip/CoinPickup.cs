// Coin colour:
coinMat.color = #f5c842;

// How many coins in the level (1-12):
int coinCount = 7;

void OnTriggerEnter(Collider other)
{
    if (!other.CompareTag("Player")) return;
    GameManager.Instance.coins++;
    Destroy(gameObject);
}