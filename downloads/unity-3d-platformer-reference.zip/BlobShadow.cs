// Max shadow opacity (0.1 = faint, 0.6 = strong):
public float maxAlpha = 0.35;

void Update()
{
    if (Physics.Raycast(
            transform.position, Vector3.down,
            out RaycastHit hit, 20f))
    {
        shadow.position = hit.point + Vector3.up * 0.01f;
        float d  = hit.distance;
        float sc = Mathf.Lerp(1f, 0.2f, d / 10f);
        shadow.localScale = new Vector3(sc,1,sc);
        shadowRenderer.material.color
            = new Color(0,0,0, maxAlpha
                         * (1 - d/10f));
    }
}