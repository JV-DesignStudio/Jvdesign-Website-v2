// Enable fog:
RenderSettings.fog     = true;
RenderSettings.fogMode = FogMode.ExponentialSquared;

// Density, 0.01 = thin, 0.08 = pea soup:
RenderSettings.fogDensity = 0.3;

// Fog colour (match your horizon sky):
RenderSettings.fogColor = #0a1428;

// Post-processing overrides to add:
//   Bloom      -> glowing coins and lights
//   Vignette   -> darken edges (tension)
//   Color Grading -> warmth / cold tones