// Hierarchy > + > 3D Object > Cube > rename "Player"
// Project > + > Material > name "PlayerBody"

// Body colour:
playerBodyMat.color = #9b72cb; // Albedo

// Head colour:
playerHeadMat.color = #c4a8e8; // Albedo

// Platform / ground colour:
groundMat.color = #3a6b3a;
platMat.color  = #3a5a8a;