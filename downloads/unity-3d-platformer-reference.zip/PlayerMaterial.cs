// Hierarchy > + > 3D Object > Cube > rename "Player"
// Project > + > Material > name "PlayerBody"

// Body colour:
playerBodyMat.color = ; // Albedo

// Head colour:
playerHeadMat.color = ; // Albedo

// Platform / ground colour:
groundMat.color = ;
platMat.color  = ;