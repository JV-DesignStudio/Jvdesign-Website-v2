// How many · your normal jump force:
public float launchMult = 

void OnTriggerEnter(Collider other)
{
    if (!other.CompareTag("Player")) return;
    var pc = other.GetComponent<PlayerController>();
    pc.velocity.y = pc.jumpForce * launchMult;
}

// Speed boost coroutine:
IEnumerator SpeedBoost()
{
    speed *= 2f;
    yield return new WaitForSeconds(5f);
    speed /= 2f;
}