public Transform target;
// Camera distance, further = see more level:
public float distance  = 14;
public float height    = 5f;
public float smoothing = 5f;

void LateUpdate()
{
    Vector3 goal = target.position
        - target.forward * distance
        + Vector3.up * height;

    transform.position = Vector3.Lerp(
        transform.position, goal,
        smoothing * Time.deltaTime);

    transform.LookAt(target.position
                    + Vector3.up);
}