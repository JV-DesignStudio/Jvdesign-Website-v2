Build a 3D Platformer in Unity
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/unity-3d-platformer.html

Reference project files for this workshop.
These are the finished code files shown step by step in the lesson, so you can
compare your own version or copy a section you are stuck on.

Files:
- AtmosphereSetup.cs
- AudioManager.cs
- BlobShadow.cs
- CameraFollow.cs
- Checkpoint.cs
- CoinPickup.cs
- GameManager.cs
- HUD.cs
- HazardZone.cs + PlayerController.cs
- LevelManager.cs
- LightingSetup.txt
- MovingPlatform.cs
- PatrolEnemy.cs
- PlayerController.cs
- PlayerMaterial.cs
- SpringPad.cs
- StarPickup.cs
- UnityHub Setup

How to use:
1. Unzip this folder somewhere easy to find.
2. Follow the workshop steps and type the code yourself.
3. Stuck? Open the matching file here and compare it line by line.
4. Every code block on the workshop page also has a Copy button.
