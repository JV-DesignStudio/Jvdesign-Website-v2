using TMPro;
using UnityEngine.UI;

// HUD coin text colour:
coinText.color = #f5c842; // accent

void Update()
{
    var gm = GameManager.Instance;
    coinText.text = "🪙 " + gm.coins;

    // Health hearts:
    for (int i=0; i<heartIcons.Length; i++)
        heartIcons[i].enabled = i < gm.health;
}

// Canvas: Hierarchy > + > UI > Canvas
// Add: TextMeshPro, Image (hearts), Slider (XP)
// Install TMP: Package Manager > TextMeshPro