// Enemy colour:
enemyMat.color = #f87171

// How many enemies (1-6):
int enemyCount = 3;

// Patrol speed (0.3 = slow, 2.0 = fast):
public float speed = 0.8;

void Update()
{
    transform.position = Vector3.MoveTowards(
        transform.position, target.position,
        speed * Time.deltaTime);
}