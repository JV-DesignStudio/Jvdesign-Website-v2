// Enemy colour:
enemyMat.color = 

// How many enemies (1-6):
int enemyCount = ;

// Patrol speed (0.3 = slow, 2.0 = fast):
public float speed = ;

void Update()
{
    transform.position = Vector3.MoveTowards(
        transform.position, target.position,
        speed * Time.deltaTime);
}