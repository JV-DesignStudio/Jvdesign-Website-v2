// Inactive colour (before touched):
inactiveMat.color = Color.cyan; // teal pillar

// Active colour (after touched):
// Pick your "activated" checkpoint colour:
activeMat.color   = ;

void OnTriggerEnter(Collider other)
{
    if (activated || !other.CompareTag("Player"))
        return;
    activated = true;
    GetComponent<Renderer>().material.color
        = activeMat.color;
    player.spawnPoint = transform.position;
}