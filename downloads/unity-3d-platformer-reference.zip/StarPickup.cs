// Star colour, make it unmissable:
starMat.color = 

void Update()
{
    // Spin on Y axis:
    transform.Rotate(0, 90 * Time.deltaTime, 0);
    // Bob up and down:
    transform.position += Vector3.up
        * Mathf.Sin(Time.time * 2f) * 0.002f;
}

void OnTriggerEnter(Collider other)
{
    if (!other.CompareTag("Player")) return;
    GameManager.Instance.CollectStar(this);
    Destroy(gameObject);
}