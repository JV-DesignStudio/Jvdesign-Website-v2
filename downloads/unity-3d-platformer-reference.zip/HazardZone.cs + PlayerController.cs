// In PlayerController, i-frames duration:
// (seconds after taking damage you're invincible)
public float iFrames = ;

private float invTimer = 0f;

public void TakeDamage(int amt)
{
    if (invTimer > 0) return; // still invincible
    GameManager.Instance.health -= amt;
    invTimer = iFrames;
    StartCoroutine(FlashRoutine());
}
void Update()
{
    if (invTimer > 0)
        invTimer -= Time.deltaTime;
}