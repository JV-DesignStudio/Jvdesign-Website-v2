// ===== Part 1 of 8 (as shown in the lesson) =====
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Runs ONCE when the scene loads:
    void Start()
    {
        Debug.Log("Player ready!");
    }

    // Runs EVERY FRAME (~60x per second):
    void Update()
    {
        // your code here
    }
}

// Create: Project panel > + > C# Script > name it
// Attach: drag script onto Player in Hierarchy
// OR:     Inspector > Add Component ? type name
// 📝 Filename must exactly match class name!

// ===== Part 2 of 8 (as shown in the lesson) =====
public float moveSpeed = 4; // try 2-10

void Update()
{
    float h = Input.GetAxisRaw("Horizontal"); // A/D
    float v = Input.GetAxisRaw("Vertical");   // W/S

    Vector3 dir = new Vector3(h, 0, v);

    bool jump = Input.GetKeyDown(KeyCode.Space);
}

// ===== Part 3 of 8 (as shown in the lesson) =====
public float speed = 5;

private CharacterController cc;

void Start() =>
    cc = GetComponent<CharacterController>();

void Update()
{
    float h = Input.GetAxisRaw("Horizontal");
    float v = Input.GetAxisRaw("Vertical");
    cc.Move(new Vector3(h,0,v)
             * speed * Time.deltaTime);
}

// Inspector > Add Component ? CharacterController
// Then add your PlayerController script

// ===== Part 4 of 8 (as shown in the lesson) =====
// Gravity multiplier, change the feel:
// 0.5 = moon   1.0 = normal   2.0 = heavy
public float gravityMult = 1.0;

private Vector3 velocity;

void Update()
{
    // Accumulate gravity each frame
    velocity.y += Physics.gravity.y
                  * gravityMult
                  * Time.deltaTime;

    // Small -2 keeps isGrounded reliable
    if (cc.isGrounded && velocity.y < 0)
        velocity.y = -2f;

    cc.Move(velocity * Time.deltaTime);
}

// ===== Part 5 of 8 (as shown in the lesson) =====
// Jump height in world units (try 2-8):
public float jumpHeight = 3

// Jump force directly (preview uses this):
public float jumpForce  = 8;

void Update()
{
    if (Input.GetKeyDown(KeyCode.Space)
        && cc.isGrounded)
    {
        velocity.y = Mathf.Sqrt(
            jumpHeight * 2f
            * Mathf.Abs(Physics.gravity.y));
    }
}

// ===== Part 6 of 8 (as shown in the lesson) =====
private Animator anim;

void Update()
{
    anim.SetFloat("Speed", move.magnitude);
    anim.SetBool("IsGrounded", cc.isGrounded);
    anim.SetFloat("VelocityY", velocity.y);
}

// Animator transitions:
// Idle -> Run:  Speed > 0.1
// Run -> Idle:  Speed = 0.1
// Any -> Jump:  IsGrounded=false, VelocityY > 0
// Any -> Fall:  VelocityY

// ===== Part 7 of 8 (as shown in the lesson) =====
public ParticleSystem jumpDust;
public ParticleSystem coinSparkle;

// Jump particle colour:
jumpDust.startColor = #93d8fc;

// Burst count, particles per jump (1-20):
jumpDust.emission.SetBursts(new[] {
    new ParticleSystem.Burst(0f, 6)
});

if (jump) jumpDust.Play();

// ===== Part 8 of 8 (as shown in the lesson) =====
// 2 = double jump, 3 = triple jump:
public int  maxJumps  = 2;
private int jumpCount = 0;

void Update()
{
    if (cc.isGrounded) jumpCount = 0;

    if (Input.GetKeyDown(KeyCode.Space)
        && jumpCount < maxJumps)
    {
        float mult = (jumpCount == 0) ? 1f : 0.8f;
        velocity.y = jumpForce * mult;
        jumpCount++;
    }
}