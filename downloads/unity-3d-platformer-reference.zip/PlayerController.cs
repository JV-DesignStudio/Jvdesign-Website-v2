using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Runs ONCE when the scene loads:
    void Start()
    {
        Debug.Log("Player ready!");
    }

    // Runs EVERY FRAME (~60x per second):
    void Update()
    {
        // your code here
    }
}

// Create: Project panel > + > C# Script > name it
// Attach: drag script onto Player in Hierarchy
// OR:     Inspector > Add Component ? type name
// 📝 Filename must exactly match class name!