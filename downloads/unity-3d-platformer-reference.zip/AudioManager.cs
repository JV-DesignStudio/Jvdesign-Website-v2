public AudioClip jumpSFX, coinSFX, hurtSFX;
public AudioClip bgMusic;
public float    musicVolume = 0.6f;
public float    sfxVolume   = 1.0f;

void Start()
{
    src.clip = bgMusic;
    src.loop = true;
    src.Play();
}

public void PlayJump() =>
    src.PlayOneShot(jumpSFX, sfxVolume);

// Free SFX sources:
// freesound.org / mixkit.co / opengameart.org
// Import: drag .wav or .mp3 into Project panel