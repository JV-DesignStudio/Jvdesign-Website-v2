public static GameManager Instance;

// Starting health (1 = hard, 5 = easy):
public int maxHealth = 3;
public int health;
public int coins = 0;

void Awake()
{
    if (Instance != null)
    { Destroy(gameObject); return; }
    Instance = this;
    health   = maxHealth;
    DontDestroyOnLoad(gameObject);
}

// Use anywhere: GameManager.Instance.coins++;