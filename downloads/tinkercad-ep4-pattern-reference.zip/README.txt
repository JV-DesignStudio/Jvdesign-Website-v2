Pattern Pop-It
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/tinkercad-ep4-pattern.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Pattern Pop-It

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Plan your design
- Before opening TinkerCAD, grab a piece of paper and a pencil
- Draw the outline shape you want for your pop-it, try a heart, star, animal, or game controller
- Inside the outline, draw circles where the bubbles will go
- Think about the pattern: do you want rows, a spiral, random, or a picture made of bubbles?
- Write down approximate sizes: how big is the overall shape? How big are the bubbles?
- This sketch is your blueprint, it'll make building in TinkerCAD much faster!

## Build your custom shape
- Open TinkerCAD and create a new design: "My Pattern Pop-It"
- For a heart shape: drag two cylinders and a triangle, position them to form a heart outline
- For a star: use the "Star" shape from the Shapes Panel (look under "Basic Shapes" or search "star")
- For a simple custom shape: use the "Scribble" tool, draw any outline freehand!
- Flatten your shape to 4mm height, this is the base thickness
- Make the overall shape about 80-100mm across so there's room for bubbles
- If using multiple shapes to create an outline, select all and Group (Ctrl+G) them into one piece

## Set up precise measurements
- Find the Ruler tool in the top-right toolbar (looks like a small ruler icon)
- Click it, then click on the workplane to place it. A ruler with measurement lines appears
- The ruler shows distances from its origin point, useful for precise positioning
- Drag the ruler to the corner of your base shape
- Now when you drag shapes, you'll see exact distances from the ruler origin
- This helps place bubbles at exact positions instead of guessing by eye
- 20406080100 75 mm 30 mm The Ruler turns guessing into measuring. Drop it at the corner of the plane; from then on, every selected shape shows exact distance numbers you can click and retype. 💡The Ruler tool is essential for patterns. Without it, your bubbles might look randomly placed instead of following a neat pattern. 📝 Fill in the Blanks +15 XP The tool shows exact from its origin point on the workplane. 🔍 Check 🧠 Knowledge Check +15 XP What does the Ruler tool help you do? AMeasure exact positions for precise placement of shapes BDraw straight lines CChange the size of shapes Check Answer ✅ Correct! Next Step → 4 🫧 Create Bubbles in a Pattern Place bubbles following your sketch, not just a grid! Locked 🎯 Goal for this stepCreate bubbles that follow a pattern matching your sketched design. Place your bubbles Create a half-sphere bubble (same technique as Episode 2): sphere at 10mm, position half below workplane
- Place your first bubble at a key position, like the center of your design
- Instead of a simple grid, follow your paper sketch to place bubbles in your pattern
- For a heart shape: place bubbles following the heart outline, then fill the center
- For a spiral: start from the center and place bubbles in a growing spiral
- Use Ctrl+D to duplicate and then move each bubble to its planned position
- Use the Ruler tool to keep spacing consistent, aim for 12-15mm between bubble centers
- 12-15 mm apart follow your paper sketch, outline first, then fill the middle Big bubble at the focal point, the rest tracing the shape. Ctrl+D each new bubble from the last one and nudge it into place with the arrow keys, keeping 12-15 mm between centres. 🔢 Put These in Order +15 XP Click the items in the correct order: Duplicate the bubble and move it to the next position Create your first half-sphere bubble Continue until your pattern is complete Place it at a key starting position 🔄 Reset✅ Check Order 🧠 Knowledge Check +15 XP What makes this pop-it different from Episode 2's pop-it? AIt uses bigger bubbles BIt uses different materials CThe bubbles follow a creative pattern instead of a simple grid Check Answer ✅ Correct! Next Step → 5 🔵 Mix Bubble Sizes Use large, medium, and small bubbles for visual interest Locked 🎯 Goal for this stepCreate bubbles in 3 different sizes and mix them for a more interesting design. Add size variety You've been using 10mm bubbles. Let's add variety!
- Create a large bubble: 14mm diameter half-sphere. Great for center or focal points
- Create a medium bubble: 10mm diameter (your original size). Good for the main pattern
- Create a small bubble: 7mm diameter half-sphere. Perfect for filling gaps and borders
- Place large bubbles at the most important parts of your pattern
- Fill the main pattern with medium bubbles
- Tuck small bubbles into gaps and along the edges for a polished look
- 14 mm · large focal points 10 mm · medium the main pattern 7 mm · small gaps and edges Three sizes make it look designed, not stamped. Resize a duplicated sphere to 14, 10 or 7 mm before placing it, biggest where you want the eye to go first. 💡Mixing sizes creates visual hierarchy, the eye is drawn to the larger bubbles first, making your pattern more interesting. ⚡ True or False? +15 XP Using only one bubble size creates the best designs. TrueFalse Large bubbles work well as focal points in a pattern. TrueFalse Small bubbles are good for filling gaps along edges. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP Why mix bubble sizes in your design? ABecause TinkerCAD requires different sizes BIt creates visual interest and hierarchy, the design looks more professional CSmaller bubbles are easier to 3D print Check Answer ✅ Correct! Next Step → 6 🕳️ Apply the Hole Technique Turn all bubbles into holes and punch them through the base Locked 🎯 Goal for this stepConvert all bubbles to Hole shapes and group with the base. Punch the bubbles Select all your bubble shapes (click first, Shift+click the rest, or use Ctrl+A then Shift+click the base to deselect it)
- Click "Hole" to convert all bubbles to hole shapes
- They all turn translucent with stripes, ready to cut into the base
- Now select everything: all bubbles AND the base shape (Ctrl+A)
- Press Ctrl+G to Group. The bubbles punch dome-shaped impressions into the base!
- Rotate the view to admire your unique pattern pop-it taking shape
- 1 · BUBBLES SET TO HOLE Ctrl+G 2 · GROUPED · DIMPLES! Same two moves as Episode 2: select only the bubbles and click "Hole", then select everything and Ctrl+G. Every bubble becomes a smooth dome dent in your custom shape. 💡If some bubbles didn't cut properly, they might have been floating above the base. Undo (Ctrl+Z), lower them so they overlap the base, then Group again. 🧠 Knowledge Check +15 XP What must you do BEFORE grouping bubbles with the base? AChange all bubbles to Hole shapes BChange the base to a Hole shape CExport as STL first Check Answer ✅ Correct! Next Step → 7 ✨ Add Decorative Elements Add raised borders, embossed name, and details Locked 🎯 Goal for this stepEnhance the design with borders, text, and decorative details. Add finishing touches Create a border: duplicate your base shape outline, make it 4mm bigger all around, and 2mm taller
- Position the border behind your main pop-it and Group them together
- Add your name using the Text tool from the Shapes Panel
- Set the text height to 2mm and position it along the bottom edge of the pop-it
- For raised text: leave it as a solid shape sitting on top of the base
- For embossed text: change it to a Hole, position on the surface, then Group
- Consider adding small decorative shapes, hearts, stars, or dots, around the edge
- darker border ring behind (4 mm bigger) name in Text shape, 2 mm tall The border is your outline again, 4 mm bigger. Duplicate the outline, scale it up, slide it underneath and Group. Raised name = leave the Text solid; stamped name = turn the Text into a Hole first. 📝 Fill in the Blanks +15 XP For embossed text, change the text to a shape before grouping. For raised text, leave it as a shape. 🔍 Check 🧠 Knowledge Check +15 XP What's the difference between raised and embossed text? ARaised text is bigger BRaised text sticks up from the surface; embossed text is cut into the surface CThere's no difference Check Answer ✅ Correct! Next Step → 8 🎨 Choose Your Colour Theme Pick colours that match your design Locked 🎯 Goal for this stepApply a cohesive colour scheme to your pop-it design. Apply your colours Select your pop-it shape. Click the colour swatch in Shape Properties
- Think about your theme: rainbow, pastel, neon, or monochrome?
- For a rainbow pop-it: unfortunately, grouped shapes share one colour in TinkerCAD. Choose your favourite single colour!
- Consider how the colour will look when 3D printed, light colours show detail better
- Popular choices: bright pink, ocean blue, mint green, sunset orange, or classic white
- If printing in multi-colour, you'd need to split the design or use a multi-material printer
- Apply your chosen colour and take a moment to admire your creation!

## Check your design
- Rotate your design and look at it from all angles, especially the bottom
- Wall thickness: make sure no parts are thinner than 1.5mm. Thin walls can break during printing
- Check between adjacent bubbles, the walls between them should be at least 2mm thick
- If bubbles are too close together, move them apart slightly before your final grouping
- Overhangs: the dome impressions face upward, which is perfect, no support material needed
- The base should be flat on the bottom, this is the surface that sits on the print bed
- If you see any floating pieces or disconnected parts, they won't print correctly, fix them!
- 2 mm+ ✨ TOO CLOSE paper-thin, will snap! check every neighbouring pair of bubbles from above before your final group Leave at least 2 mm of plate between bubbles. If two dimples nearly touch, the wall between them prints wafer-thin and snaps on the first pop. Nudge them apart before grouping. ⚡ True or False? +15 XP Walls thinner than 1.5mm can break during 3D printing. TrueFalse Overhangs facing downward always print perfectly. TrueFalse The flat bottom of the pop-it should face the print bed. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP What is the minimum recommended wall thickness between bubbles? A0.5mm B2mm C10mm Check Answer ✅ Correct! Next Step → 10 🌐 Share Your Design Learn TinkerCAD's sharing features and community Locked 🎯 Goal for this stepShare your completed design with others and explore the TinkerCAD community. Share and explore Click "Export" → STL to save your printable file
- Now let's share the design: click the "Share" button in the top toolbar
- You can copy the share link, anyone with this link can view your 3D design in their browser
- TinkerCAD has a Gallery where you can publish your designs for the community to see
- To publish: add a description, tags (like "pop-it", "fidget", "toy"), and a thumbnail image
- Browse the TinkerCAD Gallery to see what other designers have created, get inspiration for your next project!
- You can also "Tinker This" on other people's public designs, remix them and make them your own!
