# ===== Part 1 of 8 (as shown in the lesson) =====
player = pygame.Rect(380, 430, 40, 40)

keys = pygame.key.get_pressed()
if keys[pygame.K_LEFT]:
    player.x -= 8
if keys[pygame.K_RIGHT]:
    player.x += 8
player.x = max(0, min(800 - player.width, player.x))

# ===== Part 2 of 8 (as shown in the lesson) =====
import pygame
pygame.init()
screen = pygame.display.set_mode((800, 480))
pygame.display.set_caption("My Python Game")
clock = pygame.time.Clock()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((25, 30, 60))      # everything you build below is drawn here
    pygame.display.flip()
    clock.tick(60)                 # 60 frames per second

pygame.quit()

# ===== Part 3 of 8 (as shown in the lesson) =====
import random
things = []
spawn_timer = 0

# inside the loop:
spawn_timer += 1
if spawn_timer >= 40:
    spawn_timer = 0
    things.append({
        "rect": pygame.Rect(random.randint(10, 766), -24, 24, 24),
        "kind": "gem"
    })

for t in things[:]:
    t["rect"].y += 5
    if t["rect"].y > 480:
        things.remove(t)

# ===== Part 4 of 8 (as shown in the lesson) =====
kind = "bomb" if random.random() < 0.25 else "gem"
things.append({
    "rect": pygame.Rect(random.randint(10, 766), -24, 24, 24),
    "kind": kind
})

# drawing:
for t in things:
    colour = (248, 113, 113) if t["kind"] == "bomb" else (77, 217, 224)
    pygame.draw.ellipse(screen, colour, t["rect"])

# ===== Part 5 of 8 (as shown in the lesson) =====
score, lives = 0, 3

for t in things[:]:
    if player.colliderect(t["rect"]):
        if t["kind"] == "gem":
            score += 1
        else:
            lives -= 1
        things.remove(t)

# ===== Part 6 of 8 (as shown in the lesson) =====
fall_speed = 5 + score // 10
spawn_at = max(12, 40 - score // 2)
bomb_chance = min(0.5, 0.25 + score * 0.005)

if spawn_timer >= spawn_at:
    ...
    kind = "bomb" if random.random() < bomb_chance else "gem"

# ===== Part 7 of 8 (as shown in the lesson) =====
def load_highscore():
    try:
        with open("highscore.txt") as f:
            return int(f.read())
    except:
        return 0

def save_highscore(value):
    with open("highscore.txt", "w") as f:
        f.write(str(value))

high = load_highscore()

# when the game ends:
if score > high:
    high = score
    save_highscore(high)

# ===== Part 8 of 8 (as shown in the lesson) =====
import pygame, random
pygame.init()
screen = pygame.display.set_mode((800, 480))
pygame.display.set_caption("Gem Dash")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 32)
big_font = pygame.font.SysFont(None, 72)

def load_highscore():
    try:
        with open("highscore.txt") as f:
            return int(f.read())
    except:
        return 0

def save_highscore(value):
    with open("highscore.txt", "w") as f:
        f.write(str(value))

player = pygame.Rect(380, 430, 40, 40)
things = []
spawn_timer = 0
score = 0
lives = 3
game_over = False
high = load_highscore()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r and game_over:
                things = []
                spawn_timer = 0
                score = 0
                lives = 3
                game_over = False

    if not game_over:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player.x -= 8
        if keys[pygame.K_RIGHT]:
            player.x += 8
        player.x = max(0, min(800 - player.width, player.x))

        # difficulty scales with score
        fall_speed = 5 + score // 10
        spawn_at = max(12, 40 - score // 2)
        bomb_chance = min(0.5, 0.25 + score * 0.005)

        spawn_timer += 1
        if spawn_timer >= spawn_at:
            spawn_timer = 0
            kind = "bomb" if random.random() < bomb_chance else "gem"
            things.append({"rect": pygame.Rect(random.randint(10, 766), -24, 24, 24), "kind": kind})

        for t in things[:]:
            t["rect"].y += fall_speed
            if player.colliderect(t["rect"]):
                if t["kind"] == "gem":
                    score += 1
                else:
                    lives -= 1
                things.remove(t)
            elif t["rect"].y > 480:
                things.remove(t)

        if lives <= 0:
            game_over = True
            if score > high:
                high = score
                save_highscore(high)

    # draw
    screen.fill((25, 30, 60))
    pygame.draw.rect(screen, (45, 212, 191), player)
    for t in things:
        colour = (248, 113, 113) if t["kind"] == "bomb" else (77, 217, 224)
        pygame.draw.ellipse(screen, colour, t["rect"])
    screen.blit(font.render("Score: " + str(score), True, (255, 255, 255)), (12, 12))
    screen.blit(font.render("Best: " + str(high), True, (255, 255, 255)), (12, 44))
    screen.blit(font.render("Lives: " + str(max(0, lives)), True, (248, 113, 113)), (680, 12))
    if game_over:
        msg = big_font.render("GAME OVER", True, (255, 209, 102))
        screen.blit(msg, (210, 190))
        screen.blit(font.render("Press R to restart", True, (255, 255, 255)), (300, 270))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()