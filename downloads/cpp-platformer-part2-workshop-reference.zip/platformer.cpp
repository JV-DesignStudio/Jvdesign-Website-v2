class Enemy {
public:
    sf::RectangleShape shape;
    float vx = 120;
    float minX, maxX;
    bool alive = true;

    Enemy(float x, float y, float lo, float hi)
            : minX(lo), maxX(hi) {
        shape.setSize(sf::Vector2f(30, 24));
        shape.setPosition({x, y});
        shape.setFillColor(sf::Color(248, 113, 113));
    }

    void update(float dt) {
        shape.move({vx * dt, 0});
        float x = shape.getPosition().x;
        if (x < minX || x > maxX) vx = -vx;
    }
};

std::vector<Enemy> enemies;
enemies.emplace_back(390, 236, 380, 500);
enemies.emplace_back(60, 416, 40, 700);