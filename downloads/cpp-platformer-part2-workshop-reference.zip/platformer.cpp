// ===== Part 1 of 6 (as shown in the lesson) =====
class Enemy {
public:
    sf::RectangleShape shape;
    float vx = 120;
    float minX, maxX;
    bool alive = true;

    Enemy(float x, float y, float lo, float hi)
            : minX(lo), maxX(hi) {
        shape.setSize(sf::Vector2f(30, 24));
        shape.setPosition({x, y});
        shape.setFillColor(sf::Color(248, 113, 113));
    }

    void update(float dt) {
        shape.move({vx * dt, 0});
        float x = shape.getPosition().x;
        if (x < minX || x > maxX) vx = -vx;
    }
};

std::vector<Enemy> enemies;
enemies.emplace_back(390, 236, 380, 500);
enemies.emplace_back(60, 416, 40, 700);

// ===== Part 2 of 6 (as shown in the lesson) =====
for (auto& en : enemies) {
    if (!en.alive) continue;
    if (pb.findIntersection(en.shape.getGlobalBounds())) {
        float enTop = en.shape.getPosition().y;
        if (player.vy > 0
                && pb.position.y + pb.size.y - player.vy * dt <= enTop + 10) {
            en.alive = false;
            player.vy = -350;      // bounce!
            score += 50;
        } else {
            respawn(player);
        }
    }
}

// ===== Part 3 of 6 (as shown in the lesson) =====
const float LEVEL_W = 2400.f;
sf::View view(sf::FloatRect({0, 0}, {800, 480}));

// each frame:
float cx = player.shape.getPosition().x + 17;
cx = std::max(400.f, std::min(LEVEL_W - 400.f, cx));
view.setCenter(cx, 240);
window.setView(view);

// ... draw world ...
window.setView(window.getDefaultView());
window.draw(scoreText);          // HUD stays put

// ===== Part 4 of 6 (as shown in the lesson) =====
sf::Vector2f respawnPoint(100, 380);

void respawn(Player& p) {
    p.shape.setPosition(respawnPoint);
    p.vx = 0; p.vy = 0;
}

for (auto& cp : checkpoints)
    if (pb.findIntersection(cp))
        respawnPoint = { cp.position.x, cp.position.y - 44 };

for (auto& sp : spikes)
    if (pb.findIntersection(sp))
        respawn(player);

if (player.shape.getPosition().y > 480)   // pit
    respawn(player);

// ===== Part 5 of 6 (as shown in the lesson) =====
struct Level {
    std::vector<sf::FloatRect> platforms, spikes, checkpoints;
    std::vector<Enemy> enemies;
    sf::FloatRect door;
    float width;
};

Level makeLevel(int n) {
    if (n == 0) {
        Level L;
        L.width = 2400;
        L.platforms = { {{0,440},{2400,40}}, {{150,340},{140,16}} /* ... */ };
        L.enemies.emplace_back(390, 236, 380, 500);
        L.spikes = { {760, 424, 40, 16} };
        L.checkpoints = { {1000, 380, 12, 60} };
        L.door = {2320, 380, 30, 60};
        return L;
    }
    // n == 1 ...
}

// ===== Part 6 of 6 (as shown in the lesson) =====
int deaths = 0;                 // ++ inside respawn()
sf::Clock runTimer;             // started at first level load

// champion screen:
int secs = (int)runTimer.getElapsedTime().asSeconds();
championText.setString(
    "CHAMPION!\nTime: " + std::to_string(secs / 60) + "m "
    + std::to_string(secs % 60) + "s\nDeaths: "
    + std::to_string(deaths));