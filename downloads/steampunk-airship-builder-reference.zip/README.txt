Steampunk Airship Dockyard
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/steampunk-airship-builder.html

Offline reference pack for this workshop.

Build and fly a steampunk airship in this free browser game from JVDesignStudio.

This workshop is an interactive builder, so follow it online for the live preview.
This pack keeps a copy of the notes and guidance from the page.

--------------------------------------------------------------------
WORKSHOP NOTES
--------------------------------------------------------------------

## 🎈 Steampunk Airship Dockyard
- Lumo says: Set the gas envelope size first , it drives the whole silhouette. Go large for maximum Victorian drama! ✕ 📘 Guided Build ⭐ Sandbox Build Progress Step 1 of 19 ◀ Prev Next ? Airship: 10m × 3m × 6m Drag to orbit · Scroll to zoom ⭐ Airship Profile Card ? ⬇ Download Profile Card ?🆓 Free In-House Dev Tools

## Make It Yours
- Use these free browser tools alongside this workshop to create custom sprites, sounds, levels and colour schemes for your game. No installs. Free forever.
