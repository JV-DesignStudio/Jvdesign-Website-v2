// Complete Java Space Shooter. Run with:  javac Main.java  then  java Main
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Defend Earth");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new GamePanel());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

class GamePanel extends JPanel implements ActionListener, KeyListener {
    Timer timer = new Timer(16, this);

    int shipX = 280, shipW = 40;
    boolean leftHeld, rightHeld;
    int alienDir = 1, score = 0;
    String state = "PLAY";                       // PLAY / WIN / LOSE
    List<Rectangle> bullets = new ArrayList<>();
    List<Rectangle> aliens  = new ArrayList<>();

    public GamePanel() {
        setPreferredSize(new Dimension(600, 650));
        setBackground(new Color(10, 12, 26));
        addKeyListener(this);
        setFocusable(true);
        spawnAliens();
        timer.start();
    }

    void spawnAliens() {
        aliens.clear();
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 6; c++)
                aliens.add(new Rectangle(60 + c*80, 60 + r*52, 36, 26));
    }

    void reset() {
        shipX = 280; score = 0; alienDir = 1; state = "PLAY";
        bullets.clear(); spawnAliens();
    }

    public void actionPerformed(ActionEvent e) { update(); repaint(); }

    void update() {
        if (!state.equals("PLAY")) return;

        if (leftHeld)  shipX -= 6;
        if (rightHeld) shipX += 6;
        shipX = Math.max(0, Math.min(600 - shipW, shipX));

        for (Rectangle b : bullets) b.y -= 9;
        bullets.removeIf(b -> b.y + b.height < 0);

        // march the wave, step down and reverse at a wall
        boolean hitWall = false;
        for (Rectangle a : aliens)
            if (a.x + alienDir*2 < 0 || a.x + a.width + alienDir*2 > 600) hitWall = true;
        if (hitWall) {
            alienDir = -alienDir;
            for (Rectangle a : aliens) a.y += 14;
        } else {
            for (Rectangle a : aliens) a.x += alienDir * 2;
        }

        // bullets vs aliens
        for (int i = aliens.size() - 1; i >= 0; i--) {
            Rectangle a = aliens.get(i);
            for (int j = bullets.size() - 1; j >= 0; j--) {
                if (a.intersects(bullets.get(j))) {
                    aliens.remove(i);
                    bullets.remove(j);
                    score += 10;
                    break;
                }
            }
        }

        // lose if the wave reaches the ship line, win when cleared
        for (Rectangle a : aliens)
            if (a.y + a.height >= 580) state = "LOSE";
        if (aliens.isEmpty()) state = "WIN";
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(new Color(163, 88, 245));
        for (Rectangle a : aliens) g.fillRect(a.x, a.y, a.width, a.height);
        g.setColor(new Color(250, 204, 21));
        for (Rectangle b : bullets) g.fillRect(b.x, b.y, b.width, b.height);

        g.setColor(new Color(77, 217, 224));
        int[] xs = { shipX + shipW/2, shipX, shipX + shipW };
        int[] ys = { 580, 620, 620 };
        g.fillPolygon(xs, ys, 3);

        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 18));
        g.drawString("Score: " + score, 16, 26);
        if (!state.equals("PLAY")) {
            g.setFont(new Font("Arial", Font.BOLD, 44));
            g.drawString(state.equals("WIN") ? "EARTH SAVED!" : "GAME OVER", 130, 320);
            g.setFont(new Font("Arial", Font.PLAIN, 18));
            g.drawString("Press R to play again", 210, 360);
        }
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT)  leftHeld = true;
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) rightHeld = true;
        if (e.getKeyCode() == KeyEvent.VK_SPACE && state.equals("PLAY"))
            bullets.add(new Rectangle(shipX + shipW/2 - 2, 578, 4, 12));
        if (e.getKeyCode() == KeyEvent.VK_R && !state.equals("PLAY")) reset();
    }
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT)  leftHeld = false;
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) rightHeld = false;
    }
    public void keyTyped(KeyEvent e) {}
}