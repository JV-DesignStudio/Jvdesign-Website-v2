java.util.List<Rectangle> aliens = new java.util.ArrayList<>();
    int alienDir = 1;

    // constructor:
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 6; c++)
            aliens.add(new Rectangle(60 + c*80, 60 + r*52, 36, 26));

    void update() {
        boolean hitWall = false;
        for (Rectangle a : aliens)
            if (a.x + alienDir*2 < 0 || a.x + a.width + alienDir*2 > 600)
                hitWall = true;
        if (hitWall) {
            alienDir = -alienDir;
            for (Rectangle a : aliens) a.y += 14;
        }
        for (Rectangle a : aliens) a.x += alienDir * 2;
    }