// ===== Part 1 of 5 (as shown in the lesson) =====
int shipX = 280, shipW = 40;
    boolean leftHeld, rightHeld;

    void update() {
        if (leftHeld)  shipX -= 6;
        if (rightHeld) shipX += 6;
        shipX = Math.max(0, Math.min(600 - shipW, shipX));
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(new Color(77, 217, 224));
        int[] xs = { shipX + shipW/2, shipX, shipX + shipW };
        int[] ys = { 580, 620, 620 };
        g.fillPolygon(xs, ys, 3);
    }

// ===== Part 2 of 5 (as shown in the lesson) =====
java.util.List<Rectangle> bullets = new java.util.ArrayList<>();

    public void keyPressed(KeyEvent e) {
        // ... arrows ...
        if (e.getKeyCode() == KeyEvent.VK_SPACE)
            bullets.add(new Rectangle(shipX + shipW/2 - 2, 578, 4, 12));
    }

    void update() {
        // ... ship movement ...
        for (Rectangle b : bullets) b.y -= 9;
        bullets.removeIf(b -> b.y + b.height < 0);
    }

    // paintComponent:
    //   g.setColor(new Color(250, 204, 21));
    //   for (Rectangle b : bullets) g.fillRect(b.x, b.y, b.width, b.height);

// ===== Part 3 of 5 (as shown in the lesson) =====
java.util.List<Rectangle> aliens = new java.util.ArrayList<>();
    int alienDir = 1;

    // constructor:
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 6; c++)
            aliens.add(new Rectangle(60 + c*80, 60 + r*52, 36, 26));

    void update() {
        boolean hitWall = false;
        for (Rectangle a : aliens)
            if (a.x + alienDir*2 < 0 || a.x + a.width + alienDir*2 > 600)
                hitWall = true;
        if (hitWall) {
            alienDir = -alienDir;
            for (Rectangle a : aliens) a.y += 14;
        }
        for (Rectangle a : aliens) a.x += alienDir * 2;
    }

// ===== Part 4 of 5 (as shown in the lesson) =====
int wave = 1;

    void spawnWave() {
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 6; c++)
                aliens.add(new Rectangle(60 + c*80, 60 + r*52, 36, 26));
    }

    void update() {
        // ... everything so far ...
        if (aliens.isEmpty()) {
            wave++;
            spawnWave();
        }
        for (Rectangle a : aliens) a.x += alienDir * (1 + wave);
    }

// ===== Part 5 of 5 (as shown in the lesson) =====
boolean gameOver = false;

    void update() {
        if (gameOver) return;
        // ... everything ...
        for (Rectangle a : aliens)
            if (a.y + a.height > 560) gameOver = true;
    }

    // paintComponent:
    if (gameOver) {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 44));
        g.drawString("GAME OVER", 160, 300);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Score: " + score + "   Wave: " + wave, 200, 340);
    }