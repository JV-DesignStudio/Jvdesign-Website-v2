Crystal Frog! Add a Custom Mob to Minecraft with Fabric
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/minecraft-custom-mob-mod.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Crystal Frog! Add a Custom Mob to Minecraft with Fabric

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Files we'll create this episode
- CrystalFrogEntity.java, the frog's brain, health, AI goals
- ModEntities.java, registers the entity type with Fabric
- CrystalFrogModel.java, the 3D box model
- CrystalFrogRenderer.java, tells Minecraft to draw the frog
- ModEntityRenderers.java, client-side renderer registration
- crystal_frog.png, the texture / skin
- Loot table JSON, what drops when the frog dies
- Spawn egg item, added to ModItems.java

## Create the file

## Update CrystalMod.java

## Create the model file

## CrystalFrogRenderer.java

## ModEntityRenderers.java

## CrystalModClient.java

## Update fabric.mod.json
- Frog is invisible (no texture) most likely the client entry point wasn't registered. Double-check fabric.mod.json has a "client" key pointing to com.example.crystalmod.CrystalModClient.
- ClassNotFoundException: CrystalModClient, the class name in fabric.mod.json must exactly match the Java class name, including capitalisation.
- CrystalModClient won't compile it must implement ClientModInitializer, not ModInitializer. Import: net.fabricmc.api.ClientModInitializer.
- EntityRendererRegistry not found Alt+Enter → Import → net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.

## Create the folder structure
- In your file explorer, navigate to src/main/resources/assets/crystalmod/textures/
- Create a new folder called entity inside the textures folder
- Open any pixel art editor (even MS Paint works!) and create a 32✨32 pixel image
- Paint it! Use bright crystal blues and teals, remember the body UVs start at (0,0) and legs start at (0,9) and (8,9)
- Save it as crystal_frog.png inside the entity folder

## Add spawn egg to ModItems.java

## Register entity attributes

## Add spawn egg to creative tab

## Add spawn egg model JSON

## Add language entry

## Create the loot table

## Add natural spawning in CrystalMod.java

## Build and run
- In IntelliJ, open the Gradle panel (right side) → Tasks → fabric → runClient
- Wait for Minecraft to launch (may take 2-3 minutes the first time)
- Create a new Creative world
- Open inventory → search for "Crystal Frog Spawn Egg" → place it in your hotbar
- Right-click on the ground to spawn a Crystal Frog
- Hold a Crystal Gem, the frog should walk towards you!
