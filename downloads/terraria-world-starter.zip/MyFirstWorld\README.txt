Terraria World Workshop - Starter Pack
======================================

Welcome! This folder is the starting point for the Terraria World Workshop
on JVDesignStudio.

WHAT IS IN HERE
  world.json   a small sample world plan you can open and follow
  assets/      put your own world picture here
  README.txt   this file

HOW TO USE IT
  1. Open the Terraria World Studio in your browser (no install needed):
     https://jvdesignstudio.co.uk/workshops/terraria-mod-studio.html
  2. Open world.json to see the shape of a plan.
  3. Build your own plan in the Studio, then follow it in TEdit.

THE REAL LOOP (needs the paid game and a grown-up to help)
  1. Copy one of your worlds as a backup.
  2. Open the copy in TEdit.
  3. Change one tile, then save.
  4. Load the world in tModLoader and look at your change.

ALWAYS keep a backup copy. If something breaks, you put the backup back.
