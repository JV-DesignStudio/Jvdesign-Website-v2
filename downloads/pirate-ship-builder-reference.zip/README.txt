Pirate Ship Shipyard
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/pirate-ship-builder.html

Offline reference pack for this workshop.

Build and sail a pirate ship in this free browser game from JVDesignStudio.

This workshop is an interactive builder, so follow it online for the live preview.
This pack keeps a copy of the notes and guidance from the page.

--------------------------------------------------------------------
WORKSHOP NOTES
--------------------------------------------------------------------

## 🏴‍☠️ Pirate Ship Shipyard
- Lumo says: Start with hull width , everything else scales from it. The animated ocean appears once you finish all 22 steps! ✕ Shipyard Progress Step 1 of 21 ◀ Prev Next ? Ship: 12m × 4m × 3m Drag to orbit · Scroll to zoom ⭐⚓ Ship Profile Card ? ⬇ Download Profile Card ?🆓 Free In-House Dev Tools

## Make It Yours
- Use these free browser tools alongside this workshop to create custom sprites, sounds, levels and colour schemes for your game. No installs. Free forever.
