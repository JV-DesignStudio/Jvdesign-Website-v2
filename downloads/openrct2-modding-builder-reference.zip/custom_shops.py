# ---------------------------------------
#  OpenRCT2 Custom Shops Mod, COMPLETE
#  Made at JVDesignStudio
# ---------------------------------------

PARK_NAME = "My Pixel Park"

shops  = []
items  = []

def create_stall(name, stall_type, colour="orange"):
    stall = {"name":name,"type":stall_type,"colour":colour}
    shops.append(stall)
    return stall

def register_mod():
    print(f"Loading mod: {PARK_NAME}")
    for stall in shops:
        register_stall(stall)
        print(f"  ? {stall['name']} opened!")
    print(f"Mod loaded, {len(shops)} stalls added.")

create_stall("Pip's Ice Creams", "food_stall")
create_stall("Lumo's Juice Bar", "drink_stall",    "blue")
create_stall("Echo's Gift Shop", "souvenir_shop",  "purple")

register_mod()