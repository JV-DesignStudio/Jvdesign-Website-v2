Race Car Builder Design Your Own Race Car
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/race-car-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Race Car Builder Design Your Own Race Car

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 \u00B7 IDENTITY - Name Your Car
- Every race car needs a name. Lightning. Thunderbolt. Firestorm. The greats all had names \u2014 Batmobile, Mach 5, Herbie. What will yours be called?

## STEP 02 \u00B7 CHASSIS - Body Style
- The body defines everything. Formula cars are low and aerodynamic. Muscle cars are big and powerful. Offroad trucks are lifted and rugged. Drift cars are wide and aggressive.

## STEP 03 \u00B7 LIVERY - Body Color
- The main body colour defines your car\

## STEP 04 \u00B7 CONTRAST - Accent Color
- The accent colour appears on wings, spoilers, and details. A contrasting accent makes your car look more professional and intentional.

## STEP 05 \u00B7 POWER - Engine
- The heart of the car. A 4-cylinder is lightweight and rev-happy. A V6 is balanced. A V8 is pure torque. A V12 is screaming power. Electric is instant torque.

## STEP 06 \u00B7 GRIP - Wheels
- Wheels connect power to the road. 5-spoke is classic. Multi-split is modern. Rally is rugged. Slicks are pure track grip.

## STEP 07 \u00B7 DOWNFORCE - Front Wing
- The front wing pushes the nose down, giving more front-end grip. None for low drag. Low for balance. Medium for grip. High for maximum cornering.

## STEP 08 \u00B7 AERO - Rear Spoiler
- The rear spoiler balances the car. Too little and the rear slides out. Too much and you lose top speed. Adjust the angle for fine-tuning.

## STEP 09 \u00B7 AERODYNAMICS - Side Skirts
- Side skirts seal the gap between the car and the ground, improving aerodynamic efficiency. Standard for road cars. Wide for maximum ground effect.

## STEP 10 \u00B7 SOUND - Exhaust
- The exhaust defines the sound. Single is clean. Dual is classic. Quad is aggressive. Side pipes are pure attitude.

## STEP 11 \u00B7 SAFETY - Roll Cage
- A roll cage protects the driver in a crash. None for a clean look. Standard is a visible hoop. Full is a complete cage structure.

## STEP 12 \u00B7 VISIBILITY - Headlights
- Headlights give your car its face. Round is classic. Rectangular is retro. LED is modern and aggressive. None is pure race car.

## STEP 13 \u00B7 DECALS - Livery
- Add a livery to your car. Stripes are classic racing. Flames are aggressive. Tribal is custom culture. Plus your race number.

## STEP 14 \u00B7 FINISHING TOUCHES - Details
- The final details make it yours. Window tint adds attitude. Brake caliper colour is a subtle flex. These small touches add up.

## STEP 15 \u00B7 PERFORMANCE - Stats & Preview
- Your car\

## STEP 16 \u00B7 GREEN FLAG - Race!
- All set. Your car is fully designed. Hit the race button to spin the wheels and watch the smoke fly.
