Money Factory! Build a Tycoon in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-tycoon-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Money Factory! Build a Tycoon in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Build the plot
- Open Roblox Studio ? Baseplate template.
- Add a large Part, size 60, 1, 60, position 0, 0, 0. BrickColor: Medium stone grey. This is the factory floor.
- Add 4 wall parts around the edge (size 60, 8, 1 for front/back, 1, 8, 60 for sides). BrickColor: Dark grey. Position them so they form a box around the floor.
- Add a SpawnLocation (Model tab ? Spawn) inside the box. This is where the player starts.
- Select all the parts you just made, right-click in Explorer ? Group (Ctrl+G). Rename the group Plot.

## Make the dropper box
- Add a Part, size 4, 4, 44, 4, 4. Place it near one corner of your plot, raised up at Y=8. BrickColor: Bright blue. Name it Dropper.
- Set Anchored to true so it doesn't fall.
- Right-click Dropper in Explorer ? Insert Object ? Script. Paste this:
- Press Play to test you should see yellow bricks falling from the box every 2 seconds.

## Add cash to the player
- In the Explorer, find ServerScriptService. Right-click it ? Insert Object ? Script. Name it SetupCash. Paste:

## Build the collector
- Add a Part directly below the Dropper, at the floor level. Size: 6, 1, 66, 1, 6. BrickColor: Bright green. Name it Collector. Set Anchored = true.
- Right-click Collector ? Insert Object ? Script. Paste:
- Press Play and wait a few seconds. Look at the top right of the screen you should see Cash: 10, 20, 30... going up!

## Build the buy pad
- Add a Part, size 6, 0.5, 66, 0.5, 6. BrickColor: Bright red. Material: Neon. Name it BuyPad. Anchored = true. Place it somewhere in your plot.
- Add a second flat part above it as a sign (size 6, 3, 0.26, 3, 0.2) this will show the price. Name it PriceSign.
- Right-click BuyPad ? Insert Object ? Script. Paste:

## Update the buy pad script
- Add a second Part (size 4, 4, 44, 4, 4, BrickColor Bright red) somewhere in your plot. Anchor it. Name it Dropper2. In Properties, set Transparency to 11 so it's invisible at the start.
- Add a Script inside Dropper2, same dropper script from Step 2, but change task.wait(2) to task.wait(1) for double speed. Also start the script with:
- Add a BindableEvent inside Dropper2: right-click Dropper2 ? Insert Object ? BindableEvent. Name it UnlockEvent.
- In your BuyPad script, after print("Purchased!") add: workspace.Dropper2.UnlockEvent:Fire().

## Create the GUI
- In Explorer, find StarterGui. Right-click ? Insert Object ? ScreenGui. Name it CashGui.
- Right-click CashGui ? Insert Object ? TextLabel. Name it CashLabel.
- Select CashLabel. In Properties: set Text to 💰 $0, TextSize to 28, TextColor3 to yellow, Font to GothamBold.
- Set Position to {0.02, 0}, {0.05, 0} (top-left corner) and Size to {0.2, 0}, {0.06, 0}.
- Set BackgroundTransparency to 1 so there's no background box.
- Right-click CashGui → Insert Object → LocalScript. Paste:

## Add a BillboardGui
- Select your BuyPad in Explorer. Right-click ? Insert Object ? BillboardGui.
- Set its Size to {0, 200}, {0, 50} and StudsOffset to 0, 4, 0 (floats 4 studs above the pad).
- Right-click BillboardGui ? Insert Object ? TextLabel. Set Text to 💰 $50💰 $50. Set TextScaled to true. Set BackgroundTransparency to 1. Set TextColor3 to white. Set Font to GothamBold.
- Also set Size on the TextLabel to {1,0},{1,0}{1,0},{1,0} (fill the whole BillboardGui).
- Press Play, you should see the price floating above the pad!

## Decoration ideas
- Add tall thin cylinder parts as chimney stacks. Set Material to Metal.
- Add Neon coloured flat parts as glowing floor strips or warning lights.
- Use SpecialMesh (right-click a part ? Insert Object ? SpecialMesh, set MeshType to Cylinder or Sphere) to make pipes or tanks.
- Add PointLight objects inside Neon parts (Insert Object ? PointLight) to cast coloured light.
- Group all your decorations into a folder called Decorations to keep Explorer tidy.

## Enable API access
- Go to Home ? Game Settings ? Security. Turn on Enable Studio Access to API Services. Click Save.

## Update the SetupCash script
- Open the SetupCash script in ServerScriptService. Replace it with this full version:
- Press Play. Wait for cash to build up from the dropper.
- Walk onto the BuyPad when you have $50. Confirm Dropper2 appears and the pad turns green.
- Check the Cash GUI updates correctly.
- Press Stop.
- Go to File ? Publish to Roblox. Set a fun name like "My Money Factory Tycoon!" and set Privacy to Public.
- Share the game link with friends and family!
