Space Station Builder Design Your Own Orbital Outpost
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/space-station-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Space Station Builder Design Your Own Orbital Outpost

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 , IDENTITY - Name Your Station
- Every space station needs a name. International Space Station. Mir. Tiangong. Skylab. What will your orbital outpost be called?

## STEP 02 , STRUCTURE - Module Style
- Modules are the core building blocks of your station. Cylinders are pressure-optimized (like real ISS modules). Box modules are easier to outfit and give a more futuristic look.

## STEP 03 , SCALE - Module Count
- How many modules will your station have? More modules = more labs, more crew space, more capability. But also more mass to launch and maintain.

## STEP 04 , DIMENSIONS - Module Size
- Set the length and radius of each module. Longer modules hold more equipment. Wider modules give more internal volume for crew.

## STEP 05 , LIVERY - Body Colour
- The primary colour of your station modules. White reflects sunlight and keeps modules cool. Silver is modern. Dark colours absorb heat , fine for deep-space stations.

## STEP 06 , CONTRAST - Accent Colour
- The accent colour appears on connector bands, the truss, and the rotating ring. A contrasting accent makes your station look designed and professional.

## STEP 07 , POWER - Solar Panels
- Solar panels are your station\'s lifeline. They convert sunlight into electricity. More panels = more power for experiments, life support, and communications.

## STEP 08 , ACCESS - Docking Ports
- Docking ports allow spacecraft to connect to your station. Crew Dragon, Soyuz, Cargo ships , they all need a port to attach to.

## STEP 09 , COMMUNICATIONS - Antennas
- Antennas keep your station connected to Earth. Voice, video, telemetry, science data , it all flows through these. More antennas = more bandwidth.

## STEP 10 , OBSERVATION - Cupola
- The cupola is an observation dome , a multi-windowed dome that gives crew a panoramic view of Earth and approaching spacecraft. It\'s the most iconic feature of the ISS.

## STEP 11 , BACKBONE - Truss
- The truss is the structural backbone that holds your solar panels, radiators, and external equipment. A longer truss means more room for power generation.

## STEP 12 , THERMAL - Radiators
- Space is both freezing cold and scorching hot. Radiators dump excess heat from electronics, life support, and crew metabolism into the void.

## STEP 13 , CREW - Crew Capacity
- How many people can live and work on your station? More crew means more experiments, but also more life support, food, water, and oxygen.

## STEP 14 , ARTIFICIAL GRAVITY - Rotating Ring
- A rotating ring creates artificial gravity through centripetal acceleration. No real station has one yet, but it\'s a staple of science fiction and future station concepts.

## STEP 15 , REVIEW - Stats & Preview
- Review your station\'s capabilities. The stats reflect your design choices , more modules boost capacity, solar panels boost power, antennas boost science.

## STEP 16 , ORBIT - Launch Station!
- All systems are go. Your station is fully designed. Hit the launch button to deploy it into orbit and watch it come alive.
