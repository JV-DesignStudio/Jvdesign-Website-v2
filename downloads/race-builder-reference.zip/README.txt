Race Builder, Build a Top-Down Racer
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/race-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Race Builder, Build a Top-Down Racer

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 · CAR SETUP - Name Your Car
- Every racing game starts with one thing: your car. Give it a name, this will appear on the scoreboard. Then pick a colour. Your car's identity is the first thing the game engine needs before it can spawn you onto the track.

## STEP 02 · SPEED - Set Top Speed
- Top speed is the fastest your car can travel. In our engine it's measured as pixels per frame, a value of 3 to 7 feels like a real race. Too low and the game drags. Too high and you can't steer around corners.

## STEP 03 · ACCELERATION - Set Acceleration
- Acceleration controls how quickly your car reaches top speed. A high value means instant reaction, great for tight tracks. A lower value means slow build-up but more strategic driving. Try values between 0.05 and 0.25.

## STEP 04 · HANDLING - Set Handling (Turning)
- Handling controls how sharply your car turns. Higher values mean tighter cornering, great for technical tracks. Lower values mean wide, sweeping turns that suit high-speed driving. Try 0.03 to 0.09.

## STEP 05 · TRACK - Draw the Track
- Time to draw the oval track. Until now the background is just a grid. Applying this step switches on the real track: an oval road surface, kerbs, a grass infield, and a start/finish line. Your car will now be kept on the road, go off-track and you'll slow down.

## STEP 06 · RIVALS - Add Rivals
- A race needs opponents. Set how many rival cars appear on track. They use a simple AI: they follow the centre of the track and try to match your speed. You\'ll need to out-drive them, not just drive fast.

## STEP 07 · LAPS - Set Number of Laps
- Now we count laps. Every time your car crosses the start/finish line, the lap counter goes up. Set how many laps make a full race. The HUD shows your current lap. Complete all laps to finish the race.

## STEP 08 · BOOST - Add Boost Pads
- Boost pads add a skill layer, hit one and your car surges forward for 1 second. They\'re placed at four positions around the track. After you collect one it recharges before you can use it again. Set the boost speed multiplier.

## STEP 09 · FINISH - Wire the Finish Line
- The final piece: detect when the race ends. Once your car completes all laps, the game shows your finishing position and time. If you beat all rivals you win. Now all the systems are connected into a complete racing game.

## STEP 10 · TUNING - Fine-Tune & Experiment
- You have a complete racing game. Now tune it. Go back to any step and change a value, speed, handling, rivals, boost. Every change applies instantly. This is what game designers do: iterate until it feels right.
