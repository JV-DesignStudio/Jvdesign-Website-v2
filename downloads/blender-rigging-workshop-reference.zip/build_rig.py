# build_rig.py - Blender 4.x
# My First 3D Model Ep 3: Rigging & Bones
import bpy

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# 1. A simple body mesh
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 1))
body = bpy.context.active_object
body.name = "Body"
body.scale = (0.4, 0.3, 1.0)

# 2. Add an armature
bpy.ops.object.armature_add(enter_editmode=True, location=(0, 0, 0))
arm = bpy.context.active_object
arm.name = "Rig"
eb = arm.data.edit_bones
eb[0].name = "Spine"
eb[0].head = (0, 0, 0)
eb[0].tail = (0, 0, 2)
lower = eb.new("Lower")
lower.head = (0, 0, 0)
lower.tail = (0, 0, 1)
lower.parent = eb["Spine"]
bpy.ops.object.mode_set(mode='OBJECT')

# 3. Parent the mesh to the rig with automatic weights
body.select_set(True)
arm.select_set(True)
bpy.context.view_layer.objects.active = arm
bpy.ops.object.parent_set(type='ARMATURE_AUTO')

print("Rig created. Select the armature and press Ctrl+Tab to pose it.")
