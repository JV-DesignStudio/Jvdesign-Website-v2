My First 3D Model Ep 3: Rigging & Bones
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/blender-rigging-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First 3D Model Ep 3: Rigging & Bones

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Open your Episode 2 character.blend.
- Cursor to world centre (Shift+C), then Shift+A ? Armature. One bone appears, probably inside the body. Enable In Front (Armature properties ? Viewport Display) to see it through the mesh!
- Tab into Edit Mode ON THE ARMATURE. A bone has a head, a body and a tip.
- Select the TIP, extrude with E, a connected child bone! Build a spine: hips ? chest ? neck ? head, matching your character-s height.
- Name every bone NOW (double-click in the outliner): "spine", "chest", "neck", "head". Future-you says thanks.
- Arm chain: select the chest bone tip, E to extrude out to the shoulder, then upper arm, then forearm, then hand, following YOUR mesh (front view helps).
- Naming with a suffix: upper_arm.L, forearm.L, hand.L, the .L matters!
- Leg chain the same: thigh.L, shin.L, foot.L, from the hip area down.
- The payoff: select ALL bones (A), right-click ? Symmetrize. Blender builds the whole .R side, perfectly mirrored, correctly named.
- That .L/.R naming convention powers half of Blender-s animation tools, always use it.
- Object Mode. Select the MESH first, then Shift+Click the ARMATURE (order matters, active object last!).
- Ctrl+P ? With Automatic Weights. Blender calculates how much each bone influences every vertex.
- Test immediately: select the armature, switch the mode dropdown to Pose Mode, select the forearm bone, press R and rotate-
- -THE ARM BENDS. Take a second. You built a puppet.
- Reset any test pose with Alt+R (clear rotation), poses are not saved unless keyframed (Episode 4).
- In Pose Mode, bones rotate (R) around their joints, that is 95% of posing. G is only for the root/hips.
- Pose 1: a wave, shoulder up, elbow bent, repeat on the other arm for a cheer.
- Pose 2: a walk stance, opposite arm and leg forward (this is Episode 4 homework arriving early).
- Pose 3: crouched superhero landing, bend EVERYTHING. This one shows off every joint.
- While posing, watch the elbows and knees closely- see any mesh crumpling? Note where. Next step fixes it.
- Sometimes rotating an arm drags part of the chest, a vertex got weighted to the wrong bone.
- Select the mesh, switch to Weight Paint mode. Blue = no influence, red = full influence, shown for the SELECTED bone (Ctrl+click a bone to switch).
- Paint fixes: brush with weight 1 to ADD influence, weight 0 to REMOVE (the chest verts stealing from the arm get weight-0 brushed).
- Small brush, low strength, gradual passes. Rotate the bone WHILE painting to watch the fix live.
- Automatic weights get you 90% there; weight painting is the pro 10%.
- Every good rig has a root bone at the floor: Edit Mode, add a bone at the origin, name it "root", then make the hips its child (select hips, then root, Ctrl+P ? Keep Offset).
- Now grabbing root moves the WHOLE character, that is how characters travel through scenes.
- QA checklist: ? every joint bends cleanly ? no mesh left behind on any pose ? Symmetrize named everything .L/.R ? root moves all.
- Save as character-rigged.blend. Episode 4: keyframes, a bounce, and a walk cycle for THIS rig!


--------------------------------------------------------------------
BONUS: BLENDER PYTHON BUILDER
--------------------------------------------------------------------
This pack also includes build_rig.py, a script that builds a "Rigging & Bones" setup for you.

How to run it:
1. Open Blender 4.x.
2. Go to the Scripting tab, click Open, and choose build_rig.py.
3. Click Run Script (the play button). The model appears in your scene.
4. Press F12 to render, or keep building on top of it.
