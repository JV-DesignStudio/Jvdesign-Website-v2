My First 3D Prints, Fidget Toy
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/my-first-3d-prints-fidget-toy.html

Offline reference pack for this workshop.

Free parent & child TinkerCad workshop. Design and 3D print your first fidget toy. No experience needed. Ages 8+.

This workshop is an interactive builder, so follow it online for the live preview.
This pack keeps a copy of the notes and guidance from the page.

--------------------------------------------------------------------
WORKSHOP NOTES
--------------------------------------------------------------------

## My First 3D Prints
- Design and 3D print your first fidget toy with your child using TinkerCad. No experience needed. Each workshop takes about 1-2 hours and guides you through every step.

## 8 3D Prints to Design Together
- Start at Episode 1 and work through or jump to any episode that sounds fun. Each one teaches new 3D design skills using TinkerCad's simple drag-and-drop interface. From fidget toys to functional items, games, and collectibles!
- Magnets · Assembly · Export Magnetic Building Blocks Design interlocking cubes that snap together magnetically. Learn to create press-fit holes for magnets and understand sizing for 3D printing. Discover how to export your design. Ages 8+ 10 Steps · ~1.5 hrs Start Building ? Ep 4 Customization · Patterns · Sharing Your Unique Fidget: Pattern Pop-It Bring it all together and create your own custom pop-it fidget toy with unique shapes and patterns. Learn to save, share, and prepare your design for 3D printing or online ordering. Ages 8+ 10 Steps · ~1.5 hrs Start Building ? Ep 5 Angles · Stability · Functional Design Phone Stand: Learn Angles & Support Design a tilted phone or tablet stand that's both functional and stable. Master angles, learn how to calculate support, and create something you'll actually use every day. Ages 8+ 9 Steps · ~1 hr Start Building ? Ep 6 Channels · Ramps · Physics Marble Run: Create Tracks & Ramps Design a marble run with tracks, ramps, and jumps. Learn how channels guide objects and explore gravity and physics through 3D design. Watch marbles roll through your creation! Ages 8+ 12 Steps · ~2 hrs Start Building ? Ep 7 ABC Text · Extrusion · Personalization Custom Keychain: Add Your Name Learn to add text to your 3D designs and extrude it into a custom keychain. Create personalized gifts for friends and family. Discover how 2D designs become 3D objects. Ages 8+ 8 Steps · ~1 hr Start Building ? Ep 8 Collections · Multiple Objects · Organization Geometric Shape Set: Learn & Play Design a complete set of 3D geometric shapes cubes, spheres, pyramids, and more. Learn how basic shapes combine to create complexity. Perfect for math learning and creative play. Ages 8+ 15 Steps · ~2 hrs Start Building ? Ready to Design & Print? Start with Episode 1 to learn the basics of 3D design in TinkerCad. By episode 4, you'll have a finished fidget toy design ready to 3D print or order online!

## FAQ

## Where to next?
- Finished here, or just curious? These series are a natural next step, same step-by-step format, bigger games.
- Turn your idea into a prototype
- Plan it in Game Design Studio, then build a playable version in Arcade Game Maker.
