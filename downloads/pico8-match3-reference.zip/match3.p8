pico-8 cartridge // http://www.pico-8.com
version 41
__lua__
-- match3.p8  JVDesignStudio
function _init()
  g=14
  cols={8,12,11,10,14}
  grid={}
  for y=1,8 do
    grid[y]={}
    for x=1,8 do
      grid[y][x]=flr(rnd(5))+1
    end
  end
  cx=1 cy=1 sel=nil score=0
  resolve()
end

function draw_gem(x,y,t)
  local c=cols[t]
  local px=(x-1)*g+18
  local py=(y-1)*g+18
  rectfill(px,py,px+g-3,py+g-3,c)
end

function find_matches()
  local marks={}
  for y=1,8 do
    local run=1
    for x=2,9 do
      if x<=8 and grid[y][x]==grid[y][x-1] then
        run=run+1
      else
        if run>=3 then
          for k=x-run,x-1 do marks[y*10+k]=true end
        end
        run=1
      end
    end
  end
  for x=1,8 do
    local run=1
    for y=2,9 do
      if y<=8 and grid[y][x]==grid[y-1][x] then
        run=run+1
      else
        if run>=3 then
          for k=y-run,y-1 do marks[k*10+x]=true end
        end
        run=1
      end
    end
  end
  return marks
end

function resolve()
  local cleared=0
  while true do
    local marks=find_matches()
    local any=false
    for y=1,8 do
      for x=1,8 do
        if marks[y*10+x] then any=true cleared=cleared+1 end
      end
    end
    if not any then break end
    for y=1,8 do
      for x=1,8 do
        if marks[y*10+x] then grid[y][x]=0 end
      end
    end
    for x=1,8 do
      local write=8
      for y=8,1,-1 do
        if grid[y][x]~=0 then
          grid[write][x]=grid[y][x]
          write=write-1
        end
      end
      for y=write,1,-1 do
        grid[y][x]=flr(rnd(5))+1
      end
    end
  end
  score=score+cleared
end

function _update()
  if btnp(0) then cx=max(1,cx-1) end
  if btnp(1) then cx=min(8,cx+1) end
  if btnp(2) then cy=max(1,cy-1) end
  if btnp(3) then cy=min(8,cy+1) end
  if btnp(4) then
    if sel==nil then
      sel={x=cx,y=cy}
    else
      if abs(sel.x-cx)+abs(sel.y-cy)==1 then
        local a=grid[sel.y][sel.x]
        grid[sel.y][sel.x]=grid[cy][cx]
        grid[cy][cx]=a
        resolve()
      end
      sel=nil
    end
  end
end

function _draw()
  cls(0)
  for y=1,8 do
    for x=1,8 do
      draw_gem(x,y,grid[y][x])
    end
  end
  local px=(cx-1)*g+18
  local py=(cy-1)*g+18
  rect(px-2,py-2,px+g-1,py+g-1,7)
  if sel then
    local sx=(sel.x-1)*g+18
    local sy=(sel.y-1)*g+18
    rect(sx-2,sy-2,sx+g-1,sy+g-1,10)
  end
  print("score "..score,2,2,7)
end
