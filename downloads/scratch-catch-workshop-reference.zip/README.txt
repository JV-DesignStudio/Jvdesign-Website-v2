Don't Drop It! Build a Fruit Catch Game in Scratch
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/scratch-catch-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Don't Drop It! Build a Fruit Catch Game in Scratch

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Get started
- Open a browser and go to scratch.mit.edu.
- Click the big orange Start Creating button. A new project opens.
- You'll see the Stage (the white area on the right where your game runs) and the Blocks Panel on the left.
- In the middle is the Scripts Area, this is where you drag blocks to build your game.
- There's already a Scratch Cat sprite on the stage. We'll delete it in the next step and use our own sprites.

## Remove the cat and add a basket
- In the Sprite Panel (bottom right), right-click the Scratch Cat and choose Delete. The stage is now empty.
- Click the blue Choose a Sprite button (cat icon, bottom right). The sprite library opens.
- Search for "Bowl" or choose any wide sprite that looks like a container. Click it to add it.
- Click the Costumes tab (top left) to see the sprite's artwork. You can draw on it to make it look more like a basket if you want!
- Click the Code tab to go back to scripts. In the Properties panel (bottom of screen), set Size to 80 and drag the sprite to the bottom-centre of the stage.

## Add movement blocks to the basket sprite
- Make sure the basket sprite is selected (click it in the Sprite Panel).
- Click the Events category (yellow) and drag a "when 🏳 clicked" block into the Scripts Area.
- Click Control (orange) and attach a "forever" loop block underneath.
- Click Control again and drag an "if < > then" block inside the forever loop.
- Click Sensing (light blue) and drag "key [space] pressed?" into the diamond gap. Click the dropdown and change it to "right arrow".
- Click Motion (blue) and put "change x by (10)" inside the if block.
- Add another if block below it (still inside forever). This time check for "left arrow" and use "change x by (-10)".
- Press the Green Flag to test. Your basket should move left and right!

## Add the fruit sprite
- Click Choose a Sprite and search for "Apple" or any fruit you like. Add it to the stage.
- Set its Size to 50 in the properties area.
- Click the Code tab with the fruit sprite selected.
- Drag a "when 🏳 clicked" block in. Attach a "forever" loop.
- Inside forever, add "go to x: (pick random -200 to 200) y: (180)", this puts the fruit at a random spot at the top.
- Now add a "repeat until" loop. For the condition, use "y position < -160" (Operators category, green, pick the < block and fill in the Sensing y position block on the left).
- Inside the repeat, add "change y by (-5)". This makes the fruit fall 5 pixels every step.
- Press the Green Flag. The fruit should fall from the top, reach the bottom, then restart from a new random position!

## Create the Score variable
- Click Variables (orange) in the blocks panel, then click "Make a Variable". Name it Score and click OK.
- A Score counter appears on the stage automatically.
- Select the Fruit sprite and find your falling script. Inside the repeat until loop, add an "if < > then" block.
- For the condition, use Sensing → "touching [Sprite1]?", pick your basket sprite from the dropdown.
- Inside that if block, add Variables → "change Score by (1)".
- Also add "go to x: (pick random -200 to 200) y: (180)" right after it, this resets the fruit immediately when caught.

## Create a Speed variable
- Go to Variables → Make a Variable. Name it Speed. Uncheck the box next to it so it doesn't show on screen.
- At the top of your fruit script (right after "when 🏳 clicked"), add "set Speed to (5)".
- Change your "change y by (-5)" block to "change y by (Speed ✨ -1)", use the Operators multiply block with Speed and -1.
- After the catch block that adds score, add an "if Score > 5 then set Speed to 8" block.
- Add another: "if Score > 10 then set Speed to 12".
- Add a final one: "if Score > 20 then set Speed to 16".

## Add Lives
- Make a new variable called Lives. Set it to 3 at the start of your fruit script.
- After your repeat until y < -160 loop ends (the fruit hit the floor), add "change Lives by (-1)".
- Below that, add an "if Lives < 1 then" block.
- Inside that if block, add Looks → "say [Game Over! Score: ] for (2) seconds".
- Then add Control → "stop [all]" to end the game completely.

## Add a backdrop
- Click the Stage thumbnail (bottom right, below your sprites). Click "Choose a Backdrop".
- Pick a fun background, try "Blue Sky" or "Farm" for a fruity feel!
- Press the Green Flag and play through the whole game. Try to reach 20 points!
- Check lives work correctly, 3 lives, game over when they run out.
- If you have an account, click File → Save now to save your project.
- Click the orange Share button at the top right. Your game gets a public URL!
- Copy the link and send it to friends and family so they can play your game.
- Navigating the Scratch interface: Stage, Scripts Area, Sprite Panel and block categories
- Building movement with Events, Control loops, Sensing and Motion blocks
- Using variables to track Score, Speed and Lives across the game
- Detecting collisions with the touching block and conditional logic
- Creating a game-over screen with the stop all block and the say block for messages
