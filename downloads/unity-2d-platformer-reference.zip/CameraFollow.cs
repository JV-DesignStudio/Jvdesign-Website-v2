public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float   smoothSpeed  = 0.12f;
    public Vector3  offset       = new Vector3(2,1,-10);

    void LateUpdate()
    {
        // Lerp = smoothly blend from A to B
        Vector3 desired = target.position + offset;
        Vector3 smoothed = Vector3.Lerp(
            transform.position,
            desired,
            smoothSpeed);

        transform.position = smoothed;
    }
}