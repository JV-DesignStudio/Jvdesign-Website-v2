public class CoinController : MonoBehaviour
{
    public int value = 10;

    // Runs when player overlaps this trigger:
    void OnTriggerEnter2D(Collider2D other)
    {
        // Check it's actually the player:
        if (other.CompareTag("Player"))
        {
            // Add to score via GameManager:
            GameManager.instance
                .AddScore(value);

            // Play collect sound and destroy self:
            AudioSource.PlayClipAtPoint(
                collectSound,
                transform.position);

            Destroy(gameObject);
        }
    }
}