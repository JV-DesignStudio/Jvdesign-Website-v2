using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public int lives = 3;
    public int score = 0;

    void Awake()
    {
        // Singleton persist across scenes:
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else Destroy(gameObject);
    }

    public void LoadNextScene()
    {
        int next = SceneManager
            .GetActiveScene().buildIndex + 1;
        SceneManager.LoadScene(next);
    }
}