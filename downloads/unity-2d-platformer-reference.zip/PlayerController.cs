void OnCollisionEnter2D(Collision2D col)
{
    if (col.CompareTag("Enemy"))
    {
        // Where did we hit? Check contact normal
        bool stompedFromAbove =
            col.contacts[0].normal.y > 0.5f;

        if (stompedFromAbove)
        {
            // Kill enemy, bounce player up:
            Destroy(col.gameObject);
            _rb.linearVelocity = new Vector2(
                _rb.linearVelocity.x, jumpForce * 0.6f);
        }
        else
        {
            // Player takes damage:
            GameManager.instance.LoseLife();
        }
    }
}