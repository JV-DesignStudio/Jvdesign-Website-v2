// ===== Part 1 of 6 (as shown in the lesson) =====
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Unity calls these automatically:

    void Start()
    {
        // Runs ONCE when the scene loads
        Debug.Log("Player ready!");
    }

    void Update()
    {
        // Runs EVERY FRAME (~60x per second)
        // Movement and input checks go here
    }
}

// ===== Part 2 of 6 (as shown in the lesson) =====
public class PlayerController : MonoBehaviour
{
    private Rigidbody2D _rb;

    void Start()
    {
        // Get the Rigidbody2D component
        // on this same GameObject:
        _rb = GetComponent<Rigidbody2D>();

        // Freeze Z rotation (2D games only):
        _rb.constraints =
            RigidbodyConstraints2D.FreezeRotation;
    }

    void FixedUpdate()
    {
        // Physics runs in FixedUpdate, NOT Update()
        Debug.Log("velocity: " + _rb.linearVelocity);
    }
}

// ===== Part 3 of 6 (as shown in the lesson) =====
public float moveSpeed = 5;

void FixedUpdate()
{
    // GetAxisRaw = snappy (-1, 0, 1), no smoothing
    float h = Input.GetAxisRaw("Horizontal");

    // Set X velocity, keep Y (for gravity):
    _rb.linearVelocity = new Vector2(
        h * moveSpeed,
        _rb.linearVelocity.y   // keep vertical!
    );

    // Flip the sprite to face movement direction:
    if (h != 0)
        transform.localScale = new Vector3(
            h, 1, 1);
}

// ===== Part 4 of 6 (as shown in the lesson) =====
public float jumpForce   = 10;
public Transform groundCheck;   // empty child GameObject at feet
public LayerMask  groundLayer;

private bool _grounded;

void Update()
{
    // Check ground every frame:
    _grounded = Physics2D.OverlapCircle(
        groundCheck.position, 0.1f, groundLayer);

    // Only jump if grounded:
    if (Input.GetButtonDown("Jump") && _grounded)
    {
        _rb.linearVelocity = new Vector2(
            _rb.linearVelocity.x,
            jumpForce);
    }
}

// ===== Part 5 of 6 (as shown in the lesson) =====
private Animator _anim;

void Start()
{
    _rb   = GetComponent<Rigidbody2D>();
    _anim = GetComponent<Animator>();
}

void Update()
{
    float h = Input.GetAxisRaw("Horizontal");

    // Set Animator parameters:
    _anim.SetFloat("Speed",
        Mathf.Abs(_rb.linearVelocity.x));

    _anim.SetBool("IsGrounded", _grounded);

    _anim.SetFloat("VerticalVelocity",
        _rb.linearVelocity.y);
}

// ===== Part 6 of 6 (as shown in the lesson) =====
void OnCollisionEnter2D(Collision2D col)
{
    if (col.CompareTag("Enemy"))
    {
        // Where did we hit? Check contact normal
        bool stompedFromAbove =
            col.contacts[0].normal.y > 0.5f;

        if (stompedFromAbove)
        {
            // Kill enemy, bounce player up:
            Destroy(col.gameObject);
            _rb.linearVelocity = new Vector2(
                _rb.linearVelocity.x, jumpForce * 0.6f);
        }
        else
        {
            // Player takes damage:
            GameManager.instance.LoseLife();
        }
    }
}