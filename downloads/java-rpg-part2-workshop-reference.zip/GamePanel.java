boolean defending = false;

    void battleAction(char key) {
        defending = false;
        if (key == 'a') {
            int dmg = hero.getAttack() + (int)(Math.random()*4) - 1;
            foe.takeDamage(dmg);
            battleLog = "You hit " + foe.name + " for " + dmg + "!";
        } else if (key == 'd') {
            defending = true;
            battleLog = "You brace behind your shield.";
        } else if (key == 'p') {
            battleLog = hero.useItem("Potion") ? "Glug! Potion heals 12." : "No potions left!";
        } else if (key == 'f') {
            if (Math.random() < 0.6) { state = "EXPLORE"; safeSteps = 3;
                battleLog = ""; return; }
            battleLog = "Could not escape!";
        } else return;

        if (foe.isAlive()) {
            int dmg = foe.attack + (int)(Math.random()*3);
            if (defending) dmg /= 2;
            hero.takeDamage(dmg);
            battleLog += "  " + foe.name + " hits for " + dmg + "!";
            if (!hero.isAlive()) state = "GAME_OVER";
        }
    }