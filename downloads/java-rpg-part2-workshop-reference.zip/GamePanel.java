// ===== Part 1 of 3 (as shown in the lesson) =====
String state = "EXPLORE";
    Monster foe;
    int safeSteps = 0;

    // after a successful move in keyPressed:
    if (state.equals("EXPLORE") && map[heroRow][heroCol] == 0) {
        if (safeSteps > 0) safeSteps--;
        else if (Math.random() < 0.15) {
            double roll = Math.random();
            String type = roll < 0.5 ? "slime"
                        : roll < 0.85 ? "wolf" : "goblin";
            foe = Monster.create(type);
            state = "BATTLE";
        }
    }

// ===== Part 2 of 3 (as shown in the lesson) =====
boolean defending = false;

    void battleAction(char key) {
        defending = false;
        if (key == 'a') {
            int dmg = hero.getAttack() + (int)(Math.random()*4) - 1;
            foe.takeDamage(dmg);
            battleLog = "You hit " + foe.name + " for " + dmg + "!";
        } else if (key == 'd') {
            defending = true;
            battleLog = "You brace behind your shield.";
        } else if (key == 'p') {
            battleLog = hero.useItem("Potion") ? "Glug! Potion heals 12." : "No potions left!";
        } else if (key == 'f') {
            if (Math.random() < 0.6) { state = "EXPLORE"; safeSteps = 3;
                battleLog = ""; return; }
            battleLog = "Could not escape!";
        } else return;

        if (foe.isAlive()) {
            int dmg = foe.attack + (int)(Math.random()*3);
            if (defending) dmg /= 2;
            hero.takeDamage(dmg);
            battleLog += "  " + foe.name + " hits for " + dmg + "!";
            if (!hero.isAlive()) state = "GAME_OVER";
        }
    }

// ===== Part 3 of 3 (as shown in the lesson) =====
if (state.equals("GAME_OVER") && e.getKeyChar() == 'r') {
        heroRow = 1; heroCol = 1;
        hero.heal(hero.getMaxHp() / 2);      // half HP respawn
        state = "EXPLORE";
        safeSteps = 5;
    }