public void gainXp(int amount) {
        xp += amount;
        while (xp >= level * 25) {
            xp -= level * 25;
            level++;
            maxHp += 6;
            attack += 2;
            hp = maxHp;          // level-up full heal!
        }
    }
    public int getLevel() { return level; }
    public void addGold(int g) { gold += g; }