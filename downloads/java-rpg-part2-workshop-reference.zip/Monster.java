public class Monster {
    String name;
    int hp, maxHp, attack, xpReward, goldReward;

    public Monster(String name, int hp, int attack, int xp, int gold) {
        this.name = name; this.maxHp = hp; this.hp = hp;
        this.attack = attack; this.xpReward = xp; this.goldReward = gold;
    }

    public static Monster create(String type) {
        switch (type) {
            case "slime":  return new Monster("Slime", 12, 3, 8, 5);
            case "wolf":   return new Monster("Wolf", 20, 5, 15, 12);
            case "goblin": return new Monster("Goblin", 28, 7, 25, 20);
        }
        return create("slime");
    }

    public void takeDamage(int amount) { hp = Math.max(0, hp - amount); }
    public boolean isAlive() { return hp > 0; }
}