Pirate Cannon Forge
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/pirate-cannon-builder.html

Offline reference pack for this workshop.

Build a pirate cannon game in your browser with this free game dev workshop from JVDesignStudio.

This workshop is an interactive builder, so follow it online for the live preview.
This pack keeps a copy of the notes and guidance from the page.

--------------------------------------------------------------------
WORKSHOP NOTES
--------------------------------------------------------------------

## 💣 Pirate Cannon Forge
- ?🆓 Free In-House Dev Tools

## Make It Yours
- Use these free browser tools alongside this workshop to create custom sprites, sounds, levels and colour schemes for your game. No installs. Free forever.
