Flappy Bird Clone - My First Browser Game Ep 1
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/js-flappy-workshop.html

Files:
- flappy-starter.html : empty starter - add the 6 steps from the workshop
- flappy-complete.html : finished reference game - complete, playable, compare if stuck

How to use:
1. Open flappy-starter.html in Notepad, VS Code, or any text editor.
2. Follow the 6 steps in the workshop, typing each part into the <script> section.
3. Save, double-click to play in browser. Use F12 console if nothing shows.
4. Compare your file to flappy-complete.html if stuck.

Features in the complete version:
- HTML canvas (400x600), one-button flap (click/tap/Space)
- Gravity, pipe generation with random gaps, AABB collision
- Score per pipe, Game Over screen, best score saved in localStorage
- No install, no account, works on school computers.

Tip: Try changing gravity (0.45), flap power (-8), GAP (150), pipe speed (2.4) to feel how game tuning works!

No install, no account, works on school computers.
