Run & Jump! GML Platformer
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gml-platformer-workshop.html

Reference project files for this workshop.
These are the finished code files shown step by step in the lesson, so you can
compare your own version or copy a section you are stuck on.

Files:
- obj_player · Create.txt
- obj_player · Step.txt
- obj_player · Step (additions).txt
- obj_game · Step.txt
- obj_coin · Collision with obj_player.txt
- obj_flag · Collision with obj_player.txt

How to use:
1. Unzip this folder somewhere easy to find.
2. Follow the workshop steps and type the code yourself.
3. Stuck? Open the matching file here and compare it line by line.
4. Every code block on the workshop page also has a Copy button.
