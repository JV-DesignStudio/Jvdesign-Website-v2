My First 3D Model Ep 1: Simple Cube Scene
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/blender-cube-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First 3D Model Ep 1: Simple Cube Scene

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Download Blender free from blender.org, Windows, Mac and Linux all work.
- Open it, you get the default scene: a cube, a camera and a light.
- Navigation on the middle mouse button: drag = orbit, Shift+drag = pan, scroll = zoom.
- No middle mouse? Enable Edit → Preferences → Input → Emulate 3 Button Mouse (Alt+drag orbits).
- Practice mission: orbit a full circle around the cube, zoom close, pan away. Repeat until it feels like your hand does it alone.
- Click the cube to select it (orange outline). Now: G = grab/move, R = rotate, S = scale. Click to confirm, Esc to cancel.
- Axis locking: tap G then Z, movement locks to the vertical axis. Same with X and Y, and it works for R and S too.
- Type numbers for precision: S 2 Enter = exactly double size; R Z 45 Enter = rotate 45° around Z.
- Mission: move the cube 2 units up (G Z 2), rotate it 45° (R Z 45), scale it 1.5× (S 1.5).
- Shift+A opens the Add menu, add another Cube for the house body, scale it wide (S, then Shift+Z to scale everything EXCEPT Z).
- The roof: Shift+A → Cone, give it 4 sides in the bottom-left operator panel, instant pyramid roof! Move it on top (G Z).
- A door: another cube, scaled thin and small, moved into the front face.
- Duplicate with Shift+D, make two window cubes.
- Add a big flattened cube as the ground. Congratulations, that pile of primitives reads as a HOUSE.
- Press Numpad 0 (or the camera icon) to look THROUGH the camera. Probably a terrible angle, let us fix it.
- The magic workflow: fly your viewport to a great angle, then View → Align View → Align Active Camera to View (Ctrl+Alt+Numpad 0), the camera jumps to your view!
- Fine-tune from camera view: select the camera, G to slide, G then middle-click drag for dolly.
- Frame the house slightly off-centre, from a low angle, instantly more dramatic than straight-on.
- Select the default light. In the green lamp properties tab, change its type to Sun, parallel rays like real sunlight.
- Rotate the sun (R) to steer shadows: low angle = evening drama, high = flat noon.
- Set Strength ~3 for soft evening or ~6 for bright day.
- Switch the viewport to Rendered shading (the sphere icons, far right one, or press Z and pick Rendered) to see real lighting live.
- Bonus: add a second weak Area light on the shadow side as a "fill" so shadows are not pitch black, a real photography trick.
- Press F12, Blender renders what the camera sees. A window shows the result.
- Save it: Image → Save As → my-first-render.png. THAT file is shareable proof of your new skill!
- Two render engines (Render Properties tab): Eevee = real-time and fast; Cycles = ray-traced, photoreal, slower. Try both, see the shadow quality difference.
- Also save your .blend file (Ctrl+S), Episode 2 builds new models, but you will want this scene again in Episode 7.
- Quiz below completes Episode 1. See you in character modelling!
- Navigating the 3D viewport: orbit, pan and zoom with middle mouse and scroll wheel
- The three transform hotkeys: G (grab/move), R (rotate), S (scale) with axis locking
- Adding mesh primitives with Shift+A and building compositions with duplicate (Shift+D)
- Framing a camera with Ctrl+Alt+Numpad 0 and understanding composition angles
- Lighting with a Sun lamp and rendering with F12, choosing between Eevee and Cycles


--------------------------------------------------------------------
BONUS: BLENDER PYTHON BUILDER
--------------------------------------------------------------------
This pack also includes build_cube_scene.py, a script that builds a "Simple Cube Scene" setup for you.

How to run it:
1. Open Blender 4.x.
2. Go to the Scripting tab, click Open, and choose build_cube_scene.py.
3. Click Run Script (the play button). The model appears in your scene.
4. Press F12 to render, or keep building on top of it.
