# build_cube_scene.py - Blender 4.x
# My First 3D Model Ep 1: Simple Cube Scene
# Run: Blender > Scripting tab > Open > Run Script  (or: blender --python build_cube_scene.py)
import bpy

# 1. Start from a clean scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# 2. Add the main cube
bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 1))
cube = bpy.context.active_object
cube.name = "MainCube"

# 3. Add a ground plane
bpy.ops.mesh.primitive_plane_add(size=12, location=(0, 0, 0))
ground = bpy.context.active_object
ground.name = "Ground"

# 4. Add a camera and frame the cube
bpy.ops.object.camera_add(location=(6, -6, 4), rotation=(1.1, 0, 0.78))
bpy.context.scene.camera = bpy.context.active_object

# 5. Add a sun light
bpy.ops.object.light_add(type='SUN', location=(4, -4, 8))
bpy.context.active_object.data.energy = 3.0

print("Done! Press F12 to render or F5 to see it in the viewport.")
