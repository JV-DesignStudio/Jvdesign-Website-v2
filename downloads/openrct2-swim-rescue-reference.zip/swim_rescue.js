function updateRescues() {
    for (var i = activeRescues.length - 1; i >= 0; i--) {
        var r      = activeRescues[i];
        var guest  = map.getEntity(r.guestId);
        var marker = map.getEntity(r.markerId);

        if (!guest || !marker) {
            if (marker) marker.remove();
            activeRescues.splice(i, 1);
            continue;
        }

        // STATE 0: fly balloon toward guest
        if (r.state === 0) {
            r.markerX += (guest.x - r.markerX) * 0.1;
            r.markerY += (guest.y - r.markerY) * 0.1;
            marker.x = Math.round(r.markerX);
            marker.y = Math.round(r.markerY);

            if (Math.abs(r.markerX - guest.x) 20) {
                r.state = 1;  // arrived! switch to flying to safety
            }
        }

        // STATE 1: fly to safety, then drop guest
        else if (r.state === 1) {
            r.markerX += (r.safe.x - r.markerX) * 0.08;
            r.markerY += (r.safe.y - r.markerY) * 0.08;
            marker.x = Math.round(r.markerX);
            marker.y = Math.round(r.markerY);

            if (Math.abs(r.markerX - r.safe.x) 20) {
                guest.x = r.safe.x;
                guest.y = r.safe.y;
                guest.z = r.safe.z;
                marker.remove();
                activeRescues.splice(i, 1);
                savedCount++;
            }
        }
    }
}