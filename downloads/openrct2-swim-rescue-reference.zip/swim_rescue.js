// ===== Part 1 of 13 (as shown in the lesson) =====
// OpenRCT2 Plugin, Swim Rescue
// Drop this in: Documents/OpenRCT2/plugin/

var pluginInfo = {
    name:    "Swim Rescue",
    version: "1.0",
    authors: ["You!"],
};

function main() {
    // This runs when the park loads
    console.log("Swim Rescue plugin loaded!");
}

// Register the plugin with OpenRCT2:
registerPlugin({
    name:    pluginInfo.name,
    version: pluginInfo.version,
    main:    main,
});

// ===== Part 2 of 13 (as shown in the lesson) =====
// The API gives us a guest object like this:
var guest = map.getGuest(0);

// We can read properties:
var guestId   = guest.id;
var guestX    = guest.x;
var guestY    = guest.y;
var inWater   = guest.isInWater;  // true/false!

// And write properties to move them:
guest.x = 128;
guest.y = 180;

// That line teleports the guest instantly!

// ===== Part 3 of 13 (as shown in the lesson) =====
function checkGuest(guest) {
    // Only act if the guest is in water:
    if (guest.isInWater ===
  true
  false
) {
        // Guest is in water, log it for now
        console.log(
            "Guest " + guest.id +
            " is in water!"
        );
    }
}

// Test it:
checkGuest({ id: 1, isInWater: true, x: 50, y: 80 });
checkGuest({ id: 2, isInWater: false, x: 10, y: 10 });

// ===== Part 4 of 13 (as shown in the lesson) =====
function checkAllGuests() {
    // How many guests to check each tick:
    var total = map.numGuests;

    for (var i = 0; i < 50; i++) {
        var guest = map.getGuest(i);

        // Skip if guest doesn't exist:
        if (!guest) continue;

        if (guest.isInWater) {
            checkGuest(guest);
        }
    }
}

// ===== Part 5 of 13 (as shown in the lesson) =====
function rescueGuest(guest) {
    try {
        // Attempt to move the guest to safety
        guest.x = findNearestPath(guest).x;
        guest.y = findNearestPath(guest).y;
        guest.isInWater = false;

    } catch (error) {
        // If something went wrong, log it
        console.log("Rescue failed: " + error.message);

        // Fallback, teleport to park entrance
        guest.x = 32;
        guest.y = 32;
    }
}

// ===== Part 6 of 13 (as shown in the lesson) =====
function swimToNearestPath(guest) {
    // Find the nearest safe tile:
    var target = findNearestPath(guest);

    // Work out direction (dx, dy):
    var dx   = target.x - guest.x;
    var dy   = target.y - guest.y;
    var dist = Math.sqrt(dx*dx + dy*dy);

    // Move a little bit each tick (swim speed):
    var speed = 1.5;
    guest.x += (dx / dist) * speed;
    guest.y += (dy / dist) * speed;

    // Close enough? Mark as saved:
    if (dist < 6) {
        guest.isInWater = false;
        console.log("Guest " + guest.id + " reached safety!");
    }
}

// ===== Part 7 of 13 (as shown in the lesson) =====
function main() {
    console.log("Swim Rescue loaded!");

    // Subscribe to every game tick:
    context.subscribe(
        "interval.tick",   // event name
        function() {         // callback runs each tick
            checkAllGuests();
        }
    );

    // Also subscribe to guest spawning:
    context.subscribe(
        "guest.spawned",
        function(e) {
            console.log("New guest: " + e.guest.id);
        }
    );
}

// ===== Part 8 of 13 (as shown in the lesson) =====
var RESCUE_RADIUS = 60;

function findBestExit(guest) {
    var exits = getPoolExits(); // returns array of exit tiles
    var best  = null;
    var bestDist = Infinity;

    for (var i = 0; i < exits.length; i++) {
        var exit  = exits[i];
        var dist  = Math.hypot(
            exit.x - guest.x,
            exit.y - guest.y
        );
        if (dist < bestDist) {
            bestDist = dist;
            best     = exit;
        }
    }
    return best;
}

// ===== Part 9 of 13 (as shown in the lesson) =====
function openStatsWindow() {
    ui.openWindow({
        title:  "📊 Swim Rescue Stats",
        width:  200,
        height: 120,
        widgets: [
            {
                type:   "label",
                text:   "Guests Saved: " + savedCount,
                x: 10, y: 30,
                width: 180, height: 20,
            },
            {
                type:   "button",
                text:   "Toggle Rescue",
                x: 10, y: 80,
                width: 120, height: 20,
                onClick: function() {
                    rescueEnabled = !rescueEnabled;
                }
            }
        ]
    });
}

// ===== Part 10 of 13 (as shown in the lesson) =====
// ----------------------------------------
//  OpenRCT2, Swim Rescue Plugin v1.0
//  Made at JVDesignStudio
// ----------------------------------------

var savedCount   = 0;
var drownedCount = 0;
var SWIM_SPEED   = 1.5;
var rescueEnabled= true;

function checkAllGuests() {
    for (var i = 0; i < map.numGuests; i++) {
        var g = map.getGuest(i);
        if (!g) continue;
        if (g.isInWater && rescueEnabled) {
            try {
                swimToNearestPath(g);
                savedCount++;
            } catch(e) {
                drownedCount++;
            }
        }
    }
}

function main() {
    context.subscribe("interval.tick", checkAllGuests);
    openStatsWindow();
    console.log("Swim Rescue v1.0 loaded!");
}

registerPlugin({ name:"Swim Rescue", version:"1.0", main:main });

// ===== Part 11 of 13 (as shown in the lesson) =====
var activeRescues = [];  // track all in-progress rescues

function spawnMarker(x, y, z) {
    try {
        var marker = map.createEntity("balloon", {
            x: x,
            y: y,
            z: z + 200   // spawn above the guest
        });
        return marker;
    } catch(e) {
        console.log("Could not spawn marker: " + e);
        return null;
    }
}

function dispatchRescue(guest, safe) {
    var marker = spawnMarker(guest.x, guest.y, guest.z);

    if (!marker) {
        // No balloon, just teleport immediately
        guest.x = safe.x;
        guest.y = safe.y;
        guest.z = safe.z;
        return;
    }

    activeRescues.push({
        guestId:  guest.id,
        markerId: marker.id,
        safe:     safe,
        state:    0     // 0 = flying to guest, 1 = flying to safety
    });
}

// ===== Part 12 of 13 (as shown in the lesson) =====
function updateRescues() {
    for (var i = activeRescues.length - 1; i >= 0; i--) {
        var r      = activeRescues[i];
        var guest  = map.getEntity(r.guestId);
        var marker = map.getEntity(r.markerId);

        if (!guest || !marker) {
            if (marker) marker.remove();
            activeRescues.splice(i, 1);
            continue;
        }

        // STATE 0: fly balloon toward guest
        if (r.state === 0) {
            r.markerX += (guest.x - r.markerX) * 0.1;
            r.markerY += (guest.y - r.markerY) * 0.1;
            marker.x = Math.round(r.markerX);
            marker.y = Math.round(r.markerY);

            if (Math.abs(r.markerX - guest.x) 20) {
                r.state = 1;  // arrived! switch to flying to safety
            }
        }

        // STATE 1: fly to safety, then drop guest
        else if (r.state === 1) {
            r.markerX += (r.safe.x - r.markerX) * 0.08;
            r.markerY += (r.safe.y - r.markerY) * 0.08;
            marker.x = Math.round(r.markerX);
            marker.y = Math.round(r.markerY);

            if (Math.abs(r.markerX - r.safe.x) 20) {
                guest.x = r.safe.x;
                guest.y = r.safe.y;
                guest.z = r.safe.z;
                marker.remove();
                activeRescues.splice(i, 1);
                savedCount++;
            }
        }
    }
}

// ===== Part 13 of 13 (as shown in the lesson) =====
// ------------------------------------------
//  Swim Rescue v2.0, OpenRCT2 Plugin
//  Made at JVDesignStudio
// ------------------------------------------

var savedCount    = 0;
var beingRescued  = {};   // object used as a lookup table
var activeRescues = [];   // array of in-progress rescues
var rescueEnabled = true;

function main() {
    console.log("[SwimRescue] v2.0 loaded!");

    context.subscribe("interval.tick", function() {
        if (!rescueEnabled) return;
        if ((date.ticks & 7) !== 0) return; // run every 8 ticks

        var guests = map.getAllEntities("guest");
        for (var i = 0; i guests.length; i++) {
            var g = guests[i];
            if (beingRescued[g.id]) continue;
            if (activeRescues.length >= 5) break;
            if (isOnWater(g)) {
                var safe = findSafePath(g);
                if (safe) dispatchRescue(g, safe);
            }
        }
        updateRescues();
    });

    if (typeof ui !== "undefined") openStatsWindow();
}

registerPlugin({
    name: "Swim_Rescue", version: "2.0",
    authors: ["JVDesignStudio"],
    type: "local", targetApiVersion: 34,
    main: main
});