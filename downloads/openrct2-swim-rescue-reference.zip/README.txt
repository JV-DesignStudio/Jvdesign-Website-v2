Save Your Guests From Drowning
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/openrct2-swim-rescue.html

Reference project files for this workshop.
These are the finished code files shown step by step in the lesson, so you can
compare your own version or copy a section you are stuck on.

Files:
- swim_rescue.js

How to use:
1. Unzip this folder somewhere easy to find.
2. Follow the workshop steps and type the code yourself.
3. Stuck? Open the matching file here and compare it line by line.
4. Every code block on the workshop page also has a Copy button.
