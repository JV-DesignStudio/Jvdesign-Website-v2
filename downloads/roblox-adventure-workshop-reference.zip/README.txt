Island Quest! Build an RPG Adventure Game in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-adventure-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Island Quest! Build an RPG Adventure Game in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Build an Island Quest RPG Adventure!

## Set Up the World
- Open Roblox Studio → New → Baseplate
- In the Explorer, click Workspace → Baseplate and press Delete to remove it
- Open the Terrain Editor (Home tab → Terrain Editor button)
- Click Generate and set: Biome = Tropics, Size X = 512, Size Z = 512, then click Generate
- Use the Paint brush to add sandy beach around the coast (Sand material, large brush)

## Add Island Landmarks
- Insert a SpawnLocation Part on the beach rename it SpawnLocation, set Material = SmoothPlastic, colour white
- Build a small Village Area: 3-4 stone walls and a floor using Parts (Material = SmoothPlastic, medium grey). Group it as Village
- Build an Ancient Ruins area inland: crumbled walls, stone pillars, overgrown floor. Group as Ruins
- Build a Volcano platform at the far end of the island a dark grey wedge hill with a red glowing top (Neon material, BrickRed colour)

## Create PlayerSetup Script
- In ServerScriptService, insert a new Script, rename it PlayerSetup
- Paste this code:

## Build the NPC Model
- In the Toolbox, search "NPC" and insert any free humanoid NPC into the village area
- Rename the NPC Model to VillageElder
- In the NPC's HumanoidRootPart, insert a ProximityPrompt
- Set the ProximityPrompt's ActionText = Talk, ObjectText = Village Elder, KeyboardKeyCode = E
- In the NPC Model, insert a Script, rename it ElderScript

## NPC Dialogue Script

## Build the Dialogue Frame
- In StarterGui, insert a ScreenGui, rename it DialogueGui
- Inside it, insert a Frame set: Size = {0.6, 0}{0.18, 0}, Position = {0.2, 0}{0.78, 0}, BackgroundColor = dark navy (21, 31, 48), BackgroundTransparency = 0.1
- Inside the Frame, add a TextLabel: Size = {1,0}{0.6,0}, Position = {0,0}{0.1,0}, TextColor = white, Font = GothamBold, TextWrapped = true rename DialogueText
- Add another TextLabel for the NPC name: Size = {0.5,0}{0.3,0}, Position = {0.02,0}{0,0}, TextColor = #38bdf8 (sky blue), rename NPCName, Text = "Village Elder"
- Set the Frame's Visible = false to start hidden
- In StarterPlayerScripts, insert a LocalScript, rename DialogueClient

## Build a Crystal Part
- Insert a Part into the Ruins area set Size = (1.5, 2, 1.5), Material = Neon, Colour = Cyan
- Add a SpecialMesh inside it set MeshType = Diamond
- Add a PointLight Brightness = 3, Colour = Cyan, Range = 10
- Rename the Part Crystal
- Insert a Script inside the Crystal Part
- Right-click the Crystal in Explorer ? Duplicate it 4 times (5 crystals total)
- Scatter them around the Ruins behind pillars, on ledges, hidden in corners

## Build the Quest UI
- In StarterGui, insert a new ScreenGui, rename QuestGui
- Add a Frame Position = {0.01,0}{0.01,0}, Size = {0.28,0}{0.12,0}, BackgroundColor = navy, BackgroundTransparency = 0.2, corner radius 12
- Inside the Frame, add a TextLabel: Size = {1,0}{0.6,0}, Position = {0,0}{0.1,0}, TextColor = white, Font = GothamBold, TextWrapped = true rename DialogueText
- Add another TextLabel for quest detail rename QuestDetail, Size = {1,0}{0.5,0}, Position = {0,0}{0.45,0}, TextColor = white, Text = "Talk to the Village Elder"
- In StarterPlayerScripts, insert a LocalScript, rename QuestTracker

## Update ElderScript for Quest Turn-In

## Add a Merchant NPC
- Insert another NPC from the Toolbox near the village rename it Merchant
- Add a ProximityPrompt: ActionText = Buy Sword (50G), ObjectText = Merchant
- Get a free sword from the Toolbox (search "sword") drag it into ServerStorage, rename IslandSword
- Insert a Script in the Merchant model:

## Build the Boss Model
- On the volcano platform, insert a Part Size = (8, 12, 8), Material = Neon, Colour = Really Red, Anchored = false, rename BossBody
- Add a Humanoid inside BossBody set MaxHealth = 200, Health = 200
- Add a BillboardGui inside BossBody: Size = {4,0}{0.8,0}, StudsOffset = (0, 8, 0), AlwaysOnTop = true
- Inside the BillboardGui, add a Frame (full size, dark bg), then a smaller red Frame named HealthFill
- Add a TextLabel above: Text = "🐉 Volcano Beast", TextColor = red
- Group BossBody into a Model named VolcanoBoss, insert a Script:

## Boss Death Detection

## Victory Screen GUI
- In StarterGui, insert a ScreenGui, rename WinGui
- Add a full-screen Frame: Size = {1,0}{1,0}, dark navy background, Transparency = 0.15, Visible = false
- Add a centre TextLabel: Text = "🏆 VICTORY! 🏆", Font = FredokaOne, large text, sky blue
- Add a sub-label: Text = "You defeated the Volcano Beast and saved the island!"
- In StarterPlayerScripts, add a LocalScript named WinClient:

## Build a Treasure Chest
- Insert a Part Size = (3, 2, 2), Material = Wood, Colour = medium brown. Rename TreasureChest
- Add a SpecialMesh MeshType = Brick (gives a nice box shape)
- Add a ClickDetector inside the Part
- Add a PointLight Colour = Gold, Brightness = 2, Range = 8
- Insert a Script inside TreasureChest:
- Duplicate the chest 5 times and hide them around the island in caves, behind trees, at the foot of the ruins

## Update PlayerSetup for Saving

## Lighting Setup
- Click Lighting in Explorer ? set: Brightness = 2.5, Ambient = (170, 195, 255) (cool blue sky), OutdoorAmbient = (160, 200, 255)
- Insert Sky in Lighting set SkyboxBk/Dn/Ft/Lt/Rt/Up = any sky asset IDs from the Toolbox (search "tropical sky")
- Insert ColorCorrection in Lighting Saturation = 0.1 (makes colours pop), Contrast = 0.05
- Insert Atmosphere in Lighting Density = 0.2, Haze = 0.5, Glare = 0.2 (gives a warm island haze)

## Volcano Fire Effects
- On the volcano top, insert a Part (flat, red Neon) add a Fire effect inside: Color = orange, Size = 10, Heat = 9
- Add several PointLights around the rim orange colour, Brightness 3, Range 20

## Ambient Sounds
- In Workspace, insert a Sound search Toolbox for a free "tropical ambient" or "ocean waves" sound, paste the SoundId. Set Looped = true, Volume = 0.4
- In ServerScriptService, insert a Script:

## Palm Tree Decorations
- Search the Toolbox for "palm tree" insert 5-8 palm trees along the beach and jungle edge
- Search for "tropical flowers" or "fern" scatter around the ruins for overgrown atmosphere

## Full Playthrough Checklist
- Click Play in the toolbar to enter the game
- Walk up to the Village Elder and press E dialogue appears, quest assigned
- Quest Tracker updates to show "💎 Crystals: 0 / 5"
- Head to the Ruins and collect all 5 crystals tracker updates each time
- Return to the Elder get 100 Gold reward, quest changes to "Slay Boss"
- Go to the Merchant and buy the sword for 50 Gold
- Head to the Volcano the Volcano Beast chases you
- Attack the boss with the sword health bar decreases
- Boss defeated Victory screen appears, Gold and XP awarded
- Open some Treasure Chests along the way loot drops work

## Publish Your Game
- Click File ? Publish to Roblox As· (or press Ctrl+Shift+P)
- Give your game a name, something like "Island Quest RPG 🏝️"
- Write a short description: "Explore a tropical island, complete quests and defeat the Volcano Beast!"
- Set Genre to Adventure
- Click Create
- After publishing, go to Game Settings ? Permissions and set to Public
- Click the Roblox button in the toolbar to open your game page copy the link and share it!
