pico-8 cartridge // http://www.pico-8.com
version 41
__lua__
-- platformer.p8  JVDesignStudio
function _init()
  px=16 py=16
  pvx=0 pvy=0
  grounded=false
  for x=0,15 do mset(x,15,1) end
  for y=0,15 do mset(0,y,1) mset(15,y,1) end
  for x=3,6 do mset(x,11,1) end
  for x=9,12 do mset(x,8,1) end
  for x=6,8 do mset(x,5,1) end
end

function is_solid(x,y)
  local tx=flr(x/8)
  local ty=flr(y/8)
  return mget(tx,ty)==1
end

function _update()
  pvx=0
  if btn(0) then pvx=-1.5 end
  if btn(1) then pvx=1.5 end
  if btnp(4) and grounded then
    pvy=-3
    sfx(0)
  end
  pvy=pvy+0.5
  px=px+pvx
  if is_solid(px+3,py) then px=px-2 end
  if is_solid(px-3,py) then px=px+2 end
  py=py+pvy
  if is_solid(px,py+7) then
    py=flr((py+7)/8)*8-7
    pvy=0
    grounded=true
  else
    grounded=false
  end
  if is_solid(px,py-7) and pvy<0 then
    pvy=0
    py=flr((py-7)/8)*8+8+7
  end
end

function _draw()
  cls(0)
  map(0,0,0,0,16,16)
  rectfill(px-3,py-7,px+3,py+7,11)
  print("arrows + z",2,2,6)
end
