Space Shooter , Build a Shooter in GDevelop
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gdevelop-shooter-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Space Shooter , Build a Shooter in GDevelop

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Create a new scene "Game". Add a Sprite object "Player" shaped like a spaceship.
- Events: On key pressed, change X/Y position to move the ship.
- Add a dark background (set background color to black or dark blue).
- Add a Sprite object "Bullet". Paint a small yellow/white projectile.
- Add event: Condition "Key pressed: Space". Actions: "Create object Bullet at position of Player", then "Add force to Bullet: X=0, Y=-400".
- Add event: Condition "Bullet Y position < -20". Action: "Delete Bullet" (remove off-screen bullets).
- Add Sprite object "Enemy". Paint a red alien shape.
- Add event: Condition "Repeat every 1.5 seconds". Action: "Create Enemy at position (Random(0 to 800), -30)".
- Add event: Condition "Always". Action: "Change Enemy Y position: Add 100" (makes them drift down).
- Add event: Condition "Enemy Y position > 620". Action: "Delete Enemy".
- Create variable "Score" = 0.
- Add event: Condition "Bullet is in collision with Enemy". Actions: "Delete Bullet", "Delete Enemy", "Change Score: Add 1".
- Create variables: "Wave" = 1, "EnemySpeed" = 100, "SpawnRate" = 1.5.
- Event: Condition "Score = Wave ✨ 5". Actions: "Change Wave: Add 1", "Change EnemySpeed: Add 20", "Change SpawnRate: Subtract 0.1" (min 0.3).
- Use EnemySpeed in the "Always" event that moves enemies downward.
- Use SpawnRate in the "Repeat every" timer event.
- Add Sprite object "PowerUp". Paint a blue/green gem.
- Event: Condition "Repeat every 10 seconds". Action: "Create PowerUp at random position at top".
- Event: Condition "Player collides with PowerUp". Actions: "Delete PowerUp", "Change variable ShootSpeed: Set to 0.1" (faster shooting).
- Add a timer event that resets ShootSpeed after 5 seconds.
- Create variable "Lives" = 3. Add a Text object "LivesText" to display it.
- Event: Condition "Enemy Y position > 620" (before deleting). Action: "Change Lives: Subtract 1".
- Event: Condition "Lives < 1". Action: "Change scene to GameOver".
- Click Play. Test movement, shooting and collision.
- Watch the waves get harder. Try to reach wave 3!
