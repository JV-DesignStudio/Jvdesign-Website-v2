// Complete C++ Platformer for SFML 3. Build:
//   g++ platformer.cpp -o platformer -lsfml-graphics -lsfml-window -lsfml-system
#include <SFML/Graphics.hpp>
#include <optional>
#include <vector>

class Player {
public:
    sf::RectangleShape shape;
    float vx = 0, vy = 0;
    float sinceGround = 999;
    bool onGround = false;

    Player() {
        shape.setSize(sf::Vector2f(34, 44));
        shape.setPosition({100, 380});
        shape.setFillColor(sf::Color(255, 119, 0));
    }

    void update(float dt) {
        float target = 0;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left))  target = -260;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right)) target =  260;
        vx += (target - vx) * 12.f * dt;   // smooth toward target

        vy += 1400.f * dt;                 // gravity
        sinceGround += dt;
        if (onGround) sinceGround = 0;

        shape.move({vx * dt, vy * dt});

        auto pos = shape.getPosition();
        if (pos.x < 0) shape.setPosition({0.f, pos.y});
        if (pos.x + shape.getSize().x > 800) shape.setPosition({800.f - shape.getSize().x, pos.y});
    }

    void jump() {
        if (sinceGround < 0.1f) {          // coyote time
            vy = -560;
            sinceGround = 999;              // spend the jump
        }
    }
};

int main() {
    sf::RenderWindow window(sf::VideoMode({800, 480}), "C++ Platformer");
    window.setFramerateLimit(60);

    Player player;
    bool won = false;
    int score = 0;

    std::vector<sf::FloatRect> platforms = {
        {{0.f, 440.f},  {800.f, 40.f}},
        {{150.f, 340.f},{140.f, 16.f}},
        {{380.f, 260.f},{140.f, 16.f}},
        {{610.f, 180.f},{140.f, 16.f}}
    };
    std::vector<sf::FloatRect> coins = {
        {{205.f, 300.f},{18.f, 18.f}},
        {{435.f, 220.f},{18.f, 18.f}},
        {{665.f, 140.f},{18.f, 18.f}}
    };

    sf::Clock clock;
    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) window.close();
            if (const auto* kp = event->getIf<sf::Event::KeyPressed>())
                if (kp->code == sf::Keyboard::Key::Space && !won) player.jump();
        }

        float dt = clock.restart().asSeconds();

        if (!won) {
            player.update(dt);
            player.onGround = false;

            sf::FloatRect pb = player.shape.getGlobalBounds();
            for (auto& plat : platforms) {
                if (pb.findIntersection(plat) && player.vy > 0
                        && pb.position.y + pb.size.y - player.vy * dt <= plat.position.y + 1) {
                    player.shape.setPosition({pb.position.x, plat.position.y - pb.size.y});
                    player.vy = 0;
                    player.onGround = true;
                    pb = player.shape.getGlobalBounds();
                }
            }
            for (size_t i = 0; i < coins.size(); ) {
                if (pb.findIntersection(coins[i])) { coins.erase(coins.begin()+i); score += 10; }
                else ++i;
            }
            if (coins.empty()) won = true;
        }

        window.clear(sf::Color(25, 30, 60));
        for (auto& plat : platforms) {
            sf::RectangleShape r(plat.size); r.setPosition(plat.position);
            r.setFillColor(sf::Color(6, 214, 160)); window.draw(r);
        }
        for (auto& c : coins) {
            sf::RectangleShape r(c.size); r.setPosition(c.position);
            r.setFillColor(sf::Color(255, 209, 102)); window.draw(r);
        }
        window.draw(player.shape);
        window.display();
    }
}