// Complete C++ Pong for SFML 3. Build with:
//   g++ pong.cpp -o pong -lsfml-graphics -lsfml-window -lsfml-system
#include <SFML/Graphics.hpp>
#include <optional>
#include <cstdlib>
#include <string>

int main() {
    sf::RenderWindow window(sf::VideoMode({800, 500}), "C++ Pong");
    window.setFramerateLimit(60);

    sf::RectangleShape p1({14.f, 90.f});
    sf::RectangleShape p2({14.f, 90.f});
    sf::RectangleShape ball({14.f, 14.f});
    p1.setPosition({20.f, 205.f});
    p2.setPosition({766.f, 205.f});

    float bx = 393, by = 243, bvx = 300, bvy = 180;
    int p1Score = 0, p2Score = 0;

    // Score text needs a font. Point this at any .ttf on your system.
    sf::Font font;
    bool haveFont = font.openFromFile("C:/Windows/Fonts/arial.ttf");

    auto serve = [&](int dir) {
        bx = 393; by = 243;
        bvx = 300.f * dir;
        bvy = (std::rand() % 2 == 0) ? 180.f : -180.f;
    };
    serve((std::rand() % 2 == 0) ? 1 : -1);

    sf::Clock clock;
    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent())
            if (event->is<sf::Event::Closed>())
                window.close();

        float dt = clock.restart().asSeconds();

        // paddles: W/S and Up/Down, speed in pixels per second
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::W))    p1.move({0.f, -360.f * dt});
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S))    p1.move({0.f,  360.f * dt});
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up))   p2.move({0.f, -360.f * dt});
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Down)) p2.move({0.f,  360.f * dt});
        auto clampY = [](sf::RectangleShape& p) {
            float y = p.getPosition().y;
            if (y < 0) p.setPosition({p.getPosition().x, 0.f});
            if (y > 410) p.setPosition({p.getPosition().x, 410.f});
        };
        clampY(p1); clampY(p2);

        // ball: velocity is pixels per second, scaled by dt so speed stays the same at any frame rate
        bx += bvx * dt; by += bvy * dt;
        if (by <= 0 || by + 14 >= 500) bvy = -bvy;
        ball.setPosition({bx, by});

        sf::FloatRect br = ball.getGlobalBounds();
        if (br.findIntersection(p1.getGlobalBounds()) && bvx < 0) {
            bvx = -bvx + 60.f;
            bvy = (((by + 7) - (p1.getPosition().y + 45)) / 7.f) * 60.f;
        }
        if (br.findIntersection(p2.getGlobalBounds()) && bvx > 0) {
            bvx = -(bvx + 60.f);
            bvy = (((by + 7) - (p2.getPosition().y + 45)) / 7.f) * 60.f;
        }
        if (bvx > 720.f) bvx = 720.f; if (bvx < -720.f) bvx = -720.f;

        if (bx < 0)   { p2Score++; serve(-1); }
        if (bx > 800) { p1Score++; serve(1); }

        window.clear(sf::Color(12, 14, 24));
        window.draw(p1); window.draw(p2); window.draw(ball);
        if (haveFont) {
            sf::Text s(font, std::to_string(p1Score) + "   " + std::to_string(p2Score), 40);
            s.setPosition({360.f, 20.f});
            window.draw(s);
        }
        window.display();
    }
}