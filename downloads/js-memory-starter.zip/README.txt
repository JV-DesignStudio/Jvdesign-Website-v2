Memory Match - My First Browser Game Ep 2
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/js-memory-workshop.html

Files:
- memory-starter.html : Step 1 board builder (16 cards, no logic) - start here
- memory.html : reference - same starter, follow steps 2-5 in workshop to complete

How to use:
1. Open memory-starter.html in browser - you see 16 face-down cards.
2. Follow workshop steps to add shuffle, flip, match and scoring.
3. Compare to memory.html if stuck.

No install, works on school computers.
