Dot Smash - Build a Game in 15 Minutes
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/build-a-game-15-min.html

Files:
- dotsmash-starter.html : empty starter (add the 4 steps from the workshop)
- dotsmash.html : finished reference game (complete, playable)

How to use:
1. Open dotsmash-starter.html in Notepad, follow the 4 steps in the workshop.
2. Save, double-click to play in browser.
3. Compare your file to dotsmash.html if stuck.

No install, no account, works on school computers (save as All Files).
