Point & Click , Build an Adventure in GDevelop
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gdevelop-pointclick-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Point & Click , Build an Adventure in GDevelop

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Create a scene "Room1". Add a background image or colour.
- Add Sprite objects for interactive items: "Key", "Door", "Chest".
- Add event: Condition "Mouse button pressed" AND "Cursor is on Key". Action: "Delete Key", "Change variable HasKey: Set to 1".
- Create scene variable "HasKey" = 0, "HasCoin" = 0.
- Add Sprite objects "InvKey" and "InvCoin" at the bottom of the scene. Set them invisible initially.
- Event: Condition "Variable HasKey = 1". Action: "Show InvKey".
- Event: Condition "Variable HasCoin = 1". Action: "Show InvCoin".
- Add a Text object "DialogueText" at the bottom of the screen. Set it invisible initially.
- Add event: Condition "Mouse pressed on Chest". Actions: "Set DialogueText to "The chest is locked. You need a key."", "Show DialogueText".
- Add event: Condition "Mouse pressed on Door" AND "HasKey = 1". Action: "Change scene to Room2".
- Add event: Condition "Mouse pressed on Door" AND "HasKey = 0". Action: Set dialogue to "The door is locked."
- Create scene "Room2" with different objects.
- In Room1: Event "Mouse on Door AND HasKey=1" → Change to Room2.
- In Room2: Add a "Back" arrow. Event "Mouse on Back" → Change to Room1.
- Important: create global variables (not scene variables) for inventory so items persist between rooms!
- Create variable "Selected" = "none".
- Event: Mouse on InvKey → Set Selected = "key".
- Event: Mouse on Chest AND Selected = "key" → Delete Chest, show "You opened the chest!", Set HasCoin = 1.
- Add multiple animations to the Chest object: "closed" and "open".
- Event: Condition "Variable HasCoin = 1". Action: "Set animation of Chest to "open"".
- You can also change object opacity to "grey out" items that are already used.
- Create scene "Win" with congratulations text.
- In Room2: Event "Mouse on Treasure AND HasCoin = 1" → Change scene to Win.
- Add audio files to your project (click sounds, pickup sounds).
- In each "Mouse pressed" event, add action "Play sound".
- Add a brief "flash" effect when picking up items using opacity changes.
- Play: Room1 → pick up key → open chest → get coin → unlock door → Room2 → use coin on treasure → Win!
