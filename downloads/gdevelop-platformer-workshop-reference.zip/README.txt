Platformer , Build a Platformer in GDevelop
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gdevelop-platformer-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Platformer , Build a Platformer in GDevelop

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Create a new scene called "Level1".
- Add a Sprite object called "Player". Paint a simple character (about 30x40 pixels).
- Click "Edit object behaviors" and add "Platformer character".
- Place the Player near the bottom-left of the scene.
- Add a Sprite object called "Platform". Paint a brown/green rectangle (at least 100 pixels wide, 20 pixels tall).
- Add the "Platform" behavior to it (different from Platformer Character!).
- Place several instances to create a level: ground at the bottom, floating platforms at various heights.
- Add a "FinishFlag" sprite at the top-right of the level.
- Open the Events Sheet. Add event: Condition "Key pressed: Right". Action: "Simulate a press of the Right key" on Player (Platformer Character).
- Repeat for Left key.
- Add event: Condition "Key pressed: Space". Action: "Simulate a jump" on Player.
- Add a Sprite object "Coin". Paint a yellow circle (about 16x16).
- Place several coins around the level on top of platforms.
- Create scene variable "Score" = 0.
- Add event: Condition "Player is in collision with Coin". Actions: "Delete the Coin", "Change Score: Add 1".
- Add a Sprite object "Enemy". Paint a red enemy (about 24x24).
- Add the "Platformer character" behavior to it too.
- Add a scene variable "EnemyDirection" = 1.
- Event: Condition "Repeat every 0.5 seconds". Action: "Simulate Right key" on Enemy (if direction is 1) or Left (if -1).
- Event: Condition "Enemy is in collision with Platform" AND "Enemy is falling". Action: "Change EnemyDirection: Multiply by -1" (reverses direction).
- Add event: Condition "Player is in collision with Enemy" AND "Player is falling". Action: "Delete Enemy". This lets you stomp on enemies from above!
- Add event: Condition "Player is in collision with Enemy" AND "Player is NOT falling". Action: "Change scene to Level1" (restart).
- Create a "Win" scene with a "You Win!" text and "Press R to play again".
- Add event: Condition "Player is in collision with FinishFlag". Action: "Change scene to Win".
- In the Win scene events: Condition "Key pressed: R". Action: "Change scene to Level1".
- Make your level wider by adding more platforms to the right.
- Add event: Condition "At the beginning of the scene". Action: "Camera: Follow Player".
- Add event: Condition "At the beginning of the scene". Action: "Camera: Set zoom to 1".
- Click Play and test everything.
- Try jumping on an enemy from above. Try getting hit from the side.
- Collect all coins and reach the finish flag.
