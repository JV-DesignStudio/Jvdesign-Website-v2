Find the Exit! Build a Maze Game in Scratch
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/scratch-maze-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Find the Exit! Build a Maze Game in Scratch

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Go to scratch.mit.edu, start a new project and name it "Maze Game". Delete the cat.
- Click the Stage. Click Paint to draw a custom backdrop.
- Fill the entire backdrop with black using the fill bucket tool.
- Select a bright blue colour. Use the Rectangle tool to draw thick walls forming a maze. Leave corridors wide enough to walk through!
- Leave a start gap in the top-left and an exit gap in the bottom-right we'll add the door there.
- Name this backdrop Level1.
- Click Choose a Sprite. Pick a small character Pico, Nano or any compact sprite.
- Set Size to 30, smaller than usual so it fits the maze corridors.
- Drag the sprite to the start gap of your maze (top-left area).
- In the Code tab, add: "when 🎮 clicked ? go to x: (-180) y: (140)" adjust to your start gap position.
- In the player's code, add a "when 🎮 clicked ? forever" loop.
- Inside: "if key [right arrow] pressed? then change x by 3". Immediately after: "if touching color [blue]? then change x by -3".
- Repeat for left: "if key [left arrow] ? change x by -3 ? if touching blue ? change x by 3".
- Repeat for up: "if key [up arrow] ? change y by 3 ? if touching blue ? change y by -3".
- Repeat for down: "if key [down arrow] ? change y by -3 ? if touching blue ? change y by 3".
- Make a variable called HasKey. Uncheck it so it doesn't show on screen.
- Click Choose a Sprite and search for "Key". Add it, size to 40.
- Drag the key to somewhere inside the maze, not too easy to reach!
- In the Key's code: "when 🎮 clicked ? set HasKey to 0 ? show ? forever ? if touching [Player]? then set HasKey to 1 ? hide".
- Paint a new sprite draw a rectangle in yellow/gold. Name it Door. Size to fit the exit gap of your maze.
- Drag it to the exit gap of your maze to block it.
- In Door's code: "when 🎮 clicked ? show ? forever ? if touching [Player]? and HasKey = 1 then broadcast [NextLevel] ? stop this script".
- Add: "if touching [Player]? and HasKey = 0 then say [Find the key first!] for 1 second".
- Make a variable called Timer (keep it visible on stage).
- Click the Stage. Click Paint to draw a custom backdrop.
- After the repeat: "say [Time's Up! Try again!] for 2 seconds ? broadcast [Restart]".
- In the Player sprite, add: "when I receive [Restart] ? go to x: (-180) y: (140)", back to start position.
- The timer loop from Step 2 will automatically restart when the green flag is clicked again. Just make sure the Player sprite goes back to start when Restart is received.
- Click the Stage ? Backdrops tab. Right-click Level1 and choose Duplicate.
- Rename the copy Level2. Modify the maze make corridors more complex, add dead ends, change the key and exit positions.
- In the Stage's "when I receive [NextLevel]" script, add: "switch backdrop to [Level2] ? set Timer to 45 ? set HasKey to 0".
- Also move the player back to the new start position: broadcast [LevelStart] and handle it in the player.
- Move the Key and Door sprites to new positions matching Level 2's layout.
- Duplicate Level2 and rename it Level3. Redesign the maze to be the trickiest yet many dead ends, key hidden deep inside.
- In the Stage's NextLevel script, add a check: "if backdrop name = Level2 then switch to Level3 ? set Timer to 30".
- After Level 3 is completed, show a You Win! message: "if backdrop name = Level3 then say [You escaped all 3 mazes! 🎉] for 3 seconds → stop all".
- Select the Key sprite → Sounds tab → Choose a Sound. Add "Collect" or "Ding".
- In the Key's code, add "play sound [Ding]" just before the hide block.
- Select the Stage → Sounds → add a looping background track like "Mysterious Ticking Noise" or "Cave".
- In the Stage's "when 🏳 clicked" script, add "play sound [Cave] until done" inside a loop, or "start sound [Cave]" to play continuously.
- In the Stage's Backdrops tab, add a new backdrop and draw a title screen, write the game name and "Click to Play".
- Name it TitleScreen. Move it to be the first backdrop in the list.
- In the Stage's code: "when 🎮 clicked ? switch backdrop to [TitleScreen] ? wait until mouse down? ? switch backdrop to [Level1]".
- Then start the timer and send the player to the start position via a broadcast.
- Press Green Flag and play from title screen through all 3 levels.
- Check: key collection works on each level, door blocks without key, timer resets between levels.
- If walls feel too tight, edit the backdrops to widen corridors.
- Click File ? Save now then Share. Challenge family to escape all 3 mazes!
