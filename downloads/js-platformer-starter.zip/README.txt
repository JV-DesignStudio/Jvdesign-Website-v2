Platformer - My First Browser Game Ep 5
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/js-platformer-builder.html

Files:
- platformer-starter.html : Step 1 starter (canvas, player, gravity) - start here
- platformer.html : reference - same starter, follow steps 2-10 to add coins, enemies, health

How to use:
1. Open platformer-starter.html in browser - player falls, use arrows and space to move/jump.
2. Follow workshop steps to tweak gravity, jumpForce, health.
3. Compare to platformer.html if stuck.

No install, works on school computers.
