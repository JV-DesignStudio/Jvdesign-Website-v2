GameMaker Go! Pong in GML
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gml-pong-workshop.html

Reference project files for this workshop.
These are the finished code files shown step by step in the lesson, so you can
compare your own version or copy a section you are stuck on.

Files:
- obj_ball
- obj_ball · Collision with obj_paddle
- obj_game
- obj_paddle · Step Event
- obj_paddle_ai · Step

How to use:
1. Unzip this folder somewhere easy to find.
2. Follow the workshop steps and type the code yourself.
3. Stuck? Open the matching file here and compare it line by line.
4. Every code block on the workshop page also has a Copy button.
