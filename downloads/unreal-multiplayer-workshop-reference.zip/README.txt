My First Unreal Game Ep 9: Multiplayer Basics
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/unreal-multiplayer-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First Unreal Game Ep 9: Multiplayer Basics

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Unreal networking was built in from day one (1998!). Testing is absurdly easy.
- Beside Play: dropdown → Number of Players: 2, Net Mode: Play As Listen Server. Press Play.
- TWO windows appear: the server-player and a client, connected and running. Two mannequins, visible to each other. Zero setup.
- Movement already syncs, the Character class replicates movement out of the box (with prediction Fortnite-grade).
- Vocabulary check (from Unity Ep 8 if you did it): listen server = host; authority = the server owns truth. Same physics, different engine.
- By default, an actor spawned on the server exists ONLY on the server. Tick Replicates (class defaults) → the server creates/destroys it on all clients too.
- Variables: a plain variable changed on the server stays server-only. Set its Replication to Replicated → value flows server → clients automatically.
- Direction matters: replication is one-way, server → client. Clients NEVER push variables up (that is what RPCs are for, step 4).
- Test: a replicated BP_Ball with a replicated colour variable, changed server-side on a timer, both windows change together.
- Syncing a value is half the job, clients usually need to REACT (update a health bar, flash a colour).
- Set a variable’s replication to RepNotify: Unreal auto-creates an OnRep_VariableName function, called on clients whenever the value lands.
- Health example: Health (RepNotify) → OnRep_Health updates the health bar widget + plays a hit flash. Server changes Health once; every client’s UI reacts by itself.
- This is Unity’s OnValueChanged callback, Unreal-flavoured. Same architecture: state syncs, reactions are local.
- Custom events gain a Replicates dropdown: Run on Server (client asks server) and Multicast (server tells everyone).
- The pattern (Unity Ep 8 déjà vu): client presses F → RunOnServer event → server VALIDATES → Multicast event → effect on all screens.
- Validation is not optional: the server re-checks range/cooldown/permission. "Never trust the client", every online cheat ever is a client that was trusted.
- Build it: a door only the server opens (F → Server_RequestOpen → distance check → Multicast_OpenDoor animating on every screen).
- Where does a SCORE live in multiplayer? Not the pawn (dies/respawns), not the controller (server-only for others). Answer: PlayerState, per-player, replicated to everyone, survives respawns. Built for exactly this.
- Create BP_MyPlayerState (add Score, RepNotify), set it in the Game Mode.
- The server grants points: get the scoring player’s PlayerState → add Score.
- A scoreboard widget (Tab) lists every PlayerState via Get Game State → PlayerArray, names and scores of ALL players, replicated for free.
- Framework tour: GameMode (rules, server-only) / GameState (match data, shared) / PlayerState (per-player, shared) / Pawn (the body). Learn the homes, networking gets easy.
- Assemble: your Ep 1 arena + replicated coins (server destroys on overlap + adds to the toucher’s PlayerState score) + RepNotify scoreboard + a Multicast win banner at 10.
- Test at Players: 2. Then the real thing: package the game (Platforms → Windows) and try LAN play with a friend.
- Nine episodes of Unreal: editor, Blueprints, events, interfaces, dispatchers, components, saves, streaming, profiling, and networked play. That is a serious skill stack.
- Blueprint has taken you this far; C++ is the natural next mountain (the Top-Down Shooter episode touches it). Either way: you build in the engine that builds blockbusters. GG, developer.
