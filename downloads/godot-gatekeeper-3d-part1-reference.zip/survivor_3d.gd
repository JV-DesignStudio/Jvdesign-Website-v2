# survivor_3d.gd: Attach to your Survivor3D CharacterBody3D root
extends CharacterBody3D

var hidden_stats: Dictionary = {
    "temperature": 102.0,
    "has_spots":   true
}

var walk_speed: float = 2.0
var gate_pos: Vector3 = Vector3(0.0, 0.0, 2.0)

func _process(delta: float) -> void:
    if position.distance_to(gate_pos) > 0.2:
        var dir := (gate_pos - position).normalized()
        position += dir * walk_speed * delta