# world.gd: Attach this script to your World Node3D
extends Node3D

func _ready() -> void:
    print("🛡️ Checkpoint is live, Day 1 begins!")