# gate_controller.gd: Attach to a Node3D near the gate
extends Node3D

@onready var gate_mesh:   MeshInstance3D = $GateMesh
@onready var alarm_light: OmniLight3D    = $AlarmLight
var current_survivor: Node3D = null

# GateArea: notices when a visitor reaches the window
func _on_gate_area_body_entered(body: Node3D) -> void:
    if body.is_in_group("survivor"):
        current_survivor = body

# The Day 1 rule: safe means 100°F or lower
func is_safe(survivor: Node3D) -> bool:
    return survivor.hidden_stats["temperature"] <= 100.0

# GREEN button: let the visitor in
func _on_green_area_body_entered(body: Node3D) -> void:
    if not body.is_in_group("players") or current_survivor == null:
        return
    if not is_safe(current_survivor):
        GameManager.mistake_made()   # ❌ oops, they were sick!
    var y := gate_mesh.position.y
    var tw := create_tween()
    tw.tween_property(gate_mesh, "position:y", y + 3.0, 1.0)
    tw.tween_interval(2.0)
    tw.tween_property(gate_mesh, "position:y", y, 1.0)
    _finish_visitor()

# RED button: sound the alarm and send them away
func _on_red_area_body_entered(body: Node3D) -> void:
    if not body.is_in_group("players") or current_survivor == null:
        return
    if is_safe(current_survivor):
        GameManager.mistake_made()   # ❌ oops, they were healthy!
    _finish_visitor()
    alarm_light.visible = true
    await get_tree().create_timer(2.0).timeout
    alarm_light.visible = false

func _finish_visitor() -> void:
    current_survivor.queue_free()   # the visitor walks off
    current_survivor = null