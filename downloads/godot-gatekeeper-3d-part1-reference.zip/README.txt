Who Goes There? Part 1: Build a 3D Co-op Checkpoint in Godot
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/godot-gatekeeper-3d-part1.html

Reference GDScript files for this workshop.
These are the scripts shown step by step in the lesson. Build the scenes in the
Godot editor as the steps describe, then attach each script to the matching node.

Scripts:
- world.gd
- menu.gd
- player.gd
- survivor_3d.gd
- thermometer.gd
- rulebook.gd
- gate_controller.gd
- game_manager.gd
- day_manager.gd
- character_swap.gd

How to use:
1. Create the Godot project and scenes exactly as the workshop steps describe.
2. Create a script with the same name and paste (or type) the code in.
3. Stuck? Compare your script to the reference here.
