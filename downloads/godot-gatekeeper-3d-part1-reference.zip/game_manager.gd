# game_manager.gd: Register as an Autoload in Project Settings
extends Node

var base_health: int = 100
var current_day: int = 1

func mistake_made() -> void:
    base_health -= 20
    print("⚠️ Base Health: %d" % base_health)
    _update_health_display()
    if base_health <= 0:
        game_over()

func _update_health_display() -> void:
    # Finds the Label3D you put in the "health_label" group
    var lbl = get_tree().get_first_node_in_group("health_label")
    if lbl:
        lbl.text = "🛡️ Base: %d / 100" % base_health

func game_over() -> void:
    print("❌ GAME OVER, the base has fallen!")
    get_tree().change_scene_to_file("res://game_over.tscn")