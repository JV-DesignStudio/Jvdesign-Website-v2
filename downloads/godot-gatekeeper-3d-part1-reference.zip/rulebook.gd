# rulebook.gd: Attach to your 3D board node inside the booth
extends Node3D

@onready var rule_sign: Label3D = $RuleSign

var daily_rules: Dictionary = {
    1: "DO NOT let anyone in\\nwith temp over 100°F!",
    2: "DO NOT let anyone in\\nwith green spots!\\nAND: no temp over 100°F!",
    3: "ADMIT anyone from District 7.\\nDeny all others with temp > 100°F."
}

func _ready() -> void:
    update_for_day(GameManager.current_day)

func update_for_day(day: int) -> void:
    if day in daily_rules:
        rule_sign.text = daily_rules[day]
    else:
        rule_sign.text = "Check ALL rules from previous days!"