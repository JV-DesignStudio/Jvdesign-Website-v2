# day_manager.gd: Attach to the DayManager node in your World scene
extends Node

# The % sign finds nodes marked "Access as Unique Name"
@onready var day_timer: Timer   = %DayTimer
@onready var clock_lbl: Label3D = %ClockLabel
@onready var safe_room: Node3D  = %SafeRoomMarker

func _ready() -> void:
    day_timer.wait_time = 120.0
    day_timer.one_shot = true
    day_timer.start()

func _process(_delta: float) -> void:
    var s := int(day_timer.time_left)
    clock_lbl.text = "%02d:%02d" % [s / 60, s % 60]

func _on_day_timer_timeout() -> void:
    end_day()

func end_day() -> void:
    for player in get_tree().get_nodes_in_group("players"):
        player.global_position = safe_room.global_position
    print("Day %d complete! Rest up." % GameManager.current_day)
    GameManager.current_day += 1

func start_next_day() -> void:
    day_timer.start()