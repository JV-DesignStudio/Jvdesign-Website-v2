# menu.gd: Attach to your Control root in menu.tscn
extends Control

func _on_host_pressed() -> void:
    var peer = ENetMultiplayerPeer.new()
    peer.create_server(7777, 4)   # port 7777, max 4 players
    multiplayer.multiplayer_peer = peer
    get_tree().change_scene_to_file("res://world.tscn")

func _on_join_pressed() -> void:
    var peer = ENetMultiplayerPeer.new()
    peer.create_client("127.0.0.1", 7777)  # same-machine test
    multiplayer.multiplayer_peer = peer
    get_tree().change_scene_to_file("res://world.tscn")