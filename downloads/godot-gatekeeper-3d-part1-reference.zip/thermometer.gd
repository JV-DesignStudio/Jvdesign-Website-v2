# thermometer.gd: Attach to your Thermometer Node3D
extends Node3D

@onready var floating_label: Label3D = $FloatingLabel
var is_held: bool = false

func _ready() -> void:
    floating_label.visible = false

func _on_area_3d_body_entered(body: Node3D) -> void:
    if body.is_in_group("survivor"):
        var temp: float = body.hidden_stats["temperature"]
        floating_label.text    = "🌡️ %.1f°F" % temp
        floating_label.visible = true

func _on_area_3d_body_exited(body: Node3D) -> void:
    if body.is_in_group("survivor"):
        floating_label.visible = false