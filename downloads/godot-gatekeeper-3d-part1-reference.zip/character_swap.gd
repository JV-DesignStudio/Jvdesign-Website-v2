# character_swap.gd: Attach to your Survivor3D or Player root
extends Node3D

# Drag your imported .glb into the scene, then link it here
@onready var placeholder: MeshInstance3D = $PlaceholderBox
@onready var real_model:  Node3D         = $LumoFoxModel

func _ready() -> void:
    placeholder.visible = false   # hide grey box
    real_model.visible  = true    # show real character
    print("🦊 Lumo is ready at the gate!")