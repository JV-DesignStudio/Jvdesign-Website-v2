My First 3D Model Ep 5: Materials & Textures
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/blender-materials-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First 3D Model Ep 5: Materials & Textures

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Test scene: a few spheres on a plane, rendered viewport (Z → Rendered), Cycles if your machine allows.
- Every new material is a Principled BSDF, an "everything shader" built on real physics (PBR).
- The big four: Base Color (what it is), Metallic (0 or 1, almost never between), Roughness (mirror 0 → chalk 1), IOR/Transmission (glass).
- Drill: make one sphere chalky red (rough 0.9), one glossy plastic (rough 0.15), one brushed metal (metallic 1, rough 0.4).
- GOLD: Metallic 1, Base Color warm yellow-orange (metal colour lives IN the base color), Roughness 0.25.
- GLASS: Transmission 1, Roughness 0 (clear) or 0.3 (frosted). Cycles renders it true; in Eevee (4.2+) it works via raytracing, older Eevee needs Blend Mode tweaks.
- GLOW: an Emission value above 0 with a colour, the surface becomes a light source. Strength 5+ for neon signage.
- Combine: a gold ring on a glass slab under a neon light = a product shot. Render it (F12)!
- To put an IMAGE on a 3D surface, the surface must be flattened to 2D first, like peeling an orange flat. That flattening is UV unwrapping.
- Open the UV Editing workspace tab (top of the window), 2D left, 3D right.
- The orange-peel cuts are seams: in Edit Mode, select edges and Ctrl+E → Mark Seam. For a cube: seam 7 edges so it unfolds into a cross shape.
- Select all (A) → U → Unwrap. The left panel shows your flattened cube!
- Try it on your character too, seams down the sides where they hide.
- With the character unwrapped, switch to the Texture Paint workspace.
- Add a paint canvas: Texture slot → Base Color → new image (1024×1024, a skin base colour).
- Paint IN THE 3D VIEW, strokes land on the model and appear on the flat image simultaneously. Magic.
- Paint: eyes, brows, a mouth, shirt details, shoe caps. Low-poly + hand-paint = timeless indie style.
- CRITICAL: painted images are not auto-saved with the file! Image → Save As in the image editor, and enable Image → Pack to embed it.
- Open the Shading workspace, your material as a node graph.
- Shift+A → Texture → Noise Texture; connect its Color output into Base Color. Instant marble-ish pattern, no image involved!
- Insert a ColorRamp between them (Shift+A → Converter) to remap the noise into exactly two wood tones. Drag the flags to taste.
- Stretch the pattern into grain: add a Mapping node before the noise, scale Y to 8.
- Procedural = infinite resolution, zero files, always editable. The node graph IS the texture recipe.
- Open your Episode 1 house scene. Time for the glow-up.
- Walls: procedural noise → subtle plaster. Roof: ColorRamp brick tones. Door: your wood grain nodes. Windows: GLASS. A porch light: EMISSION.
- Ground: dark rough material (0.9) so the house pops.
- Render with F12 in Cycles. Compare with your Episode 1 render, same shapes, unrecognisable quality. Materials did that.
- Save everything, Episode 6 relights this exact scene for drama.


--------------------------------------------------------------------
BONUS: BLENDER PYTHON BUILDER
--------------------------------------------------------------------
This pack also includes build_materials.py, a script that builds a "Materials & Textures" setup for you.

How to run it:
1. Open Blender 4.x.
2. Go to the Scripting tab, click Open, and choose build_materials.py.
3. Click Run Script (the play button). The model appears in your scene.
4. Press F12 to render, or keep building on top of it.
