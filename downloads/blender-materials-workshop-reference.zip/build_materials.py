# build_materials.py - Blender 4.x
# My First 3D Model Ep 5: Materials & Textures
import bpy

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

def make_material(name, colour, roughness):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*colour, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    return mat

colours = [("Red", (0.8, 0.1, 0.1), 0.3),
           ("Green", (0.1, 0.7, 0.2), 0.5),
           ("Blue", (0.1, 0.3, 0.9), 0.1)]

for i, (name, col, rough) in enumerate(colours):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.6, location=(i * 1.6 - 1.6, 0, 1))
    obj = bpy.context.active_object
    obj.name = name + "Sphere"
    obj.data.materials.append(make_material(name + "Mat", col, rough))

bpy.ops.object.light_add(type='SUN', location=(4, -4, 8))
bpy.context.active_object.data.energy = 3.0
bpy.ops.object.camera_add(location=(0, -7, 2), rotation=(1.4, 0, 0))
bpy.context.scene.camera = bpy.context.active_object

print("Three materials applied. Change the Base Color and Roughness to experiment.")
