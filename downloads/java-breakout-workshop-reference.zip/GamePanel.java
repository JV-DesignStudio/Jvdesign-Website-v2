// ===== Part 1 of 4 (as shown in the lesson) =====
int padX = 295, padW = 110, padH = 14;
    boolean leftHeld, rightHeld;

    void update() {
        if (leftHeld)  padX -= 7;
        if (rightHeld) padX += 7;
        padX = Math.max(0, Math.min(700 - padW, padX));
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(new Color(255, 119, 0));
        g.fillRoundRect(padX, 470, padW, padH, 8, 8);
    }

// ===== Part 2 of 4 (as shown in the lesson) =====
int bx = 340, by = 300, bs = 14;
    int bvx = 4, bvy = -4;

    void update() {
        // ... paddle code ...
        bx += bvx;  by += bvy;
        if (bx <= 0 || bx + bs >= 700) bvx = -bvx;   // side walls
        if (by <= 0) bvy = -bvy;                     // ceiling

        Rectangle ball = new Rectangle(bx, by, bs, bs);
        Rectangle pad  = new Rectangle(padX, 470, padW, padH);
        if (ball.intersects(pad) && bvy > 0) {
            bvy = -bvy;
            int hit = (bx + bs/2) - (padX + padW/2);
            bvx = hit / 12;              // steer with the paddle!
            if (bvx == 0) bvx = 1;
        }
    }

// ===== Part 3 of 4 (as shown in the lesson) =====
boolean[][] bricks = new boolean[5][10];
    Color[] rowColors = { new Color(248,113,113), new Color(251,146,60),
        new Color(250,204,21), new Color(74,222,128), new Color(96,165,250) };

    // in constructor:
    for (int r = 0; r < 5; r++)
        for (int c = 0; c < 10; c++)
            bricks[r][c] = true;

    // in paintComponent:
    for (int r = 0; r < 5; r++)
        for (int c = 0; c < 10; c++)
            if (bricks[r][c]) {
                g.setColor(rowColors[r]);
                g.fillRect(c*68 + 12, r*26 + 50, 64, 22);
            }

// ===== Part 4 of 4 (as shown in the lesson) =====
int lives = 3;
    boolean gameOver = false, won = false;

    void update() {
        if (gameOver || won) return;    // freeze the game
        // ... all previous code ...

        if (by > 520) {                 // ball lost!
            lives--;
            bx = 340; by = 300; bvx = 4; bvy = -4;
            if (lives == 0) gameOver = true;
        }

        int alive = 0;
        for (int r = 0; r < 5; r++)
            for (int c = 0; c < 10; c++)
                if (bricks[r][c]) alive++;
        if (alive == 0) won = true;
    }