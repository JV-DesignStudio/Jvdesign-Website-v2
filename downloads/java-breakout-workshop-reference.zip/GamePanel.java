int bx = 340, by = 300, bs = 14;
    int bvx = 4, bvy = -4;

    void update() {
        // ... paddle code ...
        bx += bvx;  by += bvy;
        if (bx <= 0 || bx + bs >= 700) bvx = -bvx;   // side walls
        if (by <= 0) bvy = -bvy;                     // ceiling

        Rectangle ball = new Rectangle(bx, by, bs, bs);
        Rectangle pad  = new Rectangle(padX, 470, padW, padH);
        if (ball.intersects(pad) && bvy > 0) {
            bvy = -bvy;
            int hit = (bx + bs/2) - (padX + padW/2);
            bvx = hit / 12;              // steer with the paddle!
            if (bvx == 0) bvx = 1;
        }
    }