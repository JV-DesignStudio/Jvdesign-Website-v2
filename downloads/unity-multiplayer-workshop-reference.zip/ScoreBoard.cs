using Unity.Netcode;
using TMPro;

public class ScoreBoard : NetworkBehaviour
{
    public NetworkVariable<int> score = new NetworkVariable<int>(0);
    public TMP_Text label;

    public override void OnNetworkSpawn()
    {
        score.OnValueChanged += (oldVal, newVal) =>
            label.text = "Score: " + newVal;
    }

    public void AddPoint()
    {
        if (!IsServer) return;      // authority!
        score.Value += 1;
    }
}