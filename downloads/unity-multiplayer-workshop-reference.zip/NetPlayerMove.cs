using Unity.Netcode;
using UnityEngine;

public class NetPlayerMove : NetworkBehaviour
{
    public float speed = 5f;

    void Update()
    {
        if (!IsOwner) return;    // only drive YOUR player!

        Vector2 input = new Vector2(
            Input.GetAxisRaw("Horizontal"),
            Input.GetAxisRaw("Vertical")).normalized;

        transform.position += (Vector3)(input * speed * Time.deltaTime);
    }
}