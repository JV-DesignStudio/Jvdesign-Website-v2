using Unity.Netcode;
using UnityEngine;

public class PlayerEmote : NetworkBehaviour
{
    void Update()
    {
        if (IsOwner && Input.GetKeyDown(KeyCode.E))
            EmoteServerRpc();
    }

    [ServerRpc]
    void EmoteServerRpc()
    {
        EmoteClientRpc();       // server approves & broadcasts
    }

    [ClientRpc]
    void EmoteClientRpc()
    {
        // runs on EVERY client:
        Instantiate(confettiPrefab, transform.position,
                    Quaternion.identity);
    }
}