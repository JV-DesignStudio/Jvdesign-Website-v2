Geometric Shape Set
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/tinkercad-ep8-shapes.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Geometric Shape Set

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Our shape collection
- Cube, all sides equal
- Sphere, perfectly round
- Cylinder, circular cross-section with height
- Cone, circular base tapering to a point
- Pyramid, square base with triangular sides
- Triangular Prism, triangle cross-section
- Hexagonal Prism, hexagon cross-section
- Torus, donut shape
- 3. Cylinder4. Cone5. Pyramid6. Tri. Prism7. Hex. Prism8. Torus The full set you are about to build. One shape per step, all sized around 25 mm so they feel like a matching family, plus a storage tray at the end. 💡Open TinkerCAD and create a new design. Name it "Geometric Shape Set" so you can find it later. 🧠 Knowledge Check +15 XP How many basic 3D shapes will we create for our collection? A5 B8 C12 Check Answer ✅ Correct! Next Step → 2 🟦 Create a Perfect Cube Make a box with all equal dimensions, 25x25x25mm Locked 🎯 Goal for this stepCreate a perfect cube where all three dimensions (width, depth, height) are exactly the same. Build the cube Drag a Box shape from the Basic Shapes panel onto the workplane.
- Click on the box to select it. You'll see dimension handles appear.
- Set the Width to 25mm.
- Set the Depth to 25mm.
- Set the Height to 25mm.
- 25 mm 6 faces · 12 edges · 8 corners Width, depth and height all read 25. If even one is different it is a box, not a cube. Type each number rather than dragging. 💡What makes a cube special? All sides are equal! A regular box can have different width, depth, and height, but a cube must have the same value for all three. ⚡ True or False? +15 XP A cube has all equal side lengths. TrueFalse A cube has 8 faces. TrueFalse All edges of a cube are the same length. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP What makes a cube different from a rectangular box? AAll dimensions are equal BIt has more faces CIt has rounded corners Check Answer ✅ Correct! Next Step → 3 🔵 Create a Sphere Drag a sphere and learn about diameter vs radius Locked 🎯 Goal for this stepCreate a sphere and understand the relationship between diameter and radius. Build the sphere Drag a Sphere from the Basic Shapes panel onto the workplane.
- Click the sphere to select it.
- Set the diameter to 25mm. This means the sphere is 25mm across.
- The radius is half the diameter, so our sphere has a radius of 12.5mm.
- diameter 25 mm radius 12.5 mm (half the diameter) No faces, no edges, one smooth surface. Diameter is all the way across; radius is centre to edge, exactly half. 💡Diameter vs Radius: The diameter is the full width across the middle of a circle or sphere. The radius is half that, from the centre to the edge. Radius = Diameter ÷ 2. ✏️ Fill in the Blanks +15 XP Our sphere has a diameter of mm. That means its radius is mm. ✏️ Check Answers 🧠 Knowledge Check +15 XP If the diameter of a sphere is 25mm, what is the radius? A25mm B12.5mm C50mm Check Answer ✅ Correct! Next Step → 4 🛢️ Create a Cylinder Experiment with different heights and diameters Locked 🎯 Goal for this stepCreate a cylinder and understand how diameter and height work together. Build the cylinder Drag a Cylinder from the Basic Shapes panel onto the workplane.
- Set the diameter to 25mm.
- Set the height to 30mm, slightly taller than it is wide.
- Notice how a cylinder has 2 flat circular faces (top and bottom) and 1 curved surface wrapping around the side.
- flat face (top + bottom = 2) 1 curved surface wraps around 30 mm 25 mm across Two flat circles + one curved wrap. Slightly taller than wide (30 vs 25) so it reads as a tower, not a puck. 💡A cylinder is like a tin can! The top and bottom are circles, and the side is a curved surface. Think of a Pringles tube. 💻 Code Challenge +20 XP Fill in the blanks to set the correct cylinder dimensions: Cylinder Settings: Diameter: mm Height: mm 🔍 Check Code 💡 Hint: The diameter is 25mm and the height is 30mm. 🧠 Knowledge Check +15 XP A cylinder has how many flat faces? A2 (top and bottom circles) B1 (just the bottom) C4 (top, bottom, and two sides) Check Answer ✅ Correct! Next Step → 5 🔺 Create a Cone Explore the base diameter and height relationship Locked 🎯 Goal for this stepCreate a cone and explore what happens when you change the height-to-base ratio. Build the cone Drag a Cone shape from the Basic Shapes panel onto the workplane. In TinkerCAD this may appear as "Cone" or you can find it under shape generators.
- Set the base diameter to 25mm.
- Set the height to 30mm.
- Try changing the height to 60mm while keeping the base at 25mm. Notice how it becomes a tall, thin spike!
- Set the height back to 30mm for our final set.

## Build the pyramid
- In TinkerCAD, look for a Pyramid shape in Basic Shapes, or search for it in Shape Generators.
- Drag the pyramid onto the workplane.
- Set the base width to 25mm and base depth to 25mm (square base).
- Set the height to 30mm.
- A square-based pyramid has 5 faces: 1 square base + 4 triangular sides.
- 4 triangle sides meet at the tip + 1 square base underneath = 5 faces 25 ✨ 25 base, 30 tall. Like a tiny Egyptian pyramid. Count the faces when it prints: four triangles plus the square it stands on. 💡If you can't find a pyramid shape, try using the Roof shape or look in Shape Generators → All and search for "pyramid". ⚡ True or False? +15 XP A square-based pyramid has a square base. TrueFalse A square-based pyramid has 5 faces in total. TrueFalse Pyramids and cones are the same shape. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP Where can you find a pyramid shape in TinkerCAD? AIt doesn't exist in TinkerCAD BIn Basic Shapes or Shape Generators CYou have to draw it by hand Check Answer ✅ Correct! Next Step → 7 🔷 Create a Triangular Prism Understand cross-sections and prism shapes Locked 🎯 Goal for this stepCreate a triangular prism and learn what a cross-section is. Build the triangular prism Look for a Wedge or Roof shape in TinkerCAD's Basic Shapes, this creates a triangular prism.
- You can also find triangular prism shapes in Shape Generators.
- Set the width to 25mm, depth to 25mm, and height to 25mm.
- A cross-section is the shape you'd see if you sliced through the middle. If you slice a triangular prism, you get a triangle!
- slice anywhere along it → always the same triangle THE WEDGE = TRIANGULAR PRISM "Cross-section" = the shape you would see at the cut. A prism keeps the same cross-section all the way through, here, a triangle. 💡Cross-section concept: Imagine slicing through a shape like cutting a loaf of bread. The shape of the slice is the cross-section. A triangular prism has a triangle cross-section, just like a Toblerone box! ✏️ Fill in the Blanks +15 XP A triangular prism has a cross-section. If you sliced through it, the cut shape would be a . ✏️ Check Answers 🧠 Knowledge Check +15 XP What shape is the cross-section of a triangular prism? ATriangle BSquare CCircle Check Answer ✅ Correct! Next Step → 8 ⬡ Create a Hexagonal Prism Use the Polygon shape and set the number of sides Locked 🎯 Goal for this stepCreate a hexagonal prism using the Polygon shape with 6 sides. Build the hexagonal prism Find the Polygon shape in TinkerCAD's Basic Shapes or Shape Generators panel.
- Drag it onto the workplane.
- In the shape settings, set Sides to 6, this makes it a hexagon.
- Set the diameter to 25mm and height to 25mm.
- A hexagon has 6 equal sides. Hexagonal prisms are found everywhere in nature, honeycomb cells are hexagons!

## Build the torus
- The torus is not in the Basic Shapes panel. Click the dropdown at the top of the shapes panel and switch to Shape Generators or All.
- Search for "Torus" or scroll through the shape generators to find it.
- Drag the torus onto the workplane.
- Set the outer diameter to about 25mm.
- A torus is like a donut, it has a hole through the middle and no edges or vertices!
- outer diameter 25 mm the hole goes right through no edges, no corners, all curve Hiding in Shape Generators, not Basic Shapes. Switch the panel dropdown, search "torus", and meet the only shape in the set with a hole built in. 💡A torus is one of the most interesting shapes! It's made by rotating a circle around an axis. You can find torus shapes in real life as donuts, bagels, and rings. ⚡ True or False? +15 XP A torus looks like a donut. TrueFalse The torus is found in TinkerCAD's Basic Shapes panel. TrueFalse A torus has a hole through the middle. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP Where do you find the torus shape in TinkerCAD? ABasic Shapes panel BIt doesn't exist in TinkerCAD CShape Generators panel Check Answer ✅ Correct! Next Step → 10 🔢 Add Numbers to Each Shape Use Text as a Hole to engrave numbers 1-8 on each shape Locked 🎯 Goal for this stepNumber each shape 1-8 by using the Text shape as a Hole and grouping it with each shape. Engrave numbers on each shape Find the Text shape in the Basic Shapes panel (or search for it).
- Drag a Text shape onto the workplane. Type the number "1".
- Resize the text to fit on the face of the cube, around 10-12mm tall.
- Change the text from Solid to Hole using the shape inspector (top right of the shape settings).
- Position the text on a flat face of the cube using the Align tool.
- Select both the cube and the text, then click Group (Ctrl+G). The number is now engraved!
- Repeat for shapes 2-8.
- Text "1" → Hole → Align → Group 10-12 mm tall, engraved into a flat face of the shape Number every shape 1 to 8. Same trick each time: a Text shape set to Hole, aligned onto a flat face, then grouped. The sphere and torus are trickiest, pick their flattest spot. 💡When you set a shape to Hole and Group it with a Solid shape, TinkerCAD subtracts the hole from the solid, creating an engraved effect. This is called a Boolean subtraction. 🔢 Put It In Order +15 XP Click these steps in the correct order to engrave a number on a shape: Change the text to Hole Drag a Text shape onto the workplane Select both shapes and Group (Ctrl+G) Type the number Align the text on the shape face Resize the text to fit 🔍 Check Order↺ Reset 🧠 Knowledge Check +15 XP What happens when you Group a Hole shape with a Solid shape? AThey both disappear BThe Hole is subtracted from the Solid, creating an engraved cut CNothing happens Check Answer ✅ Correct! Next Step → 11 📦 Create the Storage Tray Build a large flat box with compartment walls Locked 🎯 Goal for this stepBuild a storage tray with walls and dividers to hold all 8 shapes. Build the tray Start a new TinkerCAD design for the tray (or build it next to your shapes).
- Drag a large Box onto the workplane, about 140mm wide x 80mm deep x 20mm tall.
- Create a slightly smaller box as a Hole, about 136mm x 76mm x 18mm. This will hollow out the inside.
- Raise the Hole box 2mm off the workplane (so the tray keeps a solid bottom).
- Select both and Group, you now have a hollow tray!
- Add thin wall dividers (solid boxes, 2mm thick) to create compartments for each shape.
- CUTAWAY · BOX + RAISED HOLE 2 mm solid floor TRAY WITH DIVIDERS 2 mm walls make the compartments 140 ✨ 80 × 20 mm outside · hole box 136 ✨ 76 ✨ 18, raised 2 mm before grouping Raise the hole box 2 mm before grouping, that is what leaves a solid floor instead of cutting straight through the bottom of the tray. 💡Arrange the compartments in a 2x4 grid (2 rows of 4) so all 8 shapes have their own space. Each compartment should be about 32mm x 35mm. 🔮 Predict What Happens +15 XP You've built the tray, but the compartments are exactly 25mm x 25mm, the same size as your shapes. What will happen when you try to put the shapes in? AThe shapes won't fit, there's no room for printing tolerance or easy removal BThey'll fit perfectly every time CThe shapes will shrink to fit 🔮 Check Prediction 🧠 Knowledge Check +15 XP How do you hollow out a box in TinkerCAD? AClick a "hollow" button BDelete the inside with an eraser CPlace a slightly smaller Hole box inside and Group them Check Answer ✅ Correct! Next Step → 12 📐 Size the Compartments Add 2mm clearance so shapes fit easily after printing Locked 🎯 Goal for this stepSize each compartment slightly larger than its shape, adding 2mm clearance for printing tolerance. Calculate compartment sizes Each shape is roughly 25mm across. We need to add 2mm of clearance, 1mm on each side.
- So each compartment should be about 27mm x 27mm at minimum.
- For the taller shapes (cylinder, cone), make the tray walls at least 18mm tall so they stay secure.
- The torus and sphere need slightly wider compartments, about 29mm, because they can roll.
- Double-check each compartment by placing the shape inside it in TinkerCAD to test the fit.
- 2729 ⚠2727 27272729 ⚠ cubespherecylindercone pyramidtri prismhex prismtorus shapes are 25 mm → compartments 27 mm (+1 mm clearance each side) · rollers get 29 mm Test the fit inside TinkerCad: drop each shape into its compartment on screen. If it overlaps a wall there, it will not fit in real life either. 👨‍👧Parent note: Clearance is important in 3D printing because printed objects are never perfectly exact. Adding 1-2mm of extra space on each side ensures pieces fit together properly. ✏️ Fill in the Blanks +15 XP We add mm of clearance. So a 25mm cube needs a compartment that is mm wide. ✏️ Check Answers 🧠 Knowledge Check +15 XP Why do we add 2mm clearance to each compartment? ATo make the tray look bigger BBecause the shapes will grow during printing CFor printing tolerance and easy removal of shapes Check Answer ✅ Correct! Next Step → 13 🏷️ Add Labels to Compartments Engrave shape names on each compartment Locked 🎯 Goal for this stepAdd text labels to each compartment so you know which shape goes where. Label each compartment For each compartment, drag a Text shape onto the workplane.
- Type the shape name, e.g., "CUBE", "SPHERE", etc.
- Make the text small enough to fit, around 4-5mm tall.
- Set each text to Hole, this will engrave the names into the tray bottom.
- Position each label at the bottom of its compartment.
- Make the text only 1mm deep so it doesn't go all the way through the tray.
- Select the tray and all labels, then Group to engrave them all at once.
- Text → Hole · 4-5 mm letters only 1 mm deep, floor is 2 mm Depth matters here: the floor is only 2 mm thick, so make the label text 1 mm deep. Full-depth letters would punch holes right through the tray. 💡Labels can be engraved (cut into the surface using Holes) or raised (added as solid shapes on top). Engraved labels are easier to print and won't break off. ⚡ True or False? +15 XP Labels help identify where each shape goes in the tray. TrueFalse Labels must always be raised, they can't be engraved. TrueFalse Text size affects readability, smaller text may be harder to read. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP What's the advantage of engraving labels (Hole) instead of raising them (Solid)? AEngraved labels are easier to print and won't break off BRaised labels are always better CThere's no difference Check Answer ✅ Correct! Next Step → 14 🎨 Color-Code Everything Assign matching colors to shapes and their compartments Locked 🎯 Goal for this stepAssign a unique color to each shape and its matching compartment for easy sorting. Color-code the set Click on the Cube to select it.
- In the shape inspector, click the color swatch to open the color picker.
- Choose a color, e.g., Red for the cube.
- Now color the cube's compartment in the tray the same Red color.
- Repeat for all 8 shapes, choosing a different color for each: 1. Cube = Red, 2. Sphere = Blue, 3. Cylinder = Green, 4. Cone = Yellow, 5. Pyramid = Orange, 6. Tri-Prism = Purple, 7. Hex-Prism = Pink, 8. Torus = Teal

## Export and print
- In TinkerCAD, click the Export button (top right).
- Choose .STL as the file format, this is the standard format for 3D printing.
- You can export all shapes at once or individually.
- Open your slicer software (like Cura, PrusaSlicer, or Bambu Studio).
- Import all your shapes. Batch printing means arranging multiple objects on the build plate and printing them all in one job.
- Arrange all pieces on the build plate with about 5mm gap between each one.
- Set your layer height, 0.2mm is a good balance of speed and quality.
- Click Slice, then print! The tray should be printed separately as it's much larger.
