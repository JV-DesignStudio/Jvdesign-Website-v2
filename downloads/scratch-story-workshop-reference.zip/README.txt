Your Story! Build an Interactive Adventure in Scratch
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/scratch-story-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Your Story! Build an Interactive Adventure in Scratch

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## What kind of story will YOU tell?
- Pick a setting, a haunted castle, a space station, an enchanted forest, a school, a pirate ship... anything goes!
- Give your hero a name and a problem to solve.
- Think of one BIG choice the player will make early on. (Example: "Go left or go right?")
- Each path should lead somewhere different, maybe one is happy, one is scary, or one is funny.
- You need at least 2 endings. More is better!

## Setting up scenes
- Open Scratch and start a new project. Click the Stage area (bottom right).
- Click Backdrops tab at the top left.
- For each scene, either Paint your own backdrop or click the blue image icon to choose one from Scratch's library.
- Rename each backdrop clearly: Opening, ForestPath, CastleDoor, HappyEnding, SpookyEnding etc.

## Adding your hero
- Click the blue cat icon (Add Sprite) in the bottom right corner.
- Choose a character from the library, or click Paint to draw your own!
- Rename the sprite Hero in the sprite info panel.
- Drag the sprite to a good position on screen and use the size box to make them the right size (try 80-120).

## Making your hero talk
- In the Hero sprite, add code blocks after the setup from Step 3.
- Use say [ ] for (2) seconds blocks to show speech bubbles.
- Write 2-4 lines that introduce your story, who the hero is, where they are, and what problem they face.
- After the last line, use broadcast [ShowChoices v] to signal that it's time to show the choice buttons.

## Building the choice buttons
- Paint two new sprites: BtnLeft and BtnRight. Draw a simple rectangle with text, e.g. "Go LEFT" and "Go RIGHT".
- Both buttons should start hidden (hide on green flag).
- When they receive ShowChoices, they show and position themselves on screen.
- When clicked, each button broadcasts its path and hides both buttons.

## Scripting Path A in the Hero sprite
- In the Hero sprite, add a new script starting with when I receive [PathA v].
- Switch to the PathA backdrop immediately.
- Move the hero to a new position and write 3-5 lines of dialogue for this path.
- After the dialogue, broadcast Ending1 to trigger the ending.

## Scripting Path B in the Hero sprite
- Add another new script: when I receive [PathB v].
- Switch to the PathB backdrop.
- Write a different adventure, maybe spookier, funnier, or more dangerous!
- End by broadcasting Ending2.

## Costume-based animation
- Click the Hero sprite, then click the Costumes tab. Add or draw 2-3 costumes (normal, talking, scared/happy).
- In the Scripts tab, use switch costume to [ ] before key dialogue lines.
- For a walk animation, use a repeat (5) loop that alternates costumes with a small wait.

## Adding sounds
- Click the Stage, then the Sounds tab. Add a background music track from the Scratch library (try the "Music" or "Loops" category).
- In the Stage's Scripts, add a forever loop to keep the music playing.
- For sound effects, click individual sprites and add sounds to them. Use play sound [ ] until done at dramatic moments.

## Creating a conversation
- Add a new sprite for your NPC (a fairy, a wizard, a monster, a friend, whatever fits your story!).
- Name the sprite NPC (or their actual name).
- Have them start hidden. When the right broadcast is received (e.g. PathA), show them at a specific position.
- Use the Hero and NPC talking back and forth, Hero says a line, then broadcasts NPCTalk, NPC responds, then broadcasts HeroTalk2, etc.

## Nesting choices inside a path
- Pick one path (A or B) that will get an extra choice part-way through.
- After a few dialogue lines, broadcast ShowChoices2 instead of an ending.
- Create two new button sprites (or reuse BtnLeft/BtnRight) that respond to ShowChoices2 and broadcast PathA1 / PathA2.
- Write separate dialogue for each sub-path, ending in Ending1 or Ending3 (a brand new ending!).

## Building the ending scenes
- For each ending, add a script in the Hero sprite: when I receive [Ending1 v].
- Switch to the matching ending backdrop.
- Show 2-3 final dialogue lines that wrap up the story.
- Add a visual celebration, change colour effects, play a happy sound, or use a confetti sprite!
- Create a PlayAgain button sprite that broadcasts RestartGame when clicked, which triggers stop all then relaunches everything.

## Testing checklist
- Click the green flag and play Path A all the way to its ending. Does everything work?
- Click the green flag again and play Path B all the way to its ending. Does everything work?
- If you added a third path, play that too!
- Check: do buttons hide after being clicked? Does music loop without gaps? Does the Play Again button restart cleanly?
- Fix any bugs you find. Look for: sprites that don't hide, wrong backdrop showing, dialogue that runs out of order.

## Polishing touches
- Add a title screen backdrop as the very first backdrop, with the game's name drawn on it. Show it for 2 seconds before the story starts.
- Give your project a great name and write a description in Scratch so other players know what it's about.
- Click Share to publish! Copy the link and share it with friends and family.
