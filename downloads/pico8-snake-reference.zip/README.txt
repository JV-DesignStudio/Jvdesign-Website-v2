Snake Game in Pico-8
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/pico8-snake-workshop.html

This is a finished Pico-8 cartridge: a complete, playable game you can open
in Pico-8 (or at lexaloffle.com) and run immediately.

File:
- snake.p8

How to use:
1. Open Pico-8 and type:  load snake.p8
   (or drag the file onto the Pico-8 window, or use "Load cart" in the web player).
2. Press Ctrl+R to run, then follow the on-screen controls.
3. Open the CODE tab to read every line, then rebuild it step by step in the workshop.

Controls are printed on screen for each game.
