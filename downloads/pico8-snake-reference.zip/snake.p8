pico-8 cartridge // http://www.pico-8.com
version 41
__lua__
-- snake.p8  JVDesignStudio
function _init()
  g=16
  reset()
end

function reset()
  dx=1 dy=0
  snake={}
  add(snake,{x=4,y=4})
  add(snake,{x=3,y=4})
  add(snake,{x=2,y=4})
  score=0
  move_timer=0
  move_speed=8
  game_over=false
  spawn_food()
end

function spawn_food()
  fx=flr(rnd(8))
  fy=flr(rnd(8))
  for s in all(snake) do
    if s.x==fx and s.y==fy then
      spawn_food()
      return
    end
  end
end

function _update()
  if game_over then
    if btnp(4) then reset() end
    return
  end
  if btnp(0) and dx==0 then dx=-1 dy=0 end
  if btnp(1) and dx==0 then dx=1 dy=0 end
  if btnp(2) and dy==0 then dx=0 dy=-1 end
  if btnp(3) and dy==0 then dx=0 dy=1 end

  move_timer=move_timer+1
  if move_timer<move_speed then return end
  move_timer=0

  for i=#snake,2,-1 do
    snake[i].x=snake[i-1].x
    snake[i].y=snake[i-1].y
  end
  snake[1].x=snake[1].x+dx
  snake[1].y=snake[1].y+dy

  if snake[1].x<0 or snake[1].x>7 or snake[1].y<0 or snake[1].y>7 then
    game_over=true
  end
  for i=2,#snake do
    if snake[1].x==snake[i].x and snake[1].y==snake[i].y then
      game_over=true
    end
  end

  if snake[1].x==fx and snake[1].y==fy then
    score=score+1
    add(snake,{x=snake[#snake].x,y=snake[#snake].y})
    spawn_food()
    sfx(0)
    if move_speed>3 then move_speed=move_speed-0.5 end
  end
end

function _draw()
  cls(0)
  for i=0,8 do
    line(i*g,0,i*g,128,1)
    line(0,i*g,128,i*g,1)
  end
  rectfill(fx*g+2,fy*g+2,fx*g+13,fy*g+13,8)
  for s in all(snake) do
    rectfill(s.x*g+1,s.y*g+1,s.x*g+14,s.y*g+14,11)
  end
  print("score "..score,2,2,7)
  if game_over then
    print("game over",38,58,8)
    print("press z",48,68,6)
  end
end
