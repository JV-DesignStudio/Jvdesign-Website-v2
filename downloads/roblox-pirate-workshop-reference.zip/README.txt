Build a Pirate Game in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-pirate-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Build a Pirate Game in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Install Roblox Studio & start a place
- Go to roblox.com, sign in (or create a free account), then click Create.
- If prompted, download and install Roblox Studio, it's free.
- Once Studio opens, choose the Baseplate template, a flat grey block to build on.
- Click Create to open your new place.

## Find your way around Studio
- Viewport, the big 3D area in the middle. This is your game world.
- Explorer (right side), a list of everything in your game, like folders and files.
- Properties (below Explorer), settings for whatever you have selected.
- Hold Right Mouse Button and move the mouse to look around. While holding it, press W A S D to fly.
- Scroll the Mouse Wheel to zoom. Press Q/E to fly down/up.

## Turn the baseplate into ocean
- Click the Terrain tab at the top of Studio.
- Click Edit to open the Terrain Editor panel.
- Choose the Add tool, set the material to Water, and pick a large brush size.
- Click and drag across the baseplate to flood a large area with water.

## Save your place
- Press Ctrl + S. Choose Save to Roblox.
- Name your place "My Pirate Game" and click Save.

## Build the hull
- Go to Home tab, click Part → Block. A block appears in your world.
- Use the Scale tool or Properties to stretch it: Size X=6, Y=4, Z=20.
- Set BrickColor to a wood colour like "Reddish brown".
- Insert a Wedge part, scale it to match, and place at the front for a pointed bow.
- Duplicate the wedge (Ctrl + D), rotate 180° and place at the back for the stern.

## Add deck, mast & sails
- Insert a Block, flatten it (low Y, wide X/Z) and place on top of the hull as a deck.
- Insert a Cylinder, rotate it upright, and stretch it tall, this is the mast.
- Insert a thin Block, colour it white, and hang it from the mast, that's a sail.
- Duplicate the mast + sail combo and place a second one further along the deck.

## Group into a Model & add a seat
- Select all ship parts, press Ctrl + G to group them into a Model.
- Rename the Model to "PirateShip". Set PrimaryPart to the hull block.
- Insert a VehicleSeat and place it on the deck. Make sure it's inside your PirateShip Model.
- Add a WeldConstraint between the seat and the deck, and between every major part and the hull.

## Scripts 101: where code lives
- A Script runs on the server, use it for movement, damage, scoring.
- A LocalScript runs on each player's device, used for GUIs and camera effects.
- Right-click an object in Explorer → Insert Object → Script to add one.
- Press F5 to test, then check View → Output for errors.

## Make the ship float
- Select every part of the ship. In Properties, make sure Anchored = false for all parts.
- Position the ship above the water surface, not underneath it.
- Press F5 to test, the ship should drop slightly and settle, floating on the water!

## Script the steering controls
- Select the VehicleSeat in Explorer.
- Right-click → Insert Object → Script.
- Delete the default text and paste in the script below:

## Build a cannon
- Insert a Cylinder, rotate it sideways, and scale into a short fat tube.
- Set its colour to dark grey. Name it "CannonBarrel".
- Position it on the edge of the deck, pointing outward over the water.
- Add a WeldConstraint between the cannon and the hull.
- Right-click the cannon → Insert Object → ClickDetector.

## Script the cannon to fire
- Right-click CannonBarrel → Insert Object → Script and paste:

## Add damage & sinking
- Select PirateShip Model → Insert Object → NumberValue, name it "Health", set Value to 100.
- Add a Touched event on each cannonball that reduces the hit ship's Health by 15.
- Add a script that watches Health, when it hits 0, tween all parts downward to "sink", wait 4 seconds, then reset to the starting position.

## Sculpt an island with Terrain
- Open Terrain → Edit. Select the Add tool with material Sand.
- Click below the water surface to build a mound of sand poking above the waves.
- Switch to Grass and add a layer on top for a grassy centre.
- Use the Smooth tool to round off blocky edges.

## Decorate & add a dock zone
- Open Toolbox and search for free models: "palm tree", "rock", "crate".
- Drag them onto your island. Set Anchored = true on each decoration.
- Insert a thin invisible Block along the shoreline (Transparency=1, CanCollide=true). Name it "DockZone".
- Add a Script to DockZone that zeroes the ship's BodyVelocity on contact, a soft landing.

## Add a treasure chest
- Insert a small Block on the island, colour it gold/brown. Name it "TreasureChest".
- Right-click → Insert Object → ProximityPrompt. Set ActionText to "Open Chest", HoldDuration to 1.
- Add a Script that gives the player +25 Gold when triggered, then destroys the chest.

## Create pirate crews (Teams)
- In Explorer, find Teams. Right-click → Insert Object → Team.
- Name it "Red Crew", set TeamColor to "Bright red".
- Insert a second Team: "Blue Crew", TeamColor "Bright blue".
- Tick AutoAssignable on both teams.

## Add spawn points for each crew
- Insert a SpawnLocation near the red ship's dock. Set TeamColor to "Bright red", Neutral = false.
- Insert another near the blue ship. Set TeamColor to "Bright blue", Neutral = false.

## Build a leaderboard
- In Explorer, find ServerScriptService. Insert a Script named "LeaderboardSetup".
- Paste this code:

## Add sound effects
- Open Toolbox → Audio, search for "cannon". Drag a free cannon sound into CannonBarrel.
- In the cannon script, add after creating the ball: cannon:FindFirstChildOfClass("Sound"):Play()
- For ambient ocean sound, drag an "ocean waves" audio into Workspace. Set Looped = true, Playing = true, Volume = 0.3.

## Build a health bar (ScreenGui)
- In StarterGui, insert a ScreenGui.
- Add a Frame (background bar, Size {0,200},{0,24}, dark grey).
- Inside it, add another Frame named "Fill" (green, Size {1,0},{1,0}).
- Add a LocalScript that updates the Fill's width based on the ship's Health value.

## Playtest with friends
- Click the dropdown next to Play → choose Local Server with 2 players.
- Studio opens multiple game windows. Test: do both crews spawn correctly? Can both ships take damage?

## Publish your game!
- Save with Ctrl + S.
- Go to File → Publish to Roblox. Name it, add a description and thumbnail.
- Set access to Friends or Private to start. Click Create.
