MUGEN Complete Game Setup - Reference Project
=============================================

This pack is the finished version of the My First Fighting Game Ep 5
workshop. Open these files beside the workshop and compare them with
your own project, or copy a line back if something went wrong.

What is inside
--------------
data/mugen.cfg                How MUGEN finds your screenpack (the motif line).
data/MyPack/select.def        Your final roster, home stages, arcade ladder and boss.
data/MyPack/system.def        Lifebars and menu music for the screenpack.
README.txt                    This file.

How to use it
-------------
1. Copy data/mugen.cfg into your MUGEN data folder and set the motif line
   to your own screenpack's system.def.
2. Copy data/MyPack/select.def into your screenpack folder and replace the
   character and stage names with the ones you installed.
3. Copy data/MyPack/system.def only if you want the same lifebars and music.

Every code block in the workshop also has a Copy button, so you can paste
a single line without downloading anything.
