My First 3D Model Ep 4: Character Animation
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/blender-animation-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: My First 3D Model Ep 4: Character Animation

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Fresh scene. The Timeline runs along the bottom; the blue playhead is the current frame; 24 frames • 1 second (default settings).
- Frame 1: select the cube, press I → Location. A keyframe (diamond) appears, you SAVED the position at this time.
- Frame 48 (drag the playhead): move the cube 6 units right (G X 6), press I ? Location again.
- Press Space: the cube slides! Blender invents ("interpolates") every frame between your two keys.
- Animation = keyframes + interpolation. Everything else is refinement.
- Every animator alive did this exercise first. Sphere at height 5: key it (frame 1), floor at frame 12, key, back up (a bit lower, 3.5) frame 24, key, floor 32, up 2.5 at 40- decaying bounces.
- Play it. Feels floaty and wrong, right? GOOD. That is the lesson: even spacing = robotic.
- Open the Dope Sheet editor, every key as a diamond you can grab and slide. Timing edits without redoing poses.
- Squash the hang-time: pull the "top" keys closer to the landings so the ball spends longer rising slowly and falls FAST.
- Open the Graph Editor: your Z-location drawn as a curve over time. Those curve SHAPES are the feel.
- Select the landing keys ? the curve should hit the floor STEEP (fast impact). Select handles and sharpen them (V ? Vector).
- The peaks should be ROUND (slow hang time), V ? Auto Clamped keeps them smooth.
- One more trick: select all keys of the last bounce, press T ? try Bounce easing. Blender has physics-flavoured presets!
- Play it now. THAT is a bounce. Same keys, only curves changed.
- Open character-rigged.blend. Pose Mode. Frame 1: relaxed pose, select ALL bones (A), key with I ? Rotation.
- Frame 12: raise the arm (shoulder + elbow), key JUST those bones.
- Frames 18 / 24 / 30: wrist tilts out / in / out, key each. Frame 40: back to relaxed, key all.
- Layer polish: tilt the HEAD slightly toward the wave around frame 14 (key it). Tiny secondary motion = huge charm.
- Loop playback and shorten/lengthen gaps in the dope sheet until the wave feels eager (fast up) and friendly (loose wrist).
- A walk cycle is four repeating poses: Contact (legs scissored, heel strikes), Down (weight lands, body lowest), Pass (legs together, body highest), Up (push off).
- Frame 1: Contact, left leg forward, RIGHT ARM forward (opposites!). Key all bones.
- Frame 7: Down. Frame 13: Pass. Frame 19: Up. Frame 25: Contact again but MIRRORED (right leg forward).
- The mirror pose is free: in the dope sheet copy frame 1-s keys (Ctrl+C), go to frame 25, paste FLIPPED (Ctrl+Shift+V), the .L/.R names from Episode 3 pay off!
- Set the scene end to frame 48 (two steps), enable looping, play. Tune hip height dips in the graph editor. You are animating!
- Frame the shot: camera slightly low, character walking "on the spot" centre-frame (cycles animate in place, sliding the world under them comes later in your journey).
- Light it with your Episode 1 skills: key sun + fill.
- Output Properties: resolution 1280×720 is plenty; format FFmpeg Video, encoding MPEG-4. Set an output folder!
- Render ? Render Animation (Ctrl+F12). Every frame renders, a 48-frame clip takes a few minutes in Eevee.
- Find the .mp4 and watch YOUR character walk. Save the .blend, Episode 5 makes everything beautiful.


--------------------------------------------------------------------
BONUS: BLENDER PYTHON BUILDER
--------------------------------------------------------------------
This pack also includes build_animation.py, a script that builds a "Character Animation" setup for you.

How to run it:
1. Open Blender 4.x.
2. Go to the Scripting tab, click Open, and choose build_animation.py.
3. Click Run Script (the play button). The model appears in your scene.
4. Press F12 to render, or keep building on top of it.
