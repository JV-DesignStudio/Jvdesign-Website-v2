# build_animation.py - Blender 4.x
# My First 3D Model Ep 4: Character Animation
import bpy

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

bpy.ops.mesh.primitive_uv_sphere_add(radius=0.6, location=(0, 0, 1))
ball = bpy.context.active_object
ball.name = "BouncingBall"

bpy.ops.object.light_add(type='SUN', location=(4, -4, 8))
bpy.context.active_object.data.energy = 3.0
bpy.ops.object.camera_add(location=(5, -5, 3), rotation=(1.15, 0, 0.78))
bpy.context.scene.camera = bpy.context.active_object

scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end = 60

# Keyframes: up, down, up (a simple bounce loop)
for frame, z in [(1, 1.0), (30, 2.4), (60, 1.0)]:
    ball.location = (0, 0, z)
    ball.keyframe_insert(data_path="location", frame=frame)

# Make the loop smooth
for fc in ball.animation_data.action.fcurves:
    for kp in fc.keyframe_points:
        kp.interpolation = 'BEZIER'

print("Press Space to play the animation. Add more keyframes to make it yours!")
