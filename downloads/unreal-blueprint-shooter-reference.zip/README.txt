Unreal Blueprint Top-Down Shooter Learn Blueprints
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/unreal-blueprint-shooter.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Unreal Blueprint Top-Down Shooter Learn Blueprints

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 ACTOR - Blueprint Actor, The Event Graph
- A Blueprint is a visual script. Connect the Event BeginPlay output exec pin to the Print String input exec pin to confirm your engine is running.

## STEP 03 EVENT TICK - Event BeginPlay',x:20,y:30,w:155,rp:[{id:'r1',type:'exec',label:''}]}, {id:'n2',type:'func', title:'Print String',sub:'Hello Unreal!',x:215,y:30,w:160,lp:[{id:'l1',type:'exec',label:''}],rp:[{id:'r2',type:'exec',label:''}]}, ],[{f:'r1',t:'l1'}],[]), boxes:[ {t:'concept',tx:'The white arrow pins are exec wires they control the order nodes run. BeginPlay fires once at game start, then execution flows right along every connected exec wire.'}, {t:'ue',tx:'In UE5: right-click the Event Graph ? search "BeginPlay". Right-click again ? search "Print String". Then drag from the white arrow on BeginPlay to the white input arrow on Print String.'}, ], onApply(){G.on=true;sout('✅ Event BeginPlay → Print String connected. Engine running!');} }, {title:"Variables, MoveSpeed & Health",tag:"STEP 02 VARIABLES", intro:`Connect BeginPlay through Set MoveSpeed then Set Health. Then click the orange fields on each node to type the starting values.`, pz:mkPuzzle([ {id:'n1',type:'event',title:'Event BeginPlay',x:10,y:40,w:150,rp:[{id:'r1',type:'exec',label:''}]}, {id:'n2',type:'vset',title:'Set MoveSpeed',x:185,y:15,w:148, lp:[{id:'l2e',type:'exec',label:''},{id:'l2v',type:'float',label:'Value'}], rp:[{id:'r2',type:'exec',label:''}], vf:{hint:'Speed 100-1200 (e.g. 500)',val:''}}, {id:'n3',type:'vset',title:'Set Health',x:355,y:15,w:130, lp:[{id:'l3e',type:'exec',label:''},{id:'l3v',type:'int',label:'Value'}], rp:[{id:'r3',type:'exec',label:''}], vf:{hint:'Health 10-500 (e.g. 100)',val:''}}, ],[{f:'r1',t:'l2e'},{f:'r2',t:'l3e'}],[ {id:'n2',ok:v=>parseFloat(v)>=100&&parseFloat(v)parseInt(v)>=10&&parseInt(v)Float (green) = decimals. Integer (blue) = whole numbers. Bool (red) = true/false. Pin colour tells you the type instantly.'}, {t:'tip',tx:'Tick Instance Editable on a variable to make it appear in the Details panel per-placed Actor great for tuning values without opening the Blueprint.'}, ], onApply(v){ G.spd=(parseFloat(v['n2'])||500)/100;G.mhp=parseInt(v['n3'])||100;G.hp=G.mhp; G.player=true;document.getElementById('hudHealth').textContent=G.hp; sout('✅ MoveSpeed='+v['n2']+' Health='+v['n3']+
- Event Tick fires every frame and provides Delta Seconds. Connect Tick's exec to Add Movement Input, and Delta Seconds to a Multiply node so movement stays consistent at any frame rate.

## STEP 04, INPUT SETUP - Enhanced Input, Add Mapping Context
- UE5 Enhanced Input requires you to Add Mapping Context in BeginPlay. Connect BeginPlay ? Get Player Controller ? Add Mapping Context. Without this, no input fires.

## STEP 05 MOVEMENT - IA_Move Break & Add Movement
- IA_Move Triggered fires while WASD is held. Its Action Value is a Vector2D. Connect it to Break Vector2D, then X into one Add Movement Input (right) and Y into another (forward).

## STEP 06 MOUSE AIM - Get Hit Result Under Cursor Aim
- Cast a ray from the mouse cursor into the 3D world. Connect Event Tick ? Get Hit Result Under Cursor ? Branch (using bBlockingHit) ? Set Aim Location variable.

## STEP 07, LOOK AT - Find Look at Rotation Face Mouse
- Use Find Look at Rotation to get the rotation needed to face the aim point. Feed it through RInterp To for smoothness, then into Set Actor Rotation. Type an interp speed.

## STEP 08 BRANCH - Branch Check Fire Conditions
- Shooting needs ALL three: fire button held, timer ready, AND player alive. Connect three boolean variables into an AND Boolean, then into a Branch, then True into Fire Bullet.

## STEP 09 GATE - Gate Node Fire Rate Limiter
- A Gate blocks execution when closed. Connect IA_Shoot ? Gate ? Fire Bullet. After firing, a Delay node waits, then reopens the Gate. Type the fire rate in seconds.

## STEP 10, SPAWN ACTOR - Spawn Actor from Class Bullets
- Connect Fire Bullet event ? Spawn Actor from Class. Wire Bullet Class Ref into the Class pin and Get Actor Transform into Spawn Transform. Type the Blueprint name.

## STEP 11 PROJECTILE - Projectile Movement Bullet Speed
- In BP_Bullet's BeginPlay, connect Set Initial Speed then Set Life Span. Type the bullet speed and lifetime values in the orange fields.

## STEP 12 OVERLAP - On Actor Begin Overlap Hit Detection
- In BP_Bullet, when it touches an enemy On Actor Begin Overlap fires. Connect it ? Cast to BP_Enemy ? on success, Apply Damage ? Destroy Actor. Type the damage amount.

## STEP 13 TAKE DAMAGE - Event Any Damage Receive Damage
- In BP_Enemy, Event Any Damage fires when hit. Connect it to subtract from Health, then a Branch on health = 0, then On Death Custom Event.

## STEP 14 CUSTOM EVENTS - Custom Events OnDeath Chain
- In BP_Enemy's On Death event, chain: Spawn Emitter ? Play Sound ? Grant Score ? Destroy Actor. Type the score per kill in the Grant Score node.

## STEP 15 ARRAYS - Arrays, Track Active Enemies
- Connect On Enemy Spawned ? Add to Array and On Enemy Died ? Remove from Array. Then wire Remove's exec output into Length to count remaining enemies.

## STEP 16 FOR EACH - For Each Loop Iterate Enemies
- Connect Event Tick ? For Each Loop (over Active Enemies) ? Cast to BP_Enemy on success ? Update Enemy AI. Loop Body fires once per enemy.

## STEP 17 SELECT - Select Node, Enemy Type Stats
- The Select node picks one value from many based on an index. Connect an EEnemyType enum variable into Select, and Select's result into Set Max Walk Speed. Type the Grunt speed.

## STEP 18 TIMER - Set Timer Wave Spawner
- Connect BeginPlay ? Set Timer by Function Name. The Function Name must exactly match your SpawnWave Custom Event. Type the wave interval in seconds.

## STEP 19 RANDOM SPAWN - Random Edge Spawn Position
- Inside SpawnWave, use Random Integer in Range (0-3) wired into a Select (Vector) to pick a random arena edge position for each enemy spawn.

## STEP 20, CAST TO - Cast To, Get Typed References
- Cast To checks if an Actor is a specific Blueprint type. Connect Get Player Character ? Cast to BP_TopDownChar. On success connect Add Score, passing the typed reference as Target. Type the score amount.

## STEP 21, IS VALID - Is Valid, Safe Reference Checks
- Before using stored references, check they\'re still alive. Connect Stored Enemy Ref ? Is Valid ? Branch. True: use it. False: connect to Remove from Array to clean up.

## STEP 22 SEQUENCE - Sequence Node Run Multiple Chains
- A Sequence fires multiple exec outputs in order from one input. Connect On Death ? Sequence, then wire each output to: VFX, Grant Score, and Destroy Actor. Type the score.

## STEP 23 DASH - Dash Ability LaunchCharacter
- Connect IA_Dash (Started) ? Branch (dash ready?) ? Launch Character ? Delay. Type the dash distance and cooldown duration.

## STEP 24, WIDGET - Create Widget Show HUD
- In BP_GameMode BeginPlay, connect Create Widget ? Add to Viewport ? Set HUD Reference. Type the widget Blueprint class name in the Create Widget node.

## STEP 25 HUD UPDATE - Update HUD Health & Score
- Connect Update HUD ? Get HUD Ref ? Set Health Percent (Health · MaxHealth) and Set Score Text. Connect both nodes to the HUD Reference. Type the max health divisor.

## STEP 26 GAME MODE - Game Mode PlayerDied & Restart
- In BP_GameMode, connect Player Died ? Delay ? Restart Player. The Controller output from Player Died feeds into Restart Player's New Player pin. Type the death delay.

## STEP 27 INTERFACE - Blueprint Interface Interact
- A Blueprint Interface lets any Blueprint implement the same function. Connect IA_Interact ? Line Trace (find target) ? Does Implement Interface ? Interact call.

## STEP 28 SAVE GAME - Save Game High Score
- Connect On Player Death ? Create Save Game Object ? Set High Score (on save) ? Save Game to Slot. Type the save slot name.

## STEP 29 NIAGARA - Niagara VFX Death Explosion
- In On Death, connect ? Get Actor Location ? Spawn System at Location (Niagara). Also wire the enemy\'s colour variable into the Colour Param pin. Type the Niagara asset name.

## STEP 30 FINISH - Complete Blueprint Game!
- Connect Game Start → Sequence to enable all four systems. Then type READY in the confirm field. All 5 Blueprints are wired your shooter is complete!
