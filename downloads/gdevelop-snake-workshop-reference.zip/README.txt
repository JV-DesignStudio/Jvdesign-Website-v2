Snake , Build a Snake Game in GDevelop
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/gdevelop-snake-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Snake , Build a Snake Game in GDevelop

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Create the scene
- In GDevelop, open your project. Right-click "Main Scene" in the Project Manager and rename it to "Menu".
- Click "Add a new scene". Name it "Game".
- Add a "Sprite" object called "SnakeHead". Paint a 20x20 green square.
- Place it near the centre of the scene.

## Create a direction variable
- Open the Events Sheet. Create a scene variable called "Direction" with value "right" (text).
- Add an event: Condition "Key pressed: Up". Action: "Change variable Direction to "up".
- Repeat for Down → "down", Left → "left", Right → "right".
- Important: add a condition to prevent reversing. For the Up key event, add an extra condition: "Variable Direction is NOT "down". This stops the snake from going backwards!

## Move on a timer
- Add a scene variable "GridSize" = 20 (matches our square size).
- Add a "Repeat every X seconds" condition (under Timers). Set to 0.15 seconds.
- Inside that, add an event: Condition "Variable Direction = "right". Action: "Change X position of SnakeHead: Add GridSize".
- Repeat for all four directions: left (subtract X), up (subtract Y), down (add Y).

## Add the food
- Add a Sprite object called "Food". Paint a 20x20 red square.
- Place it somewhere on the scene.
- Add an event: Condition "At the beginning of the scene". Action: "Change the position of Food" to random X (0 to 780) and random Y (0 to 580). Use the "round to nearest" operator to snap to the grid.
- Add event: Condition "SnakeHead is colliding with Food". Actions: 1) "Change variable Score: Add 1". 2) "Change position of Food" to new random grid position.

## Track segment positions
- Create two scene arrays: "SegmentX" and "SegmentY" to store positions of each body segment.
- At the start of each move timer, add the head's current position to the front of both arrays.
- Add a Sprite object "SnakeBody" (20x20 green, slightly darker than head).
- Each frame, for each index in the arrays, create or position a SnakeBody instance at the stored X and Y.
- When the snake eats food, don't remove the last position from the arrays. This makes the snake grow!

## Wall collision
- Add event: Condition "SnakeHead X position < 0" OR "X position > 780" OR "Y position < 0" OR "Y position > 580".
- Action: "Change scene to Game Over" (create a "GameOver" scene with a "Game Over" text object).

## Self collision
- Add event: For each segment in the arrays, check if SnakeHead position equals any segment position.
- If it matches, change to Game Over scene.

## Show the score
- Add a "Text" object called "ScoreText". Set it to display "Score: 0". Place it in the top-left corner.
- Add event: Condition "Always". Action: "Change the text of ScoreText: Score".
- Create the "GameOver" scene. Add a Text object saying "Game Over!" and another saying "Press R to restart".
- In GameOver events, add: Condition "Key pressed: R". Action: "Change scene to Game".
- Click Play to test the game.
- Verify: snake moves on grid, food appears randomly, snake grows, score updates, game over works.
- Try to reach a score of 10!
