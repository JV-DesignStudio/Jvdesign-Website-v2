Lucky Crystal Block! Capstone Minecraft Mod with Fabric
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/minecraft-lucky-mod.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Lucky Crystal Block! Capstone Minecraft Mod with Fabric

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## The 5 random events

## Create the file
- Block breaks but nothing happens check ModBlocks.java registers it as new LuckyCrystalBlock(...), not new Block(...). The onBreak override only exists on your custom class.
- Everything happens twice you're missing the if (!world.isClient()) guard. Add it back wrapping the switch statement.
- Cannot cast World to ServerWorld the cast is safe because we already checked !isClient(). If IntelliJ warns, you can add @SuppressWarnings("unchecked") above the line.
- Method not found errors the 5 event methods must all be inside the LuckyCrystalBlock class (before its closing } but after the closing } of onBreak).

## Add to ModBlocks.java

## Add to ModItems.java, registerModItems()

## Add language entry

## Texture

## Blockstate JSON

## Block model JSON

## Item model JSON

## Loot table, drops nothing (events are the reward!)

## Update the pickaxe mining tag

## Build and run
- In IntelliJ: Gradle → Tasks → fabric → runClient
- Create a Creative world
- Open inventory → search for "Lucky Crystal Block"
- Place the block and break it with your Crystal Pickaxe
- Watch for the chat message, it tells you which event fired!
- Try to get all 5 events!
