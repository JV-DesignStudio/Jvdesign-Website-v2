pico-8 cartridge // http://www.pico-8.com
version 41
__lua__
-- shooter.p8  JVDesignStudio
function _init()
  px=64 py=100 spd=2
  bullets={}
  enemies={}
  score=0
  lives=3
  spawn_timer=0
  game_over=false
end

function spawn_enemy()
  add(enemies,{x=rnd(120)+4,y=-4,spd=0.5+rnd(1)})
end

function _update()
  if game_over then
    if btnp(4) then _init() end
    return
  end
  if btn(0) then px=px-spd end
  if btn(1) then px=px+spd end
  if btn(2) then py=py-spd end
  if btn(3) then py=py+spd end
  px=mid(4,px,124)
  py=mid(4,py,124)
  if btnp(4) then
    add(bullets,{x=px,y=py-6})
    sfx(0)
  end
  for b in all(bullets) do
    b.y=b.y-4
    if b.y<-4 then del(bullets,b) end
  end
  spawn_timer=spawn_timer+1
  if spawn_timer>30 then
    spawn_timer=0
    spawn_enemy()
  end
  for e in all(enemies) do
    e.y=e.y+e.spd
    if e.y>132 then del(enemies,e) end
    if abs(e.x-px)<6 and abs(e.y-py)<6 then
      del(enemies,e)
      lives=lives-1
      if lives<=0 then game_over=true end
    end
  end
  for b in all(bullets) do
    for e in all(enemies) do
      if abs(b.x-e.x)<6 and abs(b.y-e.y)<6 then
        del(bullets,b)
        del(enemies,e)
        score=score+10
        sfx(1)
      end
    end
  end
end

function _draw()
  cls(0)
  for i=0,30 do
    pset((i*37)%128,(i*53)%128,1)
  end
  circfill(px,py,4,12)
  tri(px,py-6,px-4,py+2,px+4,py+2,7)
  for b in all(bullets) do
    rectfill(b.x-1,b.y-2,b.x+1,b.y+2,10)
  end
  for e in all(enemies) do
    circfill(e.x,e.y,4,8)
  end
  print("score "..score,2,2,7)
  for i=1,lives do
    circfill(6+i*8,4,2,12)
  end
  if game_over then
    print("game over",38,58,8)
    print("press z",48,68,6)
  end
end
