// ===== Part 1 of 6 (as shown in the lesson) =====
int p1Y = 205, p2Y = 205;
    boolean wHeld, sHeld, upHeld, downHeld;

    void update() {
        if (wHeld)    p1Y -= 6;
        if (sHeld)    p1Y += 6;
        if (upHeld)   p2Y -= 6;
        if (downHeld) p2Y += 6;
        p1Y = Math.max(0, Math.min(410, p1Y));
        p2Y = Math.max(0, Math.min(410, p2Y));
    }

    // centre line in paintComponent:
    for (int y = 0; y < 500; y += 24)
        g.fillRect(397, y, 6, 14);

// ===== Part 2 of 6 (as shown in the lesson) =====
int bx = 393, by = 243, bs = 14;
    int bvx = 5, bvy = 3;

    void serve(int direction) {
        bx = 393; by = 243;
        bvx = 5 * direction;
        bvy = Math.random() < 0.5 ? 3 : -3;
    }

    void update() {
        bx += bvx;  by += bvy;
        if (by <= 0 || by + bs >= 500) bvy = -bvy;

        Rectangle ball = new Rectangle(bx, by, bs, bs);
        if (ball.intersects(new Rectangle(20, p1Y, 14, 90)) && bvx < 0) {
            bvx = -bvx + 1;                       // rally speeds up
            bvy = ((by + bs/2) - (p1Y + 45)) / 7; // spin
        }
        if (ball.intersects(new Rectangle(766, p2Y, 14, 90)) && bvx > 0) {
            bvx = -(bvx + 1);
            bvy = ((by + bs/2) - (p2Y + 45)) / 7;
        }
        bvx = Math.max(-12, Math.min(12, bvx));
    }

// ===== Part 3 of 6 (as shown in the lesson) =====
int score1 = 0, score2 = 0;
    boolean gameOver = false;

    void update() {
        if (gameOver) return;
        // ... movement ...
        if (bx < -20)  { score2++; serve(-1); }
        if (bx > 820)  { score1++; serve(1);  }
        if (score1 == 7 || score2 == 7) gameOver = true;
    }

    // paintComponent:
    g.setFont(new Font("Monospaced", Font.BOLD, 56));
    g.drawString("" + score1, 320, 70);
    g.drawString("" + score2, 450, 70);

// ===== Part 4 of 6 (as shown in the lesson) =====
boolean vsComputer = true;
    int aiSpeed = 5, deadZone = 12;

    void update() {
        // ...
        if (vsComputer) {
            int padCentre  = p2Y + 45;
            int ballCentre = by + bs/2;
            if (padCentre < ballCentre - deadZone) p2Y += aiSpeed;
            if (padCentre > ballCentre + deadZone) p2Y -= aiSpeed;
        } else {
            if (upHeld)   p2Y -= 6;
            if (downHeld) p2Y += 6;
        }
    }

// ===== Part 5 of 6 (as shown in the lesson) =====
String state = "MENU";

    void update() {
        if (!state.equals("PLAYING")) return;
        // ... all game code ...
        if (score1 == 7 || score2 == 7) state = "GAME_OVER";
    }

    public void keyPressed(KeyEvent e) {
        if (state.equals("MENU")) {
            if (e.getKeyChar() == '1') { vsComputer = true;  state = "PLAYING"; }
            if (e.getKeyChar() == '2') { vsComputer = false; state = "PLAYING"; }
        } else if (state.equals("GAME_OVER") && e.getKeyChar() == 'r') {
            score1 = 0; score2 = 0; serve(1);
            state = "MENU";
        }
        // ... held-key booleans ...
    }

// ===== Part 6 of 6 (as shown in the lesson) =====
int flash = 0;

    // when a point is scored:
    //   score2++; serve(-1); flash = 12;

    void update() {
        // ...
        if (flash > 0) flash--;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (flash > 0) {
            g.setColor(new Color(255, 255, 255, 40));
            g.fillRect(0, 0, 800, 500);
        }
        // ... everything else ...
    }