int bx = 393, by = 243, bs = 14;
    int bvx = 5, bvy = 3;

    void serve(int direction) {
        bx = 393; by = 243;
        bvx = 5 * direction;
        bvy = Math.random() < 0.5 ? 3 : -3;
    }

    void update() {
        bx += bvx;  by += bvy;
        if (by <= 0 || by + bs >= 500) bvy = -bvy;

        Rectangle ball = new Rectangle(bx, by, bs, bs);
        if (ball.intersects(new Rectangle(20, p1Y, 14, 90)) && bvx < 0) {
            bvx = -bvx + 1;                       // rally speeds up
            bvy = ((by + bs/2) - (p1Y + 45)) / 7; // spin
        }
        if (ball.intersects(new Rectangle(766, p2Y, 14, 90)) && bvx > 0) {
            bvx = -(bvx + 1);
            bvy = ((by + bs/2) - (p2Y + 45)) / 7;
        }
        bvx = Math.max(-12, Math.min(12, bvx));
    }