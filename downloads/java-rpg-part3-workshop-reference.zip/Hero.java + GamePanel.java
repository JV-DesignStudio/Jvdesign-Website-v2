// Hero:
public boolean hasItem(String itemName) {
    for (Item it : inventory)
        if (it.name.equals(itemName)) return true;
    return false;
}

// GamePanel.walkable():
if (map[r][c] == 5)
    return hero.hasItem("Dragon Key");

// after moving onto the gate tile:
if (map[heroRow][heroCol] == 5) {
    hero.useItem("Dragon Key");      // consumed!
    map[heroRow][heroCol] = 0;
}