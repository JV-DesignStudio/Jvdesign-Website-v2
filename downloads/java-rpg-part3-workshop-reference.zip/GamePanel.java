// ===== Part 1 of 3 (as shown in the lesson) =====
int npcRow = 2, npcCol = 3;
    String[] dialogue = {
        "Elder: Ah, " + "Aria" + "... the Dragon stirs again.",
        "Elder: Its gate only opens to the DRAGON KEY.",
        "Elder: Three goblins guard its pieces. Slay them.",
        "Elder: Return victorious, and the realm is saved!"
    };
    int dialogueLine = 0;

    boolean nextToNpc() {
        return Math.abs(heroRow - npcRow)
             + Math.abs(heroCol - npcCol) == 1;
    }

    // in keyPressed (EXPLORE):
    if (e.getKeyChar() == 'e' && nextToNpc()) {
        state = "DIALOGUE";
        dialogueLine = 0;
    }
    // in keyPressed (DIALOGUE):
    if (e.getKeyChar() == 'e') {
        dialogueLine++;
        if (dialogueLine >= dialogue.length) state = "EXPLORE";
    }

// ===== Part 2 of 3 (as shown in the lesson) =====
boolean questActive = false;
    int goblinsSlain = 0;

    // when a monster dies in battleAction:
    if (!foe.isAlive()) {
        hero.gainXp(foe.xpReward);
        hero.addGold(foe.goldReward);
        if (questActive && foe.name.equals("Goblin"))
            goblinsSlain++;
        state = "EXPLORE";
    }

    // choosing what the Elder says:
    String[] currentDialogue() {
        if (!questActive)          return dialogue;        // gives quest
        if (goblinsSlain < 3)      return new String[]{
            "Elder: " + goblinsSlain + " of 3 goblins slain. Fight on!" };
        return new String[]{
            "Elder: Incredible! Take the DRAGON KEY.",
            "Elder: The gate in the north-east awaits. Good luck, hero." };
    }

// ===== Part 3 of 3 (as shown in the lesson) =====
boolean enraged = false;

    // stepping on tile 6:
    if (map[heroRow][heroCol] == 6) {
        foe = new Monster("Dragon", 80, 9, 100, 150);
        enraged = false;
        state = "BATTLE";
    }

    // in battleAction, after damaging the boss:
    if (foe.name.equals("Dragon") && !enraged
            && foe.hp <= foe.maxHp / 2) {
        enraged = true;
        foe.attack += 4;
        battleLog = "The Dragon is ENRAGED!";
    }