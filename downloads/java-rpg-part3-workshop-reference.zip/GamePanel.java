boolean questActive = false;
    int goblinsSlain = 0;

    // when a monster dies in battleAction:
    if (!foe.isAlive()) {
        hero.gainXp(foe.xpReward);
        hero.addGold(foe.goldReward);
        if (questActive && foe.name.equals("Goblin"))
            goblinsSlain++;
        state = "EXPLORE";
    }

    // choosing what the Elder says:
    String[] currentDialogue() {
        if (!questActive)          return dialogue;        // gives quest
        if (goblinsSlain < 3)      return new String[]{
            "Elder: " + goblinsSlain + " of 3 goblins slain. Fight on!" };
        return new String[]{
            "Elder: Incredible! Take the DRAGON KEY.",
            "Elder: The gate in the north-east awaits. Good luck, hero." };
    }