Fairy Tale Cottage Builder
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/fairy-tale-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Fairy Tale Cottage Builder

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 , IDENTITY - Name Your Cottage
- Every fairy tale cottage needs a name. Rose Cottage. Whispering Willows. The Mushroom Rest. What will yours be called? A good name sets the mood for everything that follows.

## STEP 02 , COLOUR - House Colour
- The main body colour of your cottage. Warm timber tones feel cosy. Whitewash feels Mediterranean. Pastel colours feel magical. Choose a colour that tells a story.

## STEP 03 , ROOF - Roof Style
- The roof defines your cottage's character. A pitched roof is classic and practical. A round dome feels like a hobbit house. Thatch is ancient and charming.

## STEP 04 , CONTRAST - Roof Colour
- Choose a colour for your roof. Traditional red tiles feel Mediterranean. Dark slate feels English. Natural thatch has its own golden-brown beauty.

## STEP 05 , PROPORTIONS - Roof Height
- How tall should your roof be? A low roof keeps things compact and cosy. A tall roof adds drama and grandeur. The right height depends on the story you're telling.

## STEP 06 , WARMTH - Chimney
- A chimney means a fireplace inside , warmth, light, and the smell of wood smoke. Set its height and whether smoke curls from the top. This is the heart of a cosy cottage.

## STEP 07 , ENTRANCE - Door Style
- The door is the first thing visitors see. An arch door is classic and elegant. A round door feels like a hobbit house. Double doors say "grand entrance."

## STEP 08 , LIGHT - Windows
- Windows let light in and views out. Choose how many you want and what style. Arched windows feel storybook. Round windows feel nautical. Square windows feel practical.

## STEP 09 , TOWERS - Towers
- Add cylindrical towers with conical roofs to your cottage. Towers make it feel like a tiny castle or a wizard's retreat. Each tower has its own window.

## STEP 10 , NATURE - Garden
- Surround your cottage with a garden. Adjust the size, add flowers, and scatter mushrooms. A garden brings life and colour to any fairy tale home.

## STEP 11 , BOUNDARY - Fence
- Add a rustic wooden fence around your garden. It marks the edge of your cottage's world and keeps the fairy tale creatures inside (or out).

## STEP 12 , JOURNEY - Path Style
- A path leads from the door to the garden gate. Stone is classic. Cobble is rustic. Dirt is natural and simple. The path invites visitors to your cottage.

## STEP 13 , GLOW - Lanterns & Lights
- Place lanterns along the garden path and add fairy lights to the roofline. These will glow warmly when you activate the cottage in the final step.

## STEP 14 , DETAILS - Trees & Mushroom House
- Add trees to frame your cottage and optionally a tiny mushroom house for the fairies. These finishing touches bring your scene to life.

## STEP 15 , OVERVIEW - Stats & Preview
- Take a moment to admire your cottage. The stats overlay shows how cosy, whimsical, natural, and crafty your creation is. Orbit around and appreciate every detail.

## STEP 16 , ENCHANTMENT - Light the Lanterns!
- The sun is setting. It's time to light the lanterns, watch the fairy lights glow, and see fireflies dance around your cottage. Welcome home.
