MUGEN Workshop Build Your Own Fighter
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/mugen-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: MUGEN Workshop Build Your Own Fighter

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- MUGEN Workshop Build Your Own Fighter | JVDesignStudio Skip to main content JVDesignStudio Start Here Workshops Tools Play Read For Parents 🛡️ More ▾ Imagine Improve Pick Your Path Dev Log For Parents About the Studio Downloads Search ☰ 🥊 My First Fighting Game · Episode 2 of 5 · See All Episodes JVDesignStudio · MUGEN Workshop Build Your Own Fighter From Scratch A complete free course for creating original MUGEN characters and custom stages. Draw sprites, write code, build a stage, design sound effects, customise screen packs, and put it all into a playable fighting game. MUGEN 1.0 / 1.1 Fighter Factory 3 🆓 Completely Free Ages 10+ ⚔ Start Learning 📥 Printable Extras .DEF mychar.defMaster config links every other file .SFF mychar.sffAll character sprites packed together .AIR mychar.airAnimation data which sprites play when .CMD mychar.cmdPlayer inputs and button combos .CNS mychar.cnsHealth, speed, hitboxes, move logic .SND mychar.sndSound effects (optional but great) ? New · Total Beginners Start Here Add Your Own Stage Beginner's Lesson Never touched MUGEN before? Start with this 45-minute walkthrough. 7 steps, a free starter pack (.def + placeholder art), and your first working stage running by the end. Start Lesson ? 🤖 Intermediate · Make Your Fighter Think MUGEN AI Workshop, Add CPU Intelligence to Your Character Learn how MUGEN's AI trigger system works. Add attack patterns, distance logic, difficulty scaling, and survival instincts. Free template and cheat sheet included. Start Workshop ? ⭐ 0 XP Level 1 🔥0 🖨️ Print Guide Your Progress 0 / 11 steps 💻How to run: Open WinMUGEN, press Start, and test your character! ⚔ Part 1, MUGEN BasicsFrom Zero to Playable Fighter 1 🥊 What is MUGEN? Understand the engine and what tools you need Current 🎯Goal for this stepUnderstand what MUGEN is and gather the four tools you need to start building. MUGEN is a free, customisable 2D fighting game engine created by Elecbyte. It lets you build your own roster of fighters, stages, and screen packs all from scratch or downloaded from the community. The two most common versions are MUGEN 1.0 and MUGEN 1.1. Make sure your content matches your engine version. What you'll need to get started A sprite editor Aseprite, GraphicsGale (free), or Piskel (browser-based)
- A text editor Notepad++, VS Code, or even Notepad
- Fighter Factory 3 the standard tool for packing sprites and editing animations
- A copy of MUGEN 1.0 or 1.1

## Sprite rules
- Draw at a consistent resolution (e.g. 100x120 pixels per frame)
- Use a magenta background (#FF00FF) MUGEN makes this colour transparent
- Keep your character centred on a consistent axis point across all frames
- Name files logically: idle_01.png, walk_01.png, punch_01.png

## Minimum sprite set to get started
- Open Fighter Factory 3 and click File &rarr; New
- Go to the Sprites section and click Add to import your PNG files
- For each sprite, set the Group and Image number (Group 0 = Idle, 20 = Walk, 200 = Punch)
- Set the axis point for each sprite, click the crosshair tool and place it at the character's feet
- Save as yourcharacter.sff
- MUGEN/chars/mychar/mychar.def
- mychar.sff all your sprites
- mychar.air animation sequences
- mychar.cmd button commands
- mychar.cns stats and move logic
- Place your entire character folder inside MUGEN/chars/
- Open MUGEN/data/select.def in a text editor
- Find the [Characters] section and add your folder name on a new line: mychar
- Save select.def and launch mugen.exe
- Your character should appear on the select screen!

## Common issues
- Edit and pack sprites into .SFF files
- Create and preview animations (.AIR) in real-time
- Built-in editors for .DEF, .CMD, .CNS with syntax highlighting
- Import and manage sound effects (.SND)
- Set axis points visually
- Preview characters with hitboxes visible
- Open FF3 and click File &rarr; New to start a fresh .SFF project
- Go to the Sprites editor tab
- Click Add (or drag-and-drop) to import your PNG files
- For each sprite, set the Group and Image number in the panel
- Click the crosshair tool and click at the character's feet to set the axis
- Enable View &rarr; Show Guidelines to check alignment against the floor line
- Save with File &rarr; Save As &rarr; name it mychar.sff
- Switch to the Animations editor tab
- Right-click the action list &rarr; Add &rarr; set the action number (e.g. 0 for idle)
- Click Add Frame &rarr; pick sprites from your .SFF list
- Set the Ticks field for each frame (6-8 ticks = smooth, 1 tick = 60fps)
- Hit Play or press Space to preview
- Use Clsn2 Default to set one hurtbox for an entire animation
- Add Clsn1 boxes only on the frames where the attack is active
- Toggle Show Clsn in the preview to visually verify your boxes
- Switch to the Sounds editor tab
- Click Add and import WAV files
- Set Group and Sound numbers (see table below)
- Click Play to preview each sound
- File &rarr; Save As &rarr; name it mychar.snd

## Dark Dungeon Arena
- .DEF file stage config defining layers, camera, music
- .SFF file all background images packed together
- Background art your layer images (PNG or PCX)
- .SND (optional) background music or ambient sound
- Create MUGEN/stages/dungeon/ and place dungeon.def and dungeon.sff inside
- Open MUGEN/data/select.def and find [ExtraStages]
- Add a new line: stages/dungeon/dungeon.def
- Save and run mugen.exe, your stage appears in VS mode stage select
- Move characters left and right to test the parallax scrolling

## Customise Your MUGEN's Look
- The title screen your game's logo, menu options, background art
- The select screen character grid, portraits, cursor, stage selector
- The VS screen face-off display before a fight starts
- The fight HUD, life bars, power meter, timer, combo counter (controlled by fight.def)
- Back up your entire MUGEN/data/ folder somewhere safe
- Download a screen pack from mugenarchive.com, mugenfreeforall.com, or deviantart
- Extract the ZIP you'll get system.def, system.sff, system.snd, fight.def, fight.sff, fight.snd
- Copy the new files into MUGEN/data/, replacing the existing ones
- Check mugen.cfg make sure motif = data/system.def points to the right place
- Launch mugen.exe you should see the new title screen!
- Change menu.pos to move the menu around the screen
- Adjust columns/rows to fit your roster size
- Rename menu.itemname entries to anything you want
- Swap graphics by opening system.sff in Fighter Factory 3 and replacing sprites
- Start by modifying someone else's pack don't build from scratch yet
- Match your resolution 320·240 packs look broken on 640·480 MUGEN and vice versa
- Test after every single change screen pack editing is trial and error
- Custom fonts are .fnt files the Font Factory tool lets you create them from any TrueType font

## Make Your Fighter Sound Great
- Impact SFX punch hits, kick connects, blocks. These give attacks weight. A weak punch needs a different sound than a heavy one.
- Voice Lines grunts, attack shouts, win quotes. These give your fighter personality. Even a simple grunt makes a difference.
- Move Effects whooshes, energy charges, explosions. These make special moves feel powerful.
- Audacity free audio editor. Record, cut, layer, and export sounds. This is your main workshop tool. Download at audacityteam.org
- Freesound.org free sound library with thousands of CC-licensed effects. Search for "punch", "sword swing", "grunt", "explosion"
- Fighter Factory 3 pack your WAV files into a .SND file. You already know this tool.
- Record or import click the red Record button for voice, or File ? Import for downloaded WAVs
- Trim the silence select empty space before/after and press Delete. Impact sounds should be 0.1-0.3 seconds
- Normalise select all (Ctrl+A) ? Effect ? Normalize. Makes all sounds a consistent loudness
- Add punch try Effect ? Bass Boost for heavier impacts, Effect ? Reverb for echo, Effect ? Change Pitch to deepen voices
- Layer sounds import a "whoosh" and a "thud" on separate tracks. They play together = one satisfying hit
- Export File ? Export ? Export as WAV. MUGEN needs WAV format
- Open Fighter Factory 3, switch to the Sounds editor tab
- Click Add and import all your WAV files
- Set Group 0 for impacts, Group 1 for voice, Group 2+ for effects
- Number each sound within its group (0, 1, 2, 3·)
- Preview each sound with the Play button
- File ? Save As ? mychar.snd
- Update your .DEF file: sound = mychar.snd
- Record 3 voice sounds: a quick grunt, a shout, and a win celebration
- Find 3 impact sounds on Freesound.org: a light hit, a heavy hit, and a block
- Trim, normalise, and export all 6 as WAV
- Pack into .SND in Fighter Factory 3
- Add at least 2 PlaySnd controllers to your .CNS
- Test in MUGEN do they play at the right moments?

## Printable Extras for Parents & Teachers

## Make It Yours

## Explore

## For Parents

## Socials
