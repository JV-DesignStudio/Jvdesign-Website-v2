Pet Clicker! Build a Simulator in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-simulator-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Pet Clicker! Build a Simulator in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------
- Open Roblox Studio → Baseplate template. In Explorer, click Baseplate and set its BrickColor to Bright green and Material to Grass.
- Add a large Part (size 40, 1, 40) as a central plaza BrickColor Institutional white, Material SmoothPlastic. Position it in the middle.
- Add a SpawnLocation on the plaza.
- Add some decorative trees: tall thin cylinders (trunks) with green spheres on top (leaves). Group each as Tree.
- Add a sky: in Explorer find Lighting → right-click → Insert Object → Sky. Pick any sky preset you like!
- In ServerScriptService, right-click → Insert Object → Script. Name it PlayerSetup. Paste:

## Build the coin
- Add a Part. Right-click it → Insert Object → SpecialMesh. Set MeshType to Cylinder. Resize the part to 0.5, 3, 3 a flat coin shape.
- Set BrickColor to Bright yellow, Material to Neon. Set Anchored to true. Name it CoinClick. Place it on the plaza.
- Right-click CoinClick → Insert Object → ClickDetector. This makes it clickable!
- Right-click CoinClick → Insert Object → Script. Paste:

## Make the egg shape
- Add a Part. Right-click → Insert Object → SpecialMesh. Set MeshType to Sphere. Resize the part to 4, 5, 4 for an egg shape.
- BrickColor: Pastel blue, Material: SmoothPlastic. Name it Egg. Set Anchored = true. Place it near the plaza.
- Add a BillboardGui to Egg with a TextLabel that says 🥚 Hatch! Cost: 10 Coins. (StudsOffset 0, 4, 0)
- Right-click Egg → Insert Object → ClickDetector.
- Right-click Egg → Insert Object → Script. Paste:

## Update the egg script
- Replace the egg script with this expanded version that spawns a following pet:
- In StarterGui, add a ScreenGui → name it HUD.
- Add a Frame inside HUD. Set Size to {0, 200}, {0, 60}. Position: {0.5, -100}, {0, 10} (top centre). BackgroundColor3: dark blue (0,0,0.2). BackgroundTransparency: 0.3. UICorner: add UICorner with CornerRadius 0.3.
- Add a TextLabel inside the Frame. Size {1,0},{1,0}. Text: 🪙 0 Coins. TextScaled: true. Font: GothamBold. BackgroundTransparency: 1. TextColor: white.
- Add a LocalScript inside HUD:
- Add a Part, size 6, 0.5, 6, BrickColor Bright violet, Material Neon. Name it UpgradePad. Anchored = true. Place it near the coin.
- Add a BillboardGui with TextLabel: ⬆️ 2x Click! Cost: 50.
- Add a ClickDetector to UpgradePad.
- Add a Script inside UpgradePad:
- Now update the CoinClick script so clicks use the multiplier: change += 1 to += (player:GetAttribute("ClickMultiplier") or 1).
- In ReplicatedStorage, right-click → Insert Object → BillboardGui. Name it CoinPop. Set Size {0,80},{0,40}. Add a TextLabel inside: Text +1, TextScaled true, Font GothamBold, TextColor yellow, BackgroundTransparency 1.
- Add a LocalScript inside the CoinClick part (alongside the existing Script), LocalScripts run on the player's screen for visual effects:
- Replace the PlayerSetup script with this saving version:
- In Lighting (Explorer), set Brightness to 2, Ambient to a warm colour. Add a ColorCorrection effect with Saturation 0.2 for a vibrant look.
- Add a SurfaceAppearance to the ground (Insert Object → SurfaceAppearance) and choose a grass texture.
- Add more clickable coins in different spots each one earns coins. Make some float in the air!
- Add more egg types a Golden Egg that costs 100 coins but has rarer pets!
- Add a welcome sign using a Part with a SurfaceGui containing a TextLabel.
- Press Play. Click the coin to earn coins, hatch a pet, buy the upgrade.
- Check the coin GUI updates correctly.
- Check pet follows you around.
- Press Stop, then File → Publish to Roblox. Set Privacy to Public.
- Share the link!
