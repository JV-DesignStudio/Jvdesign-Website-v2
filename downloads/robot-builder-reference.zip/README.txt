Robot Builder Design Your Own Robot
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/robot-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Robot Builder Design Your Own Robot

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 · IDENTITY - Name Your Robot
- Every robot needs a name. R2-D2. WALL-E. Atlas. Optimus. A good name tells you something about what your robot does or how it behaves.

## STEP 02 · HEAD UNIT - Head Shape
- The head houses the sensors and "brain". A Dome looks friendly and classic. A Visor gives a sleek glowing eye-strip. A Box Head looks industrial. Round gives a smooth android look.

## STEP 03 · CHASSIS - Body Type
- The torso houses the power core and main processors. Standard is a balanced box shape. Barrel is round and bulky like an industrial bot. Slim is narrow and agile.

## STEP 04 · SCALE - Body Height
- How tall is your robot? Compact robots are nimble and good at squeezing into small spaces. Standard is balanced. Heavy robots are intimidating, slow, and built for power.

## STEP 05 · LIVERY - Chassis Colour
- The main body colour. Greyand whiteare classic robotic colours, but your robot can be any colour you like. This will be the main colour on the torso, legs and arms.

## STEP 06 · CONTRAST - Accent Colour
- The accent colour appears on the shoulders, knees, hands and joints. A contrasting colour makes the robot look more designed and helps the moving parts stand out.

## STEP 07 · OPTICS - Eye / Visor Glow
- Choose the glow colour for your robot's eyes (and visor, if you picked one). Blue feels calm and helpful. Red feels aggressive. Green and purple feel more alien or futuristic.

## STEP 08 · MANIPULATORS - Arm Style
- What do the hands look like? Standard hands are simple and rounded good for general tasks. Claw Hands are mechanical pincers, great for gripping. Blaster Arms swap the hand for a built-in weapon.

## STEP 09 · LOCOMOTION - Leg Style
- How does your robot move? Biped legs walk like a human great for stairs and rough ground. Tank Treads are stable and powerful but can't climb steps. Hover thrusters let it float above the ground entirely.

## STEP 10 · COMMS - Antenna
- Add an antenna to the top of the head a classic robot communications array, used for sending and receiving radio signals.

## STEP 11 · PROTECTION - Shoulder Armor
- Add chunky armour plates over the shoulders. They protect the shoulder joints the most vulnerable part of any robot arm and give a bulkier, tougher silhouette.

## STEP 12 · UTILITY - Backpack
- Choose a backpack module. A Jetpack adds twin thrusters with a glowing exhaust for extra mobility. A Cargo Pod gives your robot a storage container for carrying equipment. Or leave the back clear.

## STEP 13 · POWER CORE - Chest Reactor
- Add a glowing reactor panel to the chest a power core that lights up in your eye-glow colour. It's the classic "heart" of a robot.

## STEP 14 · ARMAMENT - Weapon
- Equip a weapon. A Blaster attaches to the right arm with a glowing muzzle. A Sword is a long blade for melee combat. A Shield protects the left arm. Or stay unarmed.

## STEP 15 · MARKINGS - Stripe Decal
- Add a stripe band around the torso a paint marking used to show a robot's faction, unit number, or just for style.

## STEP 16 · ACTIVATION - Power Up!
- All systems are ready. Hit the power button to bring your robot to life its eyes will glow brighter, the reactor will pulse, and it will start scanning the room.
