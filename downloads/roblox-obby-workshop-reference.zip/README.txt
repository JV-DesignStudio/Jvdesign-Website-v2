Don't Fall! Build an Obby in Roblox Studio
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/roblox-obby-workshop.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Don't Fall! Build an Obby in Roblox Studio

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Create your first place
- Open Roblox Studio from your desktop or Start menu.
- On the home screen, click the Baseplate template. A big flat green platform will appear.
- Look at the top. You'll see tabs like Home, Model, View. These are your tools.
- In the middle is the Viewport this is your game world. Click and drag to look around.
- On the right you'll see the Explorer panel. This shows everything in your game.

## Remove the baseplate
- In the Explorer panel on the right, find Workspace and click the arrow to expand it.
- Click on Baseplate to select it, then press Delete on your keyboard. The green floor disappears that's fine!
- Also click SpawnLocation in Explorer and press Delete. We'll add our own.

## Build a start platform
- Click the Model tab at the top, then click Part. A grey box appears in the world.
- With the part selected, look in the Properties panel (bottom right). Set Size to 20, 1, 20 to make a flat wide platform.
- Set Position to 0, 0, 0. This is your starting floor.
- Change the BrickColor to something bright try Bright blue or Lime green.
- Now go to Model → Spawn. A SpawnLocation tile appears. Move it onto your platform using the Move tool (press W to switch to it).

## Add stepping platforms
- Click Model → Part to add a new part.
- Set its Size to 6, 1, 6 and move it about 8 studs away from your start platform. Leave a gap!
- Give it a BrickColor you like.
- Repeat this 5 more times, spacing platforms out in a zigzag path. Make some close, some far apart.
- Make some platforms different sizes some tiny (4×1×4), some bigger (8×1×8). Tiny ones are harder to land on!
- In Explorer, click Workspace, then rename your parts by right-clicking them and choosing Rename. Call them Platform1, Platform2, etc.

## Build the lava floor
- Add a new Part. Set its size to 200, 1, 200 a massive flat slab.
- Set its Position Y to -10 so it sits below all your platforms.
- Set BrickColor to Bright red or Neon orange. This is your lava.
- In Properties, scroll down and find Material. Change it to Neon it will glow!
- Rename this part Lava in the Explorer.

## Make it kill players
- Click on your Lava part in Explorer. Right-click it and choose Insert Object → Script.
- A script editor opens. Delete everything inside and type this:
- Press Play (the big green Play button at the top) to test it. Walk your character off a platform you should fall into the lava and respawn!

## Add a moving platform part
- Add a new Part, size 8, 1, 8. Place it somewhere in the middle of your obby path. Colour it Bright yellow.
- Set Anchored to true in Properties (so gravity doesn't pull it down).
- Rename it MovingPlatform1.
- Right-click it in Explorer → Insert Object → Script.
- Delete everything in the script and paste this:
- Make a second moving platform in a different spot. Copy the same script but change the Vector3.new(20, 0, 0) to Vector3.new(0, 0, 20) so it moves forward/back instead.
- Press Play to see them move!

## Build the jump pad
- Add a new Part, size 6, 1, 6. Set Material to Neon and BrickColor to Cyan.
- Place it somewhere in your obby as a secret shortcut or fun extra. Rename it JumpPad.
- Right-click JumpPad → Insert Object → Script and paste:

## Build the finish area
- Add a new Part at the end of your obby. Size: 12, 1, 12. BrickColor: Bright green. Material: Neon.
- Add another part on top as a tall arch or flag pole get creative! Rename the floor part FinishLine.
- Right-click FinishLine → Insert Object → Script:

## Test your whole obby
- Press the Play button. Walk your character through the entire obby from start to finish.
- If any gaps are too big to jump, press Stop and adjust the platform positions.
- Check that lava kills you and you respawn correctly.
- Try the moving platforms and jump pads. Do they feel fun?
- Press Stop when you're happy.

## Save and publish
- Press File → Save to Roblox. Give your obby a name, like "Don't Fall Obby by [your name]".
- Press File → Publish to Roblox. Set Privacy to Public so anyone can play it.
- Visit your game's page on roblox.com and copy the link to share with friends and family!
- Navigating Roblox Studio: Viewport, Explorer, Properties and the Model tab
- Building with Parts: setting Size, Position, BrickColor and Anchored properties
- Writing Lua scripts with the Touched event to detect player contact
- Using TweenService to smoothly animate moving platforms between positions
- Creating kill bricks, jump pads with Velocity, and a finish checkpoint with victory messaging
