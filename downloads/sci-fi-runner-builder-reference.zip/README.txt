Build a Sci-Fi Endless Runner
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/sci-fi-runner-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Build a Sci-Fi Endless Runner

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Scroll Speed
- Everything in an endless runner scrolls downward. The player stays near the bottom the world moves toward them.\nScroll speed controls how fast obstacles approach. Higher = harder.

## Player Size
- Your ship is a triangle. Player size controls how big it is.\nBigger = easier to see, but harder to dodge between obstacles.\nSmaller = nimble, but easy to lose track of.

## Lane Count
- The runner uses a lane system, press left/right to switch lanes.\nMore lanes = more room to dodge.\nFewer lanes = tighter, harder.

## Obstacle Spawn Rate
- Spawn rate is how often a new obstacle appears.\nMeasured in frames between spawns lower = more frequent.\n50 = one every ~0.8 seconds. 20 = one every ~0.3 seconds.

## Lives
- Each time you hit an obstacle, you lose a life.\nWhen lives reach 0 game over.\nHow many chances should the player get?

## Shield Pickups
- ??? Shields spawn randomly and absorb one hit.\nThe shield chance is a percentage each spawn cycle rolls a dice to decide if a shield appears.

## Star Pickups
- ? Stars give +50 score each. They spawn in random lanes alongside obstacles.\nThe star chance controls how often they appear.\nStars create risk/reward sometimes they spawn in dangerous lanes.

## Difficulty Ramp
- The game gets harder over time. Speed ramp controls how fast it accelerates.\nEach frame, the speed increases by this tiny amount. Over hundreds of frames, it adds up.

## Fine-Tune Everything
- All your values in one place. Adjust everything until the game feels just right.\nThink about how they interact fast speed + dense spawns + few lives = brutal.

## Your Finished Runner!
- This is your game. Every number was your decision.\nNo two students build the same runner.\nPress Run My Game to play your final version!
