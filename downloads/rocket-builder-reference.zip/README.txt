Rocket Builder Design Your Own Launch Vehicle
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/rocket-builder.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Rocket Builder Design Your Own Launch Vehicle

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## STEP 01 · IDENTITY - Name Your Rocket
- Every rocket needs a name. NASA, SpaceX, ESAthey all name their launch vehicles. Saturn V. Falcon 9. Ariane 6. What will yours be called?

## STEP 02 · AERODYNAMICS - Nosecone Shape
- The nosecone cuts through the atmosphere. Different shapes work best at different speeds. Coneis classic. Ogiveis more aerodynamic. Bluntis used on crew capsules.

## STEP 03 · SCALE - Body Height
- How tallis your rocket? A small sounding rocket might be 8m. Saturn V was 111m. Taller rockets carry more fuel and reach higher orbits but need bigger engines.

## STEP 04 · GIRTH - Body Diameter
- A wider body holds more fuel, but creates more aerodynamic drag. Falcon 9's core is 3.7m wide. SLS is 8.4m. Your choice affects how the fins and boosters look attached.

## STEP 05 · LIVERY - Primary Colour
- The main body colour. Whitereflects sunlight and keeps fuel tanks cool. NASA's SLS is white. SpaceX's Falcon 9 is white. But your rocket can be any colour you want.

## STEP 06 · CONTRAST - Secondary Colour
- The secondary colour appears on the nosecone, fins, and engine bells. A contrasting colour makes your rocket look more designed and intentional.

## STEP 07 · STABILITY - Fin Style
- Fins keep the rocket flying straight. Without them, it would tumble. Different shapes give different handling characteristics and visual personality.

## STEP 08 · SYMMETRY - Fin Count
- 3 finsis the lightest and fastest option most model rockets use 3. 4 finsgives more stability and a more symmetrical look. Real rockets often use 4.

## STEP 09 · THRUST - Side Boosters
- Boostersare additional rockets strapped to the core. They provide extra thrust at launch and then separate. Falcon Heavy has 2 side boosters. SLS has 2 solid rocket boosters.

## STEP 10 · PROPORTIONS - Booster Size
- Set how large your boosters are relative to the main body. Smallboosters are strap-on solid rockets. Largeboosters are full liquid fuel cores like Falcon Heavy's.

## STEP 11 · POWER - Engine Count
- How many engines in the main core? 1 engineis simple and powerful. 3is like Falcon 9 (Merlin cluster). 5is raw cluster power.

## STEP 12 · PAYLOAD - Payload Fairing
- The payload fairingis the nose shell that protects cargo during ascent. It splits and falls away once above the atmosphere. Standard for satellites. XL for large space telescopes.

## STEP 13 · MARKINGS - Stripe Decal
- Add a colour stripearound the body a classic rocket marking used to break up large surfaces and identify different sections of the fuel tank.

## STEP 14 · CREW COMPARTMENT - Windows
- Add windowsto your rocket. Crew capsules and observation pods have portholes. Cargo rockets usually have none. Choose a style that matches your mission.

## STEP 15 · REUSABILITY - Landing Legs
- Add Falcon 9-style landing legsto your rocket. Reusable rockets fold out their legs just before touchdown and land propulsively. SpaceX changed everything with this.

## STEP 16 · EXHAUST - Engine Glow
- Choose the colour of your engine exhaust flame. Kerosene engines burn orange-yellow. Hydrogen engines burn nearly invisible blue-white. Ion drives glow blue-violet.

## STEP 17 · LIFTOFF - Launch!
- All systems are go.Your rocket is fully designed. Hit the launch button to ignite the engines and watch it lift off.
