Fidget Spinner
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/tinkercad-ep1-spinner.html

Offline reference pack for this workshop.
This is a companion copy of the build steps, so you can follow along without
the website. Open the workshop online for the interactive screenshots, videos
and the copy buttons.

What you build: Fidget Spinner

--------------------------------------------------------------------
STEP-BY-STEP BUILD
--------------------------------------------------------------------

## Get started
- Open a browser and go to tinkercad.com.
- Click "Join Now" in the top right corner. Choose a "Personal" account.
- Once logged in, click "Create" then "3D Design". A new empty workplane opens.
- You'll see a flat blue grid, this is the Workplane where you build.
- On the right side is the Shapes Panel, these are the building blocks for your design.
- My Fidget Spinner ✏️ Group · Align · Export TOP BASIC SHAPES Box Cylinder Roof Sphere 1 2 3 4 5 The TinkerCAD editor. ① Project name (click it to rename) · ② Export button (you'll use this at the end) · ③ ViewCube (click its faces to change view) · ④ Workplane, the blue grid where you build · ⑤ Shapes Panel, drag shapes from here. 💡Click the project name at the top left ("Untitled") and rename it to "My Fidget Spinner". ✏️ Fill in the Blanks +15 XP TinkerCAD runs in your so there's nothing to . ✏️ Check Answers 🧠 Knowledge Check +15 XP What is the Workplane in TinkerCAD? AThe panel where you find shapes BThe flat grid surface where you place and build your 3D objects CThe toolbar at the top of the screen Check Answer ✅ Correct! Next Step → 2 🎨 Explore the Workspace Learn camera controls, grid, and the shapes panel Locked 🎯 Goal for this stepBe comfortable navigating the 3D view, orbiting, zooming, and panning. Learn the controls Right-click and drag to orbit (rotate) the camera around the workplane.
- Scroll the mouse wheel to zoom in and out.
- Hold Shift + right-click and drag to pan (slide) the view.
- Click the "Home View" cube in the top left to reset the camera.
- Look at the bottom-left: the grid squares are 1mm each. The ruler shows dimensions.
- Try clicking a few shapes in the Shapes Panel on the right, but don't drag them yet!
- Orbit (spin around) hold the RIGHT button + drag Zoom in & out scroll the mouse wheel Shift + Pan (slide across) hold Shift + RIGHT drag The three camera moves. Practice each one until it feels natural, you'll use them constantly. On a laptop trackpad: two-finger drag orbits, pinch zooms. 💡The small cube in the top-left corner is called the ViewCube. Click its faces to snap to Front, Top, or Side views. ⚡ True or False? +15 XP "Right-click and drag" orbits the camera around your design. TrueFalse Each grid square on the workplane is 10mm. TrueFalse The ViewCube lets you snap to different camera angles. TrueFalse ⚡ Check All 🧠 Knowledge Check +15 XP How do you zoom in and out in TinkerCAD? APress the Z key BRight-click and drag CScroll the mouse wheel Check Answer ✅ Correct! Next Step → 3 🔵 Create the Central Hub Drag a cylinder onto the workplane as the center hub for the bearing Locked 🎯 Goal for this stepPlace a cylinder shape on the workplane. This will be the small central hub where the bearing goes. Add your first shape In the Shapes Panel on the right, find "Cylinder" under Basic Shapes.
- Click and drag the Cylinder onto the workplane. Drop it in the center.
- A cylinder appears on the grid. It has small white square handles for resizing.
- Click the cylinder to select it, you'll see dimension labels showing its size.
- The default size is about 20mm x 20mm x 20mm, we'll resize it in the next step to make it the central hub.

## Resize the cylinder
- Click the cylinder to select it. You'll see white square handles on the corners and edges.
- Look at the top, there's a small white square handle. Click and drag it downward to make the cylinder shorter.
- In the dimension box that appears, type 8 and press Enter. The height is now 8mm.
- Now grab a corner handle on the base. Hold Shift while dragging to resize both width and depth equally.
- Type 30 in the dimension box. The cylinder is now 30mm x 30mm x 8mm, a small flat disc (the hub)!
- Check your work: select the shape and verify the dimensions show 30 x 30 x 8.
- resize AFTER 8 30 mm 8 mm Don't drag by eye, type the numbers. Click a white handle and a small dimension box appears (like the "8" above). Type the exact number and press Enter. ✅Checkpoint: your cylinder should now look like a flat disc, much wider than it is tall, and clicking it should show 30 ✨ 30 ✨ 8 on the labels. If a number is wrong, click that handle and retype it. 💡The central body should be small so the arm weights stick out clearly. This creates a spinner that spins smoothly. ✏️ Fill in the Blanks +15 XP To make the spinner body (hub) properly sized, we set the height to mm and the width to mm. ✏️ Check Answers 🧠 Knowledge Check +15 XP Why do we keep the central body small (30mm, not 50mm)? AIt uses less plastic BSo the arm weights stick out clearly and the spinner has good balance and momentum CLarge bodies are harder to hold Check Answer ✅ Correct! Next Step → 5 💪 Add Spinner Arms Add 3 weight cylinders extending outward from the body Locked 🎯 Goal for this stepPlace 3 heavy cylinders that extend outward from the center to provide weight and balance for spinning. Create the first arm weight Drag a Cylinder from the Shapes Panel onto the workplane.
- Resize it to 16mm x 16mm x 8mm, this is a weight that will stick OUT from the body.
- Position this cylinder about 20mm away from the center of the body (measured centre to centre).
- Place it at the "12 o'clock" position, directly above the center, extending outward.
- Make sure it sits flat on the workplane at the same level as the body (height 0).
- The arm must overlap the edge of the body slightly (a few mm). When you group everything later, the overlap fuses them into one solid piece, a gap would make your printed spinner fall apart!
- 20 mm centre to centre the circles overlap so they fuse when grouped Line it up from above. Click "TOP" on the ViewCube so you're looking straight down, it's much easier to position the arm accurately. The arm's edge should clearly cross into the body, no gap and no daylight between them. 💡For a spinner to work, the heavy weights need to be far from the center while still overlapping the body. This creates better momentum when spinning. 🧠 Knowledge Check +15 XP Why should the arm weights be positioned far from the center? ASo they don't touch the center bearing BTo create better momentum and balance when spinning CTo make the spinner look bigger Check Answer ✅ Correct! Next Step → 6 🔄 Position Arms Evenly (120° Apart) Use rotation to space the arms perfectly around the center Locked 🎯 Goal for this stepDuplicate the arm and rotate copies to be evenly spaced at 120-degree intervals. Duplicate and rotate Select the arm cylinder you just created. Press Ctrl+D to Duplicate it.
- A copy appears on top of the original. Don't click anywhere else yet!
- You'll see a rotation handle, curved arrows around the shape. Click and drag to rotate.
- In the rotation box, type 120 and press Enter. The duplicate moves to the "4 o'clock" position.
- With the rotated copy still selected, press Ctrl+D again. TinkerCAD remembers the last action!
- The third arm automatically appears at 240°, the "8 o'clock" position. All three arms are evenly spaced!

## Create the hole
- Drag another Cylinder onto the workplane and resize it to 8mm x 8mm x 10mm (slightly taller than the spinner).
- Position it in the exact center of the spinner body.
- Use the Align tool: select both the hole cylinder and the main body, then click "Align" (L key) in the top toolbar.
- Click the center dots on both the X and Y axes, the hole cylinder snaps to the exact center.
- Now the key step: select the small cylinder and look at the top-right of the screen. Click "Hole", the shape turns translucent with stripes.
- The shape is now a "Hole", when grouped with other shapes, it will cut through them like a cookie cutter.
- VIEW FROM ABOVE stripes = it's now a Hole, dead centre (use Align) VIEW FROM THE SIDE 8 mm 10 mm the hole pokes out above AND below so it cuts all the way through What you should see: after clicking "Hole", the small cylinder turns grey with stripes. From the side (click a side face on the ViewCube) it should stick out slightly above and below the body. 💡Making the hole cylinder taller (10mm) than the spinner (8mm) ensures it cuts all the way through. If it's the same height, you might get a thin layer left at the bottom. ✏️ Fill in the Blanks +15 XP To cut a hole through a shape in TinkerCAD, first change the shape to a , then all shapes together. ✏️ Check Answers 🧠 Knowledge Check +15 XP Why do we make the hole cylinder 10mm tall when the spinner is only 8mm? ASo it looks taller than the spinner BTo ensure the hole cuts completely through, no thin layer left at top or bottom CBecause bearings are 10mm tall Check Answer ✅ Correct! Next Step → 8 🎯 Group Everything Together Combine all shapes into one solid design Locked 🎯 Goal for this stepGroup all shapes into one unified object and verify the design looks correct. Group and verify Press Ctrl+A to select all shapes on the workplane.
- You should see all shapes highlighted, the main body, 3 arms, and the center hole.
- Click "Group" in the top toolbar (or press Ctrl+G). All shapes merge into one!
- The hole cylinder cuts through the body, leaving a clean circular hole in the center.
- Rotate the view to check your design from all angles, it should look like a 3-armed spinner with a center hole.
- If something looks wrong, press Ctrl+Z to undo the grouping, fix the issue, then group again.
- the Hole cut a clean 8 mm circle no seams between body and arms, it's all ONE piece now What you should see: one solid shape in a single colour with a clean hole through the middle. Orbit around it (right-click + drag), it should look like this from every angle, just 8mm thick. ✅Checkpoint: if you can still click an arm and move it on its own, it didn't group. Select everything (Ctrl+A) and press Ctrl+G again. If the hole didn't appear, the small cylinder probably wasn't set to "Hole", undo, click it, choose Hole, and re-group. 💡After grouping, you can change the colour of the entire spinner by selecting it and choosing a colour from the Shape Properties panel. 🔢 Put It In Order +15 XP Put these in the correct order to group shapes: Click Group or press Ctrl+G Press Ctrl+A to select all shapes Check the design from all angles Verify all shapes are highlighted 🔍 Check Order↺ Reset 🧠 Knowledge Check +15 XP What happens to the "Hole" shape when you Group it with solid shapes? AIt disappears completely BIt becomes solid CIt cuts through the solid shapes, creating a hole Check Answer ✅ Correct! Next Step → 9 📤 Export as STL Download your design ready for 3D printing Locked 🎯 Goal for this stepExport your finished spinner as an STL file and understand basic 3D print settings. Export and print Click the "Export" button in the top-right corner of TinkerCAD.
- A dialog appears with format options. Choose "STL", this is the standard format for 3D printing.
- Click the download button. Your file saves as a .stl file.
- This STL file can be opened in any 3D printing software (called a "slicer") like Cura or PrusaSlicer.
- In the slicer, you'd set: Layer Height (0.2mm is standard), Infill (20% is fine for a spinner), and Material (PLA is easiest).
- The slicer converts your 3D model into instructions the printer can follow, layer by layer.
- Navigating the TinkerCAD workplane: orbit, zoom and pan with right-click and scroll
- Dragging basic shapes from the Shapes Panel and resizing with exact dimensions
- Positioning objects at precise distances and using the ViewCube for camera angles
- Grouping multiple shapes into a single solid object for 3D printing
- Exporting an STL file ready for 3D printing
