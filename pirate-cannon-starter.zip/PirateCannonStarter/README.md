# Pirate Cannon Forge - Starter Template

Free companion files for the **Pirate Cannon Forge** workshop:
https://jvdesignstudio.co.uk/workshops/pirate-cannon-builder.html

Nothing to install. Download the pack from the workshop (**📦 Starter Template**
in the title bar) and keep the files open beside the basic cannon while you work.

## What is inside

```
PirateCannonStarter/
  README.md                       this file
  CHECKLIST.md                    all 15 steps, ticked off in order
  reference/
    parameters.json               every slider with its range and a starting value
    reference-cannon.json         a finished basic cannon
```

## The basic basic cannon

`reference/reference-cannon.json` is one complete, working basic cannon: every value filled in.
To use it, open the file and copy each value into the matching control, in order:

1. Download the pack (**📦 Starter Template**).
2. Open `reference/parameters.json` or `reference/reference-cannon.json` in any text editor.
3. Work down the 15 steps. For each control, type the value into the basic forge.
4. Press **Save** so you have a copy you can reload later.

## The 15 values, in step order

- Workshop size: 4.0 m wide, 3.4 m deep, 3.0 m high
- Barrel length: 1.6 m, outer radius 0.18 m, bore 0.09 m, taper 0.22
- Muzzle ring: 0.045 thick, 0.06 wide, flare 0.075
- Cascabel: 0.085 knob radius, 0.05 neck radius
- Trunnions: 0.04 radius, 0.11 long
- Reinforce rings: 4 rings, 0.022 thick, vent hole 0.012
- Carriage: 1.15 long, 0.45 wide, 0.24 high, 12 degree elevation
- Wheels: 0.3 radius, 0.06 thick, 10 spokes, axle radius 0.03
- Materials: barrel #2f3640, carriage #7a4b23, wheels #4a3016, brass #c9a227, rope #d9b26a
- Details: rope on, quoin wedge on

## Why those values

`parameters.json` lists every control with the range the workshop allows, so you
can see where a slider is allowed to go. The starting values sit comfortably
inside every range, which makes them a safe first build to copy and then change.

## Recover from a bad experiment

- **Save** stores the cannon in this browser under a name you choose, **Load** brings it back, and each saved cannon can be deleted from the same list.
- The forge needs no account and never uploads anything, so this all works on a locked down school computer.

## Take your cannon further

- **⬇ Export OBJ** downloads a plain text 3D model of whatever you have built.
  It opens in Blender, Meshmixer or any 3D app that reads Wavefront OBJ.
- Once exported you can print the barrel length, the bore and the carriage
  angle as real numbers for a physical build.

## School computer notes

- No install, no account, no upload: files stay on the machine.
- The sliders are plain HTML, so a mouse or a trackpad is the only input needed.
- Text files open in Notepad, TextEdit or any code editor.
