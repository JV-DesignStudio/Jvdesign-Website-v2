# Checklist - Pirate Cannon Forge (15 steps)

Tick a step when its slider is set and the cannon looks the way you want.

## Get the space right (step 1)
- [ ] 1 Workshop Size: width, depth and height set

## Shape the barrel (steps 2-4)
- [ ] 2 Barrel Length set
- [ ] 3 Barrel Diameter: outer radius and bore set
- [ ] 4 Barrel Taper set

## Muzzle and breech (steps 5-7)
- [ ] 5 Muzzle Ring: thickness and width set
- [ ] 6 Muzzle Flare set
- [ ] 7 Cascabel: knob and neck radius set

## Mounting and bands (steps 8-10)
- [ ] 8 Trunnions: radius and length set
- [ ] 9 Reinforce Rings: count and thickness set
- [ ] 10 Vent / Touch Hole radius set

## Carriage and running gear (steps 11-13)
- [ ] 11 Gun Carriage: length, width, height and elevation set
- [ ] 12 Wheels: radius, thickness and spokes set
- [ ] 13 Axle Radius set

## Finish it (steps 14-15)
- [ ] 14 Materials and Color: barrel, carriage, wheel, metal and rope colours set
- [ ] 15 Final Details: rope and quoin wedge toggled

## Using the starter pack
- [ ] Loaded the reference cannon from the title bar
- [ ] Compared at least five of your sliders with parameters.json
- [ ] Saved your cannon to a name and loaded it back
- [ ] Exported your cannon as OBJ and opened the file
