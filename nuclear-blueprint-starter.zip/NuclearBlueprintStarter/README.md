# Nuclear Blueprint - Starter Template

Free companion files for the **Nuclear Blueprint** workshop:
https://jvdesignstudio.co.uk/workshops/nuclear-blueprint.html

Nothing to install. These files sit beside the workshop while you wire the
graphs, so you can check your values, see a finished run, and get back to a
known good build after an experiment goes wrong.

## What is inside

```
NuclearBlueprintStarter/
  README.md                        this file
  CHECKLIST.md                     all 37 steps, ticked off in order
  reference/
    build-values.json              every orange field with a value that passes its check
    reference-run.json             a finished run the workshop can load
    reference-run-link.txt         the same run as a one click link
```

## Way 1: open the reference run (30 seconds)

1. Unzip this folder and open `reference/reference-run-link.txt`.
2. Paste the link into a browser (or press **▶ Reference Run** in the
   workshop header, which is the same link).
3. The game loads World 2-3 with a named weapon (Nova Splinter), 140 HP, the
   damage and lifesteal mutations already chosen, and score 1250.

That is what a finished build looks like. Play it, then go back and make your
own.

## Way 2: check your values as you go

1. Open `reference/build-values.json` in any text editor.
2. Each entry has the step number, the field hint exactly as the page shows
   it, and a value that passes the page's own check.
3. Type the value into the orange field in the workshop and press Apply.

Values marked `null` are wiring only steps: there is no number to type, just
connect the pins in the order the checklist describes.

The reference weapon stores the game's internal speed (`bs`) as `12`, which the
weapon card reads as 1200 UU/s, the same number you type in step 11.

## Recover from a bad experiment

- **Save Run** stores your current run in this browser, **Load** brings it back.
- Re-import the reference any time by opening the link again.
- Checklist ticks and XP live in this browser only and are never uploaded.

## School computer notes

- No install, no account, no upload: files stay on the machine.
- The workshop runs offline once loaded, so the reference link works on a
  locked-down computer.
- Bring your own headphones: the game has sound (mute button in the header).
