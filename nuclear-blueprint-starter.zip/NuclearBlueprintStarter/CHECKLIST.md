# Checklist - Nuclear Blueprint (37 steps)

Tick a step when its graph is wired and Apply is pressed.

## Graph basics (steps 1-7)
- [ ] 1 Blueprint Actor Event Graph: Event BeginPlay to Print String
- [ ] 2 Variables: Set Health and Set MoveSpeed wired, values typed
- [ ] 3 Event Tick Delta Seconds wired
- [ ] 4 Enhanced Input Mapping Context added
- [ ] 5 IA_Move WASD Movement wired to Add Movement Input
- [ ] 6 Get Hit Under Cursor sets the aim point
- [ ] 7 Find Look at Rotation faces the mouse, rotation speed typed

## Your weapon (steps 8-15)
- [ ] 8 Bullet count set
- [ ] 9 Spread angle set
- [ ] 10 Fire rate set
- [ ] 11 Bullet speed set
- [ ] 12 Bullet damage set
- [ ] 13 Bounce modifier set to true or false
- [ ] 14 Explosive radius set
- [ ] 15 Spawn Actor from Class: BP_Bullet connected, Fire works

## Rooms and enemies (steps 16-24)
- [ ] 16 Room walls and obstacle collision, world template typed
- [ ] 17 Grunt HP, speed and damage set
- [ ] 18 Runner HP and speed set
- [ ] 19 Tank HP, speed and damage set
- [ ] 20 Shooter HP, fire rate and damage set
- [ ] 21 Overlap hit applies damage
- [ ] 22 Door opens when the room is clear
- [ ] 23 Room transition loads the next room
- [ ] 24 Chest gives a weapon pickup

## Mutations and perks (steps 25-32)
- [ ] 25 World end shows the weapon mutation card
- [ ] 26 World end shows the survivor perk card
- [ ] 27 Damage up multiplier set
- [ ] 28 Rapid fire multiplier set
- [ ] 29 More bullets amount set
- [ ] 30 Speed boost multiplier set
- [ ] 31 Shield recharge seconds set
- [ ] 32 Lifesteal HP per kill set

## Finishing (steps 33-37)
- [ ] 33 World scaling difficulty factor set
- [ ] 34 Boss HP multiplier set
- [ ] 35 HUD shows health, weapon and minimap
- [ ] 36 Death screen delay set and high score saved
- [ ] 37 Weapon named, launch it

## Using the starter
- [ ] Opened the reference run from reference-run-link.txt
- [ ] Compared at least three of your values with build-values.json
- [ ] Saved your own run to a slot and loaded it back
- [ ] Cleared a room with your own designed weapon

Done? Your roguelite runs end to end.
