# STEP 3 - Control flow (if / elif / else)
# Matches workshop step 3. Change a condition and run the game again.
extends RefCounted
class_name LessonControlFlow

static func run() -> void:
	print("[step 3] Control flow")

	var health: int = 70
	var speed: float = 5.5

	if health <= 0:
		print("  health is 0 or less: game over")
	else:
		print("  still playing with ", health, " health")

	if speed >= 10:
		print("  speed is 10 or more: boost active")
	elif speed >= 5:
		print("  speed is 5 to 9: normal running")
	else:
		print("  speed is below 5: crawling")

	if health > 50 and speed > 5:
		print("  both conditions true: the player is doing great")

	# Try it: set health to 0 and see which branch runs.
