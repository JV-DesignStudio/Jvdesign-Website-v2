# STEP 4 - Loops (for and while)
# Matches workshop step 4. Change the ranges and run the game again.
extends RefCounted
class_name LessonLoops

static func run() -> void:
	print("[step 4] Loops")

	for i in range(5):
		print("  for loop: pass ", i, " of 5")

	var coins: int = 0
	while coins < 3:
		coins = coins + 1
		print("  while loop: picked up coin ", coins)

	# Nested loops build a grid, one row at a time.
	for row in range(3):
		var line: String = ""
		for col in range(3):
			line = line + "# "
		print("  grid row ", row, ": ", line)

	# Try it: make the grid 5 rows by 5 columns.
