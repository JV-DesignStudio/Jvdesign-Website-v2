# STEP 5 - Functions
# Matches workshop step 5. Change a default value and run the game again.
extends RefCounted
class_name LessonFunctions

static func run() -> void:
	print("[step 5] Functions")

	var normal_hit: int = deal_damage(12)
	var boosted_hit: int = deal_damage(12, 8)
	print("  deal_damage(12) ->", normal_hit)
	print("  deal_damage(12, 8) ->", boosted_hit)
	print("  healing(25) ->", healing(25))

static func deal_damage(amount: int, bonus: int = 0) -> int:
	# One place that decides the final number, every caller reuses it.
	var final_amount: int = amount + bonus
	return final_amount

static func healing(amount: int) -> int:
	# Functions can also just do a job without returning a value.
	print("  healing for ", amount, " health")
	return amount
