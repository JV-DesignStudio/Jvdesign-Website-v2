# GDScript Essentials Starter - main scene
# Press F5 (Play) and open the Output panel to see every lesson run in order.
extends Node

func _ready() -> void:
	print("")
	print("=== GDScript Essentials Starter ===")
	print("Each lesson below matches one step of the workshop.")
	print("")
	LessonVariables.run()
	print("")
	LessonControlFlow.run()
	print("")
	LessonLoops.run()
	print("")
	LessonFunctions.run()
	print("")
	LessonObjects.run()
	print("")
	print("Done. Now open any file in scripts/, change a value, and press F5 again.")
