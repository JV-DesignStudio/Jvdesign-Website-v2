# STEP 2 - Variables and data types
# Matches workshop step 2. Change a value, save the file, then press F5.
extends RefCounted
class_name LessonVariables

static func run() -> void:
	print("[step 2] Variables and data types")

	var health: int = 100          # int = whole number
	var speed: float = 5.5         # float = decimal number
	var player_name: String = "Player"  # String = text in quotes
	var is_alive: bool = true      # bool = true or false

	print("  health =", health, " (int)")
	print("  speed =", speed, " (float)")
	print("  player_name =", player_name, " (String)")
	print("  is_alive =", is_alive, " (bool)")

	health = health - 10
	print("  health after 10 damage =", health)

	is_alive = health > 0
	print("  is_alive after the hit =", is_alive)

	# Try it: give player_name your own name and run the game again.
