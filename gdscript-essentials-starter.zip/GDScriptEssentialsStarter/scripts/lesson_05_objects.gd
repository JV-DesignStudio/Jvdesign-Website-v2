# STEP 6 - Objects
# Matches workshop step 6. Change the starting health and run the game again.
extends RefCounted
class_name LessonObjects

static func run() -> void:
	print("[step 6] Objects")

	var player = LessonPlayer.new()
	player.take_damage(15)
	print("  player.health after 15 damage =", player.health)

	player.take_damage(100)
	print("  player.health after a huge hit =", player.health)
	print("  player.is_alive =", player.is_alive)
