# STEP 6 - The player object
# Data (health) plus the rules that change it live together in one script.
# This is the class that lesson_05_objects.gd creates with .new().
extends RefCounted
class_name LessonPlayer

var health: int = 100
var is_alive: bool = true

func take_damage(amount: int) -> void:
	if not is_alive:
		return
	health = health - amount
	if health <= 0:
		health = 0
		is_alive = false
