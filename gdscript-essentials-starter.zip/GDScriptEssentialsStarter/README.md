# GDScript Essentials Starter

A small Godot 4 project for the GDScript Essentials workshop. Open it beside the
lesson and compare your own code with the finished examples.

## How to open it

1. Extract this zip somewhere you can write to (Desktop is fine).
2. Open Godot 4.x (free at godotengine.org). No account needed.
3. In the Project Manager choose Import, then pick `project.godot`.
4. Press F5 to run. Open the Output panel (bottom of the editor) to see the lessons.

Nothing here needs admin rights or an install, so it also works on a school computer
with Godot already set up.

## What is inside

| File | Workshop step |
|---|---|
| `scripts/lesson_01_variables.gd` | Step 2 - Variables and data types |
| `scripts/lesson_02_control_flow.gd` | Step 3 - Control flow |
| `scripts/lesson_03_loops.gd` | Step 4 - Loops |
| `scripts/lesson_04_functions.gd` | Step 5 - Functions |
| `scripts/lesson_05_objects.gd` | Step 6 - Objects |
| `scripts/lesson_player.gd` | Step 6 - the class the player uses |
| `scripts/main.gd` | Runs every lesson in order when you press F5 |

Every script starts with a short comment that says which step it belongs to.

## How to use it with the workshop

- Follow a workshop step first, then open the matching script and read it.
- If you get stuck, compare your code with the example and look for the one line
  that differs.
- Break it on purpose: change a value, swap `if` for `elif`, or make the loop run
  10 times, then press F5 again. The Output panel shows what changed.
- Delete nothing you need: copy a script file first if you want to keep your version.

## Troubleshooting

- **The Output panel is empty** - make sure `scenes/main.tscn` is the main scene
  (Project > Project Settings > Application > Run > Main Scene).
- **Godot says a class is unknown** - let the editor finish scanning (look for the
  progress bar at the bottom), then run again.
- **You edited a file but nothing changed** - save with Ctrl+S before pressing F5.
