extends Node2D

# 0 = Stage, 1 = Hall Left, 2 = Hall Right, 3 = Left Door, 4 = Right Door
var room = 0

# How likely Freddy is to move on each timer tick (0-20, like real FNAF AI levels)
@export var ai_level: int = 3

signal room_changed(room)
signal reached_door(side)  # emits "left" or "right"

func _ready():
	$MoveTimer.timeout.connect(_on_move_timer)

func _on_move_timer():
	if randi() % 20 < ai_level:
		_move_closer()

func _move_closer():
	match room:
		0:  # Stage — pick a side
			room = [1, 2].pick_random()
		1:  # Hall Left → Left Door
			room = 3
		2:  # Hall Right → Right Door
			room = 4
		3, 4:  # Already at a door — emit signal and stop
			reached_door.emit("left" if room == 3 else "right")
			return
	room_changed.emit(room)
