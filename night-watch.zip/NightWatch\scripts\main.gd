extends Node2D

var left_door_closed = false
var right_door_closed = false

var power = 100.0
var power_drained = false

var night_time = 0.0  # 0.0 = 12am, 1.0 = 6am
var game_active = true
const NIGHT_DURATION = 360.0  # 6 minutes = one full night

var cam_panels: Array = []
var freddy_markers := {}
var current_cam = 0

func _ready():
	cam_panels = [
		$Monitor/CamPanels/Cam1_Stage,
		$Monitor/CamPanels/Cam2_HallLeft,
		$Monitor/CamPanels/Cam3_HallRight,
		$Monitor/CamPanels/Cam4_Kitchen,
	]
	freddy_markers = {
		0: $Monitor/CamPanels/Cam1_Stage/FreddyStage,
		1: $Monitor/CamPanels/Cam2_HallLeft/FreddyHallLeft,
		2: $Monitor/CamPanels/Cam3_HallRight/FreddyHallRight,
		3: $LeftDoorPanel/FreddyLeftDoor,
		4: $RightDoorPanel/FreddyRightDoor,
	}

	show_cam(0)

	%Cam1Button.pressed.connect(func(): show_cam(0))
	%Cam2Button.pressed.connect(func(): show_cam(1))
	%Cam3Button.pressed.connect(func(): show_cam(2))
	%Cam4Button.pressed.connect(func(): show_cam(3))

	%CloseLeftDoorButton.pressed.connect(_on_left_door_pressed)
	%CloseRightDoorButton.pressed.connect(_on_right_door_pressed)

	%WinRestartButton.pressed.connect(func(): get_tree().reload_current_scene())
	%GoRestartButton.pressed.connect(func(): get_tree().reload_current_scene())

	$Freddy.room_changed.connect(_update_freddy_display)
	$Freddy.reached_door.connect(_on_freddy_at_door)
	_update_freddy_display(0)

func _process(delta):
	if not game_active:
		return
	_update_power(delta)
	_update_clock(delta)

func show_cam(index: int):
	for i in cam_panels.size():
		cam_panels[i].visible = (i == index)
	current_cam = index

func _on_left_door_pressed():
	left_door_closed = not left_door_closed
	%LeftDoorBlock.visible = left_door_closed
	%CloseLeftDoorButton.text = "🚪 Open Left Door" if left_door_closed else "🚪 Close Left Door"

func _on_right_door_pressed():
	right_door_closed = not right_door_closed
	%RightDoorBlock.visible = right_door_closed
	%CloseRightDoorButton.text = "🚪 Open Right Door" if right_door_closed else "🚪 Close Right Door"

func _update_power(delta):
	if power_drained:
		return
	var drain = 1.5  # base drain per second
	if left_door_closed:
		drain += 2.5
	if right_door_closed:
		drain += 2.5
	power -= drain * delta
	power = max(power, 0.0)
	%PowerBar.value = power
	%PowerLabel.text = "⚡ Power: " + str(int(power)) + "%"
	if power <= 0.0:
		_power_out()

func _power_out():
	power_drained = true
	left_door_closed = false
	right_door_closed = false
	%LeftDoorBlock.visible = false
	%RightDoorBlock.visible = false
	%CloseLeftDoorButton.text = "🚪 Close Left Door"
	%CloseRightDoorButton.text = "🚪 Close Right Door"

func _update_clock(delta):
	night_time += delta / NIGHT_DURATION
	var hour = int(night_time * 6)
	var display = ["12 AM", "1 AM", "2 AM", "3 AM", "4 AM", "5 AM", "6 AM"]
	%ClockLabel.text = display[min(hour, 6)]
	if night_time >= 1.0:
		_win()

func _update_freddy_display(room: int):
	for key in freddy_markers.keys():
		freddy_markers[key].visible = (key == room)

func _on_freddy_at_door(side: String):
	var door_closed = left_door_closed if side == "left" else right_door_closed
	if door_closed:
		$Freddy.room = 0
		_update_freddy_display(0)
	else:
		_trigger_jumpscare()

func _trigger_jumpscare():
	%JumpScare.visible = true
	await get_tree().create_timer(1.8).timeout
	_game_over()

func _win():
	game_active = false
	%WinScreen.visible = true

func _game_over():
	game_active = false
	%GameOverScreen.visible = true
