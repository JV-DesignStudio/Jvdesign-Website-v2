Open project.godot in Godot 4.
