﻿extends Control

const COLS = 4
const ROWS = 4
const CARD_SIZE = Vector2(80, 80)
const FACES = ["A", "B", "C", "D", "E", "F", "G", "H"]
const BACK = "?"

var board = []
var face_up = []
var matched = []
var first_pick = -1
var second_pick = -1
var moves = 0

func _ready():
	_build_grid()
	_new_game()

func _build_grid():
	var grid = $Grid
	for i in range(COLS * ROWS):
		var b = Button.new()
		b.custom_minimum_size = CARD_SIZE
		b.text = BACK
		b.pressed.connect(_flip_card.bind(i))
		grid.add_child(b)
		board.append(b)
		face_up.append(false)
		matched.append(false)

func _flip_card(index):
	# Step 2: reveal the card and remember the pick.
	pass

func _check_match():
	# Step 3: compare the two picks, then Step 4 and 5.
	pass

func _new_game():
	# Step 6: shuffle, reset the lists and hide the win panel.
	pass

func _update_hud():
	$Moves.text = "Moves: " + str(moves)
