# 🚀 Asteroids – Godot 4 Project

A full-featured Asteroids clone with pixel art, asteroid splitting, UFO enemies, power-ups, lives, and waves.

---

## 🚀 How to Open

1. Install **Godot 4** → https://godotengine.org
2. Open Godot → **Import** → select `project.godot`
3. Press **F5** to play!

---

## 🎮 Controls

| Key | Action |
|-----|--------|
| `A` / `←` | Rotate left |
| `D` / `→` | Rotate right |
| `W` / `↑` | Thrust |
| `Space` / `Z` | Shoot |
| `R` | Restart (game over) |

---

## 👾 Scoring

| Target | Points |
|--------|--------|
| Large asteroid | 20 |
| Medium asteroid | 50 |
| Small asteroid | 100 |
| UFO | 200 |
| Mystery power-up bonus | — |

---

## ⚡ Power-Ups

- **🔵 Shield** — absorbs one hit, visible ring around ship
- **🟡 Rapid Fire** — 3× fire rate for 6 seconds

---

## 📁 Structure

```
asteroids/
├── project.godot
├── sprites/           ← All pixel art
├── scenes/
│   ├── Main.tscn
│   ├── Ship.tscn
│   ├── Asteroid.tscn  ← All 3 sizes in one scene
│   ├── Bullet.tscn
│   ├── UFO.tscn
│   ├── Explosion.tscn
│   └── PowerUp.tscn
└── scripts/
    ├── Main.gd        ← Game loop, collisions, waves
    ├── Ship.gd        ← Thrust, inertia, screen wrap
    ├── Asteroid.gd    ← Spin, drift, wrap, splitting
    ├── Bullet.gd      ← Movement, lifetime, wrap
    ├── UFO.gd         ← AI movement, aimed shooting
    ├── PowerUp.gd     ← Drift, bob, collect
    ├── Explosion.gd
    └── GameState.gd   ← Score/lives/wave (autoload)
```

---

## 🛠️ Tweak Ideas

- `Ship.gd → thrust_power` — stronger/weaker engines
- `Ship.gd → rotation_speed` — faster/slower turning
- `Main.gd → count = 4 + ...` — change starting asteroid count
- `UFO.gd → shoot_interval` — make UFO more or less aggressive
