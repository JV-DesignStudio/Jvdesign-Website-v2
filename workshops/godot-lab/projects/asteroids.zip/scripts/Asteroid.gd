extends Area2D

signal asteroid_destroyed(size, pos, variant)

const SCREEN  = Vector2(640, 640)
const POINTS  = [20, 50, 100]
const RADII   = [28.0, 17.0, 10.0]
const SPEEDS  = [40.0, 65.0, 95.0]

@export var size:    int = 0
@export var variant: int = 0

var velocity:   Vector2 = Vector2.ZERO
var spin_speed: float   = 0.0
var points:     int     = 0

@onready var sprite_large: AnimatedSprite2D  = $Sprite
@onready var sprite_med:   AnimatedSprite2D  = $SpriteMed
@onready var sprite_small: AnimatedSprite2D  = $SpriteSmall
@onready var col:          CollisionShape2D  = $Col


func setup(sz: int, var_: int, vel: Vector2) -> void:
	size       = sz
	variant    = var_
	velocity   = vel
	points     = POINTS[sz]
	spin_speed = randf_range(-1.5, 1.5)

	# Show correct sprite, hide others, set variant frame
	sprite_large.visible = (sz == 0)
	sprite_med.visible   = (sz == 1)
	sprite_small.visible = (sz == 2)

	var active = [sprite_large, sprite_med, sprite_small][sz]
	active.frame = variant

	# Resize collision
	(col.shape as CircleShape2D).radius = RADII[sz]


func _process(delta: float) -> void:
	rotation   += spin_speed * delta
	position   += velocity * delta
	position.x  = wrapf(position.x, -40, SCREEN.x + 40)
	position.y  = wrapf(position.y, -40, SCREEN.y + 40)


func die() -> void:
	asteroid_destroyed.emit(size, global_position, variant)
	queue_free()
