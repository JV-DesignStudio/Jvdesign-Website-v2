extends Area2D

const SCREEN = Vector2(640, 640)

@export var speed:    float = 520.0
@export var is_enemy: bool  = false
@export var lifetime: float = 1.1

var velocity: Vector2 = Vector2.ZERO
var _age:     float   = 0.0


func setup(pos: Vector2, angle: float) -> void:
	position = pos
	rotation = angle
	velocity = Vector2(sin(angle), -cos(angle)) * speed


func _process(delta: float) -> void:
	_age += delta
	if _age >= lifetime:
		queue_free()
		return
	position += velocity * delta
	# Wrap bullets too
	position.x = wrapf(position.x, -10, SCREEN.x + 10)
	position.y = wrapf(position.y, -10, SCREEN.y + 10)
