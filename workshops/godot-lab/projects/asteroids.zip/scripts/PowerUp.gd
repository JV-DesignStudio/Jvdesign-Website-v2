extends Area2D

const SCREEN = Vector2(640, 640)

@export var type: String = "shield"

var velocity: Vector2 = Vector2.ZERO
var _age:     float   = 0.0
var _bob:     float   = 0.0


func setup(pos: Vector2, kind: String) -> void:
	position = pos
	type     = kind
	velocity = Vector2(randf_range(-30, 30), randf_range(-30, 30))
	$Sprite.texture = load("res://sprites/powerup_%s.png" % kind)


func _process(delta: float) -> void:
	_age += delta
	_bob += delta * 3.0
	position += velocity * delta
	position.x = wrapf(position.x, -20, SCREEN.x + 20)
	position.y = wrapf(position.y, -20, SCREEN.y + 20)
	scale = Vector2.ONE * (1.0 + sin(_bob) * 0.1)
	if _age > 6.0:
		modulate.a = 1.0 - (_age - 6.0) / 2.0
	if _age > 8.0:
		queue_free()
