Pixel Hunter - Browser Snake (Ep 4: Snake)
JVDesignStudio - https://jvdesignstudio.co.uk/workshops/js-snake-workshop.html

Files:
- snake-starter.html  : empty starter (add the 6 steps from the workshop)
- snake-complete.html : finished reference game (complete, playable)

How to use:
1. Open snake-starter.html in Notepad, VS Code, or any text editor.
2. Follow the 6 steps in the workshop, typing each part into the <script> section.
3. Save, double-click to play in browser. Use F12 console if nothing shows.
4. Compare your file to snake-complete.html if stuck.

Features in the complete version:
- 25x25 grid (500x500 canvas, 20px cells), 120ms tick inside requestAnimationFrame
- Input queue fixing the classic reversal bug, wrap-around toggle
- Food with safe spawn (Array.some), growth, score, mobile swipe
- Speed curve, gradient body, best score saved in localStorage

No install, no account, works on school computers.
