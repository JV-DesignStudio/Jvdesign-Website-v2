# 👾 Space Invaders – Godot 4 Project

A full Space Invaders clone with animated sprites, multiple enemy types, barriers, lives, waves, and a mystery ship.

---

## 🚀 How to Open

1. Install **Godot 4** → https://godotengine.org
2. Open Godot → **Import** → select `project.godot`
3. Press **F5** to play!

---

## 🎮 Controls

| Key | Action |
|-----|--------|
| `←` `→` or `A` `D` | Move ship |
| `Space` or `Z` | Shoot |
| `R` | Restart (after game over) |

---

## 👾 Enemy Types & Points

| Enemy | Points |
|-------|--------|
| 🟢 Squid (bottom 2 rows) | 10 pts |
| 🟠 Crab (middle 2 rows) | 20 pts |
| 🔴 UFO-style (top row) | 30 pts |
| 🔴 Mystery ship (flies across top) | 50–200 pts |

---

## 📁 Structure

```
space_invaders/
├── project.godot
├── sprites/          ← All pixel art sprite sheets
├── scenes/
│   ├── Main.tscn     ← Game world
│   ├── Alien.tscn    ← Single alien
│   ├── Bullet.tscn   ← Player + enemy bullets
│   ├── Barrier.tscn  ← Destructible shields
│   ├── Explosion.tscn
│   ├── Mystery.tscn  ← Bonus UFO
│   └── Player.tscn
└── scripts/
    ├── Main.gd        ← Game loop, collisions, HUD
    ├── AlienGrid.gd   ← Swarm movement & shooting
    ├── Alien.gd
    ├── Bullet.gd
    ├── Barrier.gd
    ├── Mystery.gd
    ├── Explosion.gd
    ├── Player.gd
    └── GameState.gd   ← Global score/lives/wave (autoload)
```

---

## 🛠️ Things to Try

- Change `AlienGrid.gd → COLS/ROWS` to resize the swarm
- Adjust `Player.gd → shoot_cooldown` to allow faster shooting
- Modify `ROW_POINTS` in AlienGrid to change point values
- Add more barriers by duplicating Barrier nodes in Main.tscn
