extends Node2D

var health: int = 4

@onready var sprite: Sprite2D = $Sprite


func _ready() -> void:
	add_to_group("barrier")


func hit() -> void:
	health -= 1
	var t := float(health) / 4.0
	sprite.modulate = Color(t, 1.0, t, 1.0)
	if health <= 0:
		queue_free()
