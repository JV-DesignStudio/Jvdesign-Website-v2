extends Node

# Global game state shared across scenes
var score:  int = 0
var lives:  int = 3
var wave:   int = 1
var hi_score: int = 0
