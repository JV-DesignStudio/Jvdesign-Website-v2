extends Node2D

@onready var player:       Area2D        = $Player
@onready var alien_grid:   Node2D        = $AlienGrid
@onready var bullets_node: Node2D        = $Bullets
@onready var hud_score:    Label         = $HUD/ScoreLabel
@onready var hud_hi:       Label         = $HUD/HiLabel
@onready var hud_lives:    HBoxContainer = $HUD/LivesBox
@onready var hud_wave:     Label         = $HUD/WaveLabel
@onready var msg_label:    Label         = $HUD/MsgLabel
@onready var mystery_node: Area2D        = $Mystery
@onready var mystery_timer: Timer        = $MysteryTimer

const BulletScene    = preload("res://scenes/Bullet.tscn")
const ExplosionScene = preload("res://scenes/Explosion.tscn")

var _game_over:  bool = false
var _respawning: bool = false
var _wave_clear: bool = false


func _ready() -> void:
	GameState.score = 0
	GameState.lives = 3
	_refresh_hud()

	player.bullet_fired.connect(_on_player_shoot)
	player.player_hit.connect(_on_player_hit)

	alien_grid.all_dead.connect(_on_wave_clear)
	alien_grid.reached_bottom.connect(_on_game_over)
	alien_grid.enemy_bullet_fired.connect(_on_enemy_shoot)

	mystery_node.mystery_killed.connect(_on_mystery_killed)
	mystery_node.hide()
	mystery_timer.wait_time = randf_range(15.0, 30.0)
	mystery_timer.start()
	mystery_timer.timeout.connect(_launch_mystery)

	_show_wave_banner()


func _process(_delta: float) -> void:
	if _game_over:
		if Input.is_key_pressed(KEY_R):
			GameState.wave = 1
			get_tree().reload_current_scene()
		return

	if _respawning or _wave_clear:
		return

	_check_bullet_collisions()


# ── Shooting ─────────────────────────────────────────────────
func _on_player_shoot(pos: Vector2) -> void:
	# Only one player bullet allowed at a time
	for b in bullets_node.get_children():
		if not b.is_enemy:
			return
	var b = BulletScene.instantiate()
	b.is_enemy  = false
	b.direction = -1.0
	b.position  = pos
	bullets_node.add_child(b)


func _on_enemy_shoot(pos: Vector2) -> void:
	var b = BulletScene.instantiate()
	b.is_enemy  = true
	b.direction = 1.0
	b.speed     = 180.0 + GameState.wave * 20.0
	b.position  = pos
	bullets_node.add_child(b)


# ── Simple AABB overlap check ─────────────────────────────────
func _overlaps(pos_a: Vector2, half_a: Vector2, pos_b: Vector2, half_b: Vector2) -> bool:
	return abs(pos_a.x - pos_b.x) < half_a.x + half_b.x \
	   and abs(pos_a.y - pos_b.y) < half_a.y + half_b.y


# ── Collision detection (called every frame) ─────────────────
func _check_bullet_collisions() -> void:
	for bullet in bullets_node.get_children():
		if not is_instance_valid(bullet):
			continue

		var bpos  = bullet.global_position
		var bhalf = Vector2(3, 8)   # half-size of bullet

		if not bullet.is_enemy:
			# ── Player bullet vs aliens ───────────────────
			for alien in alien_grid.aliens.duplicate():
				if not is_instance_valid(alien) or not alien.alive:
					continue
				if _overlaps(bpos, bhalf, alien.global_position, Vector2(14, 10)):
					GameState.score += alien.points
					GameState.hi_score = max(GameState.score, GameState.hi_score)
					_spawn_explosion(alien.global_position)
					alien.die()
					bullet.queue_free()
					_refresh_hud()
					break

			# ── Player bullet vs mystery ──────────────────
			if is_instance_valid(mystery_node) and mystery_node.visible:
				if _overlaps(bpos, bhalf, mystery_node.global_position, Vector2(20, 8)):
					mystery_node.die()
					if is_instance_valid(bullet):
						bullet.queue_free()

			# ── Player bullet vs barriers ─────────────────
			for barrier in get_tree().get_nodes_in_group("barrier"):
				if not is_instance_valid(barrier):
					continue
				if _overlaps(bpos, bhalf, barrier.global_position, Vector2(12, 9)):
					barrier.hit()
					if is_instance_valid(bullet):
						bullet.queue_free()
					break

		else:
			# ── Enemy bullet vs player ────────────────────
			if is_instance_valid(player) and player.visible and player._alive:
				if _overlaps(bpos, bhalf, player.global_position, Vector2(20, 12)):
					player.die()
					if is_instance_valid(bullet):
						bullet.queue_free()

			# ── Enemy bullet vs barriers ──────────────────
			for barrier in get_tree().get_nodes_in_group("barrier"):
				if not is_instance_valid(barrier):
					continue
				if _overlaps(bpos, bhalf, barrier.global_position, Vector2(12, 9)):
					barrier.hit()
					if is_instance_valid(bullet):
						bullet.queue_free()
					break


# ── Events ───────────────────────────────────────────────────
func _on_player_hit() -> void:
	GameState.lives -= 1
	_spawn_explosion(player.global_position)
	_refresh_hud()

	if GameState.lives <= 0:
		_on_game_over()
	else:
		_respawning = true
		await get_tree().create_timer(2.0).timeout
		if is_instance_valid(player):
			player.show()
			player._alive = true
		_respawning = false


func _on_wave_clear() -> void:
	_wave_clear = true
	GameState.wave += 1
	_show_message("Wave %d!" % GameState.wave)
	await get_tree().create_timer(2.5).timeout
	get_tree().reload_current_scene()


func _on_game_over() -> void:
	_game_over = true
	_show_message("GAME OVER\nPress R to restart")


func _on_mystery_killed(pts: int, pos: Vector2) -> void:
	GameState.score += pts
	GameState.hi_score = max(GameState.score, GameState.hi_score)
	_spawn_explosion(pos)
	_refresh_hud()
	var lbl = Label.new()
	lbl.text = str(pts)
	lbl.position = pos - Vector2(16, 0)
	lbl.add_theme_color_override("font_color", Color(1, 0.4, 0.4))
	add_child(lbl)
	await get_tree().create_timer(1.0).timeout
	if is_instance_valid(lbl):
		lbl.queue_free()


func _launch_mystery() -> void:
	if _game_over or _wave_clear:
		return
	mystery_node.launch(randi() % 2 == 0)
	mystery_timer.wait_time = randf_range(15.0, 30.0)
	mystery_timer.start()


func _spawn_explosion(pos: Vector2) -> void:
	var exp = ExplosionScene.instantiate()
	exp.position = pos
	add_child(exp)


func _refresh_hud() -> void:
	hud_score.text = "SCORE  %05d" % GameState.score
	hud_hi.text    = "HI  %05d"    % GameState.hi_score
	hud_wave.text  = "WAVE %d"     % GameState.wave
	for child in hud_lives.get_children():
		child.queue_free()
	for i in range(GameState.lives):
		var t = TextureRect.new()
		t.texture = load("res://sprites/player.png")
		t.custom_minimum_size = Vector2(24, 16)
		t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		hud_lives.add_child(t)


func _show_message(text: String) -> void:
	msg_label.text    = text
	msg_label.visible = true


func _show_wave_banner() -> void:
	msg_label.text    = "Wave %d" % GameState.wave
	msg_label.visible = true
	await get_tree().create_timer(1.5).timeout
	if is_instance_valid(msg_label):
		msg_label.visible = false
