extends Area2D

signal mystery_killed(points, pos)

@export var speed: float = 120.0
var _dir: float = 1.0


func launch(from_left: bool) -> void:
	_dir = 1.0 if from_left else -1.0
	position.x = -40.0 if from_left else 520.0
	show()


func _process(delta: float) -> void:
	position.x += _dir * speed * delta
	if position.x > 520 or position.x < -40:
		queue_free()


func die() -> void:
	var pts = [50, 100, 150, 200][randi() % 4]
	mystery_killed.emit(pts, global_position)
	queue_free()
