extends Node2D

signal all_dead
signal reached_bottom
signal enemy_bullet_fired(pos)

# Grid config
const COLS       = 11
const ROWS       = 5
const SPACING_X  = 40.0
const SPACING_Y  = 36.0

# Points per row (bottom to top)
const ROW_POINTS = [10, 10, 20, 20, 30]

# Which alien type per row (0=squid, 1=crab, 2=UFO-style)
const ROW_TYPES  = [0, 0, 1, 1, 2]

var aliens:       Array = []   # flat list of alive alien nodes
var _dir:         float = 1.0  # current horizontal direction
var _step_timer:  float = 0.0
var _step_time:   float = 1.0  # seconds between steps (speeds up)
var _drop_amount: float = 12.0
var _shoot_timer: float = 0.0
var _shoot_interval: float = 1.5

# Starting position (top-left of grid)
const START_X = 40.0
const START_Y = 80.0
const SCREEN_W = 480.0
const BOTTOM_LIMIT = 500.0


func _ready() -> void:
	_spawn_grid()


func _spawn_grid() -> void:
	for row in range(ROWS):
		for col in range(COLS):
			var alien = _make_alien(row, col)
			add_child(alien)
			aliens.append(alien)


func _make_alien(row: int, col: int) -> Node2D:
	var alien = preload("res://scenes/Alien.tscn").instantiate()
	alien.position = Vector2(
		START_X + col * SPACING_X,
		START_Y + row * SPACING_Y
	)
	alien.points     = ROW_POINTS[row]
	alien.alien_type = ROW_TYPES[row]
	alien.alien_killed.connect(_on_alien_killed)
	return alien


func _process(delta: float) -> void:
	if aliens.is_empty():
		return

	# ── March step ──────────────────────────────────────────
	_step_timer += delta
	if _step_timer >= _step_time:
		_step_timer = 0.0
		_march()

	# ── Enemy shooting ──────────────────────────────────────
	_shoot_timer += delta
	if _shoot_timer >= _shoot_interval:
		_shoot_timer = 0.0
		_enemy_shoot()

	# ── Check bottom ────────────────────────────────────────
	for a in aliens:
		if a.global_position.y > BOTTOM_LIMIT:
			reached_bottom.emit()
			return


func _march() -> void:
	# Check if any alien would hit a wall
	var hit_wall := false
	for a in aliens:
		var nx = a.position.x + _dir * 12.0
		if nx < 10 or nx > SCREEN_W - 10:
			hit_wall = true
			break

	if hit_wall:
		_dir *= -1
		# Drop down
		for a in aliens:
			a.position.y += _drop_amount
	else:
		for a in aliens:
			a.position.x += _dir * 12.0

	# Speed up as aliens die
	var ratio = float(aliens.size()) / float(COLS * ROWS)
	_step_time = lerp(0.08, 1.0, ratio)


func _enemy_shoot() -> void:
	if aliens.is_empty():
		return
	# Pick a random alien from the bottom row of each column
	var shooters: Array = []
	for col in range(COLS):
		var col_aliens = aliens.filter(func(a): 
			return int(round((a.position.x - START_X) / SPACING_X)) == col
		)
		if not col_aliens.is_empty():
			col_aliens.sort_custom(func(a, b): return a.position.y > b.position.y)
			shooters.append(col_aliens[0])

	if shooters.is_empty():
		return
	var shooter = shooters[randi() % shooters.size()]
	enemy_bullet_fired.emit(shooter.global_position + Vector2(0, 16))


func _on_alien_killed(_pts: int, _pos: Vector2) -> void:
	# Remove from our list
	aliens = aliens.filter(func(a): return is_instance_valid(a) and a.alive)
	if aliens.is_empty():
		all_dead.emit()


func speed_up(factor: float) -> void:
	_shoot_interval = max(0.4, _shoot_interval * factor)
