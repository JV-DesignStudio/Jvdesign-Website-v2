extends Area2D

signal bullet_fired(pos)
signal player_hit

@export var speed:          float = 200.0
@export var shoot_cooldown: float = 0.35

var _cooldown: float = 0.0
var _alive:    bool  = true

const SCREEN_W = 480.0
const HALF_W   = 20.0   # half ship width for clamping


func _process(delta: float) -> void:
	if not _alive:
		return

	_cooldown -= delta

	# Movement
	var dir := 0.0
	if Input.is_key_pressed(KEY_LEFT)  or Input.is_key_pressed(KEY_A):
		dir = -1.0
	if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		dir = 1.0
	position.x = clamp(position.x + dir * speed * delta, HALF_W, SCREEN_W - HALF_W)

	# Shoot
	if _cooldown <= 0 and (
		Input.is_key_pressed(KEY_SPACE) or
		Input.is_key_pressed(KEY_UP)    or
		Input.is_key_pressed(KEY_Z)
	):
		_cooldown = shoot_cooldown
		bullet_fired.emit(position + Vector2(0, -20))


func die() -> void:
	if not _alive:
		return
	_alive = false
	player_hit.emit()
	# Flash and respawn handled by Main
	hide()
