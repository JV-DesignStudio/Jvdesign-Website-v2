extends Area2D

@export var speed:     float = 400.0
@export var direction: float = -1.0   # -1 = up (player), +1 = down (enemy)
@export var is_enemy:  bool  = false

var _frame_timer: float = 0.0


func _process(delta: float) -> void:
	position.y += speed * direction * delta

	# Animate enemy bullet zigzag
	if is_enemy:
		_frame_timer += delta * 8
		$Sprite.frame = int(_frame_timer) % 2

	# Kill when off screen
	if position.y < -20 or position.y > 650:
		queue_free()
