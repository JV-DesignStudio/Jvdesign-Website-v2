extends Area2D

signal alien_killed(points, pos)

@export var points:     int = 10
@export var alien_type: int = 0

var alive: bool = true

const ANIM_NAMES = ["a", "b", "c"]


func _ready() -> void:
	var anim = ANIM_NAMES[clamp(alien_type, 0, 2)]
	$Sprite.play(anim)


func die() -> void:
	if not alive:
		return
	alive = false
	alien_killed.emit(points, global_position)
	queue_free()
