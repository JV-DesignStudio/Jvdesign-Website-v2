LOW POLY RALLY - starter template
JVDesignStudio workshop
Workshop: https://jvdesignstudio.co.uk/workshops/godot-rally-workshop.html

A short A-to-B rally sprint. Start at A, cross the sectors, finish at B.
Your best time is saved on this computer.

HOW TO OPEN
1. Install Godot 4 (Standard) from godotengine.org.
2. Unzip this folder somewhere you can find it.
3. Open Godot, choose Import, and pick project.godot in this folder.
4. Press F5 to play.

HOW A RUN WORKS
1. The car starts at A and a 3, 2, 1, GO countdown runs.
2. The clock starts on GO.
3. Pass the three yellow sector gates for split times.
4. Cross the white FINISH B gate to stop the clock.
5. Press R to restart from A. The best time stays saved.

CONTROLS
W or Up ............... accelerate
S or Down ............. brake and reverse
A / D or Left / Right . steer
Space ................. handbrake
C / V ................. next / previous camera
R ..................... restart the sprint from A

WHAT IS IN THE BOX
scenes/rally_stage.tscn ... A and B gates, sectors, car, camera rig and HUD
scenes/car.tscn ........... VehicleBody3D with four wheels
scenes/camera_rig.tscn .... SpringArm3D, shake pivot and Camera3D
scripts/car.gd ............ driving, surface grip and the frozen start
scripts/camera_rig.gd ..... chase, bonnet and cockpit cameras
scripts/stage_timer.gd .... countdown, splits, finish and best time
scripts/hud.gd ............ timer, splits, best time and countdown

WHAT TO CHANGE FIRST
- Drive it. If the sprint feels slow, raise engine_power in car.gd.
- Move the StartGate, sector gates and FinishGate in rally_stage.tscn to make the run longer or tighter.
- Change the body colour in scenes/car.tscn, or swap the boxes for your own Blender car.
- Add the group name "mud" to another road piece to test lower grip.
- Lower countdown_seconds on StageTimer for a quicker start.

NOTES
- The car is made from simple boxes so the project opens with no art files.
- Replace the Body, Cabin and Spoiler meshes with your own low-poly car when you are ready.
- VehicleBody3D treats +Z as forward. The car is rotated 180 degrees to face down the stage.
- If the steering turns the wrong way, flip the sign on steering in car.gd.
- The best time is stored in user://low_poly_rally_best.cfg, outside the project folder.
- The camera is the point of the workshop. Try all three views on the same corner.
