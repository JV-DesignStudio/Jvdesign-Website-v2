extends VehicleBody3D
class_name RallyCar
# car.gd - the rally car.
#
# VehicleBody3D treats local +Z as forward. The car in the stage is rotated
# 180 degrees so that its nose points down the road.
#
# The GroundRay reads the surface under the car and changes grip.
# The sprint timer sets frozen = false on GO and true again at the finish.

@export var engine_power := 50.0
@export var brake_power := 25.0
@export var reverse_power := 35.0
@export var handbrake_power := 25.0
@export var max_steer := 0.5
@export var steer_speed := 3.5
@export var top_speed_kmh := 140.0
@export var camera_rig: RallyCameraRig

@onready var start_transform := global_transform
@onready var ground_ray: RayCast3D = $GroundRay
@onready var rear_wheels: Array[VehicleWheel3D] = [$Wheel_RL, $Wheel_RR]
@onready var wheels: Array[VehicleWheel3D] = [$Wheel_FL, $Wheel_FR, $Wheel_RL, $Wheel_RR]

var steer := 0.0
var surface_grip := 1.0
var frozen := true

func _ready() -> void:
	add_to_group("player_car")
	contact_monitor = true
	max_contacts_reported = 4
	body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	if frozen:
		engine_force = 0.0
		brake = brake_power
		steering = 0.0
		return

	_read_surface()

	var throttle := Input.get_action_strength("accelerate")
	var brake_input := Input.get_action_strength("brake")
	var handbrake := Input.is_action_pressed("handbrake")
	# Positive steering turns left, so ask for left as the positive action.
	var steer_input := Input.get_axis("steer_right", "steer_left")

	# Turn the wheels smoothly instead of snapping them.
	steer = move_toward(steer, steer_input * max_steer, steer_speed * delta)
	steering = steer

	var speed := linear_velocity.length()
	if brake_input > 0.01:
		engine_force = 0.0
		brake = brake_input * brake_power
		# At a standstill, the brake pedal becomes reverse.
		if speed < 0.6:
			engine_force = -reverse_power * brake_input
	elif speed * 3.6 < top_speed_kmh:
		# A little extra push at low speed so the car gets moving.
		var boost := 1.0
		if speed < 5.0 and speed > 0.1:
			boost = clampf(5.0 / speed, 1.0, 2.0)
		engine_force = throttle * engine_power * boost * surface_grip
		brake = 0.0
	else:
		engine_force = 0.0
		brake = 0.0

	if handbrake:
		brake = handbrake_power
		for wheel in rear_wheels:
			wheel.wheel_friction_slip = 1.4
	else:
		_apply_grip()

func _read_surface() -> void:
	if not ground_ray.is_colliding():
		surface_grip = 0.6
		return

	var collider := ground_ray.get_collider() as Node
	if collider and collider.is_in_group("gravel"):
		surface_grip = 0.75
	elif collider and collider.is_in_group("mud"):
		surface_grip = 0.55
	else:
		surface_grip = 1.0

func _apply_grip() -> void:
	var slip := 3.0 * surface_grip
	for wheel in wheels:
		wheel.wheel_friction_slip = slip

func _on_body_entered(_body: Node) -> void:
	var impact := linear_velocity.length()
	if impact > 4.0:
		var rig := _get_camera_rig()
		if rig:
			rig.add_trauma(clampf(impact / 18.0, 0.15, 1.0))

func _get_camera_rig() -> RallyCameraRig:
	if camera_rig == null:
		camera_rig = get_tree().get_first_node_in_group("camera_rig") as RallyCameraRig
	return camera_rig

func reset_to_start() -> void:
	global_transform = start_transform
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
