extends Node
# stage_timer.gd - the A-to-B sprint.
#
# The car starts at A and the finish line is B. A short countdown runs, then
# the clock starts. Crossing B stops the clock and saves the best time.
# R restarts the sprint from A at any time.

signal countdown_updated(value: float)
signal race_started
signal split_taken(number: int, seconds: float)
signal stage_finished(total: float, splits: Array, best: float, is_new_best: bool)
signal time_updated(seconds: float)

enum State { COUNTDOWN, RUNNING, FINISHED }

@export var countdown_seconds := 3.0
@export var car: RallyCar
@export var finish_gate: Area3D
@export var sectors: Array[Area3D] = []

const BEST_PATH := "user://low_poly_rally_best.cfg"

var state := State.COUNTDOWN
var countdown_left := 3.0
var start_time := 0.0
var splits: Array[float] = []
var next_sector := 0
var best_time := 0.0

func _ready() -> void:
	add_to_group("stage_timer")

	if car == null:
		car = get_node_or_null("../Car") as RallyCar
	if finish_gate == null:
		finish_gate = get_node_or_null("../FinishGate") as Area3D
	if sectors.is_empty():
		for gate_name in ["Sector1", "Sector2", "Sector3"]:
			var gate := get_node_or_null("../" + gate_name) as Area3D
			if gate != null:
				sectors.append(gate)

	if finish_gate != null:
		finish_gate.body_entered.connect(_on_finish)
	for i in sectors.size():
		sectors[i].body_entered.connect(_on_sector.bind(i))

	load_best()
	restart_race()

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("reset"):
		restart_race()
		return

	if state == State.COUNTDOWN:
		countdown_left -= delta
		countdown_updated.emit(countdown_left)
		if countdown_left <= 0.0:
			state = State.RUNNING
			start_time = _now()
			if car != null:
				car.frozen = false
			race_started.emit()
	elif state == State.RUNNING:
		time_updated.emit(_now() - start_time)

func restart_race() -> void:
	state = State.COUNTDOWN
	countdown_left = countdown_seconds
	splits.clear()
	next_sector = 0
	if car != null:
		car.reset_to_start()
		car.frozen = true
	countdown_updated.emit(countdown_left)
	time_updated.emit(0.0)

func _on_sector(body: Node3D, index: int) -> void:
	if body != car or state != State.RUNNING or index != next_sector:
		return
	splits.append(_now() - start_time)
	next_sector += 1
	split_taken.emit(index + 1, splits[-1])

func _on_finish(body: Node3D) -> void:
	if body != car or state != State.RUNNING:
		return
	state = State.FINISHED
	if car != null:
		car.frozen = true

	var total := _now() - start_time
	var is_new_best := best_time <= 0.0 or total < best_time
	if is_new_best:
		best_time = total
		save_best(total)
	stage_finished.emit(total, splits, best_time, is_new_best)

func load_best() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(BEST_PATH) == OK:
		best_time = float(cfg.get_value("sprint", "best_time", 0.0))

func save_best(total: float) -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("sprint", "best_time", total)
	cfg.save(BEST_PATH)

func _now() -> float:
	return Time.get_ticks_msec() / 1000.0
