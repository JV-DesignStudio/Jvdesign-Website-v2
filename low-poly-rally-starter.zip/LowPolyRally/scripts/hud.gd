extends CanvasLayer
# hud.gd - the small sprint HUD. Keep it out of the way of the road.

@onready var time_label: Label = $TimeLabel
@onready var split_label: Label = $SplitLabel
@onready var result_label: Label = $ResultLabel
@onready var countdown_label: Label = $CountdownLabel
@onready var stage_timer: Node = get_node_or_null("../StageTimer")

var _hide_token := 0

func _ready() -> void:
	if stage_timer == null:
		countdown_label.visible = false
		return

	stage_timer.connect("countdown_updated", _on_countdown)
	stage_timer.connect("race_started", _on_race_started)
	stage_timer.connect("split_taken", _on_split)
	stage_timer.connect("stage_finished", _on_finish)
	stage_timer.connect("time_updated", _on_time)
	_show_best(float(stage_timer.get("best_time")))

func _on_countdown(value: float) -> void:
	_hide_token += 1
	countdown_label.visible = true
	if value > 0.0:
		countdown_label.text = str(ceili(value))
	else:
		countdown_label.text = "GO!"

func _on_race_started() -> void:
	_hide_token += 1
	var token := _hide_token
	countdown_label.text = "GO!"
	await get_tree().create_timer(0.8).timeout
	if token != _hide_token:
		return
	countdown_label.visible = false
	result_label.visible = false
	split_label.text = "SPLIT  --"

func _on_time(seconds: float) -> void:
	time_label.text = "TIME  %0.2f" % seconds

func _on_split(number: int, seconds: float) -> void:
	split_label.text = "SPLIT %d  %0.2f" % [number, seconds]

func _on_finish(total: float, splits: Array, best: float, is_new_best: bool) -> void:
	time_label.text = "FINISH  %0.2f" % total
	result_label.visible = true
	result_label.text = "NEW BEST!" if is_new_best else "BEST  %0.2f" % best
	var parts := PackedStringArray()
	for s in splits:
		parts.append("%0.2f" % s)
	split_label.text = "Splits: " + ", ".join(parts)

func _show_best(best: float) -> void:
	result_label.visible = true
	if best > 0.0:
		result_label.text = "BEST  %0.2f" % best
	else:
		result_label.text = "BEST  --"
