extends Node3D
class_name RallyCameraRig
# camera_rig.gd - the DiRT-style rally camera.
#
# C = next view, V = previous view. Chase is the default.
# The rig lives in world space and follows the car with a spring, so it lags,
# looks into corners, widens the FOV with speed and shakes on impact.

enum View { CHASE, BONNET, COCKPIT }

@export var car: RallyCar
@export var spring_arm: SpringArm3D
@export var shake_pivot: Node3D
@export var camera: Camera3D

@export_group("Chase")
@export var chase_distance := 6.5
@export var chase_height := 2.1
@export var chase_look_height := 1.0
@export var chase_smooth := 6.0
@export var corner_look := 1.8

@export_group("Fixed views")
@export var bonnet_offset := Vector3(0.0, 1.05, 1.4)
@export var cockpit_offset := Vector3(0.35, 1.15, -0.2)

@export_group("Feel")
@export var base_fov := 62.0
@export var max_fov := 82.0
@export var bonnet_fov := 80.0
@export var cockpit_fov := 72.0
@export var fov_smooth := 5.0
@export var trauma_decay := 1.4
@export var shake_strength := 0.09

var view := View.CHASE
var trauma := 0.0
var _noise := FastNoiseLite.new()

func _ready() -> void:
	add_to_group("camera_rig")
	_noise.frequency = 1.8
	_noise.seed = randi()

	if spring_arm == null:
		spring_arm = $SpringArm3D as SpringArm3D
	if shake_pivot == null:
		shake_pivot = $SpringArm3D/ShakePivot as Node3D
	if camera == null:
		camera = $SpringArm3D/ShakePivot/Camera3D as Camera3D
	if car == null:
		car = get_tree().get_first_node_in_group("player_car") as RallyCar

	if car != null and spring_arm != null:
		spring_arm.add_excluded_object(car.get_rid())
	_set_view(View.CHASE)

func _unhandled_input(_event: InputEvent) -> void:
	if Input.is_action_just_pressed("camera_next"):
		_set_view((view + 1) % 3)
	elif Input.is_action_just_pressed("camera_prev"):
		_set_view((view + 2) % 3)

func _set_view(next_view: int) -> void:
	view = next_view
	if spring_arm == null:
		return
	if view == View.CHASE:
		spring_arm.collision_mask = 1
		spring_arm.spring_length = chase_distance
	else:
		spring_arm.collision_mask = 0
		spring_arm.spring_length = 0.0

func _physics_process(delta: float) -> void:
	if car == null:
		car = get_tree().get_first_node_in_group("player_car") as RallyCar
	if car == null or spring_arm == null or camera == null:
		return

	if view == View.CHASE:
		_update_chase(delta)
	elif view == View.BONNET:
		_update_fixed(bonnet_offset)
	else:
		_update_fixed(cockpit_offset)

	_update_fov(delta)
	_update_shake(delta)

func _update_chase(delta: float) -> void:
	var speed := car.linear_velocity.length()
	# VehicleBody3D forward is +Z, so the car basis Z axis is the way ahead.
	var forward := car.global_transform.basis.z
	var flat_forward := Vector3(forward.x, 0.0, forward.z).normalized()
	# Positive steering is left, and +X is the model's left side.
	var steer := Input.get_axis("steer_right", "steer_left")

	var pivot := car.global_position + Vector3.UP * chase_height
	var look_target := pivot + flat_forward * (1.0 + speed * 0.03)
	look_target += car.global_transform.basis.x * steer * corner_look

	var desired := Transform3D().looking_at(look_target - pivot, Vector3.UP)
	desired.origin = pivot

	# The spring arm casts along its local +Z, so the camera sits behind.
	global_transform = global_transform.interpolate_with(
		desired, 1.0 - exp(-chase_smooth * delta)
	)

func _update_fixed(offset: Vector3) -> void:
	# The camera looks down its local -Z. Turn the rig around so that -Z
	# points the same way as the car's +Z forward.
	var desired := car.global_transform
	desired.basis = desired.basis.rotated(Vector3.UP, PI)
	desired.origin += car.global_transform.basis * offset
	global_transform = desired

func _update_fov(delta: float) -> void:
	var speed_ratio := clampf(car.linear_velocity.length() / 40.0, 0.0, 1.0)
	var target := lerpf(base_fov, max_fov, speed_ratio)

	if view == View.BONNET:
		target = bonnet_fov + speed_ratio * 8.0
	elif view == View.COCKPIT:
		target = cockpit_fov + speed_ratio * 5.0

	camera.fov = lerpf(camera.fov, target, 1.0 - exp(-fov_smooth * delta))

func add_trauma(amount: float) -> void:
	trauma = clampf(trauma + amount, 0.0, 1.0)

func _update_shake(delta: float) -> void:
	trauma = maxf(trauma - trauma_decay * delta, 0.0)
	var shake := trauma * trauma
	var t := Time.get_ticks_msec() * 0.001

	if shake_pivot == null:
		return

	shake_pivot.position = Vector3(
		_noise.get_noise_2d(t * 18.0, 0.0),
		_noise.get_noise_2d(0.0, t * 18.0),
		0.0
	) * shake_strength * shake

	shake_pivot.rotation = Vector3(
		_noise.get_noise_2d(t * 13.0, 5.0),
		_noise.get_noise_2d(5.0, t * 13.0),
		_noise.get_noise_2d(t * 9.0, 9.0)
	) * deg_to_rad(3.0) * shake

