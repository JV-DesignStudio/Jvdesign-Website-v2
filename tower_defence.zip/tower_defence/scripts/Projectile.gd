extends Node2D

var target:      Node2D = null
var speed:       float  = 280.0
var dmg:         float  = 10.0
var is_slow:     bool   = false
var slow_factor: float  = 0.5
var slow_dur:    float  = 2.0
var _age:        float  = 0.0

@onready var sprite: Sprite2D = $Sprite


func _ready() -> void:
	if is_slow:
		sprite.modulate = Color(0.4, 0.9, 1.0)
		sprite.scale    = Vector2(1.5, 1.5)


func _process(delta: float) -> void:
	_age += delta
	if _age > 3.0:
		queue_free()
		return

	if not is_instance_valid(target):
		queue_free()
		return

	var dir  = (target.global_position - global_position).normalized()
	rotation = dir.angle() + PI/2
	position += dir * speed * delta

	if global_position.distance_to(target.global_position) < 10:
		_hit()


func _hit() -> void:
	if is_instance_valid(target):
		target.take_damage(dmg)
		if is_slow:
			target.apply_slow(slow_factor, slow_dur)
	queue_free()
