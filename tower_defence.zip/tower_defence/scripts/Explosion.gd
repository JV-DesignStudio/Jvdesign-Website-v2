extends Node2D

@onready var sprite: AnimatedSprite2D = $Sprite

func _ready() -> void:
	sprite.play("explode")
	sprite.animation_finished.connect(queue_free)
