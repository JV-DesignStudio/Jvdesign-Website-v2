extends Node2D


@export var tower_type: int = 0
@export var level:      int = 0

const RANGES   = [[120,140,165],[110,130,155],[130,155,180],[160,190,220]]
const DAMAGE   = [[12,18,28],[0,0,0],[20,35,55],[8,14,22]]
const COOLDOWN = [[0.9,0.7,0.5],[1.2,1.0,0.8],[1.8,1.4,1.1],[0.0,0.0,0.0]]
const SLOW_AMT = [0.0, 0.5, 0.4, 0.35]
const SLOW_DUR = [0.0, 2.0, 2.5, 3.0]

var range_px:  float = 120.0
var damage:    float = 12.0
var cooldown:  float = 0.9
var _shoot_t:  float = 0.0
var _target:   Node2D = null
var cell:      Vector2i

@onready var sprite:     Sprite2D = $Sprite
@onready var range_ring: Sprite2D = $RangeRing
@onready var laser_line: Line2D   = $LaserLine


func _ready() -> void:
	_apply_stats()
	range_ring.hide()
	laser_line.hide()
	sprite.region_enabled = true
	sprite.region_rect    = Rect2(tower_type * 48, level * 48, 48, 48)
	_update_range_ring()


func _apply_stats() -> void:
	range_px = RANGES[tower_type][level]
	damage   = DAMAGE[tower_type][level]
	cooldown = COOLDOWN[tower_type][level]


func _update_range_ring() -> void:
	var ring_scale = (range_px * 2.0) / 256.0
	range_ring.scale = Vector2(ring_scale, ring_scale)


func _process(delta: float) -> void:
	_shoot_t = max(0.0, _shoot_t - delta)

	if not is_instance_valid(_target) or _target.global_position.distance_to(global_position) > range_px:
		_target = _find_target()

	if tower_type == 3:
		_process_laser(delta)
	else:
		if _target != null and _shoot_t <= 0:
			_shoot_t = cooldown
			var angle = global_position.angle_to_point(_target.global_position)
			sprite.rotation = angle + PI / 2.0
			match tower_type:
				0: _fire_bullet(_target)
				1: _fire_slow_orb(_target)
				2: _fire_splash(_target.global_position)


func _find_target() -> Node2D:
	var enemies = get_tree().get_nodes_in_group("enemies")
	var best: Node2D = null
	var best_prog: int = -1
	for e in enemies:
		if not is_instance_valid(e):
			continue
		if e.global_position.distance_to(global_position) <= range_px:
			if e.path_idx > best_prog:
				best_prog = e.path_idx
				best = e
	return best


func _process_laser(delta: float) -> void:
	if is_instance_valid(_target):
		laser_line.show()
		laser_line.points = [Vector2.ZERO, to_local(_target.global_position)]
		_target.take_damage(damage * delta)
		sprite.rotation = global_position.angle_to_point(_target.global_position) + PI / 2.0
	else:
		laser_line.hide()


func _fire_bullet(tgt: Node2D) -> void:
	var proj_node = get_tree().get_root().get_node_or_null("Main/Projectiles")
	if proj_node == null:
		return
	var b = preload("res://scenes/Projectile.tscn").instantiate()
	b.target   = tgt
	b.speed    = 280.0
	b.dmg      = damage
	b.is_slow  = false
	proj_node.add_child(b)
	b.global_position = global_position


func _fire_slow_orb(tgt: Node2D) -> void:
	var proj_node = get_tree().get_root().get_node_or_null("Main/Projectiles")
	if proj_node == null:
		return
	var b = preload("res://scenes/Projectile.tscn").instantiate()
	b.target      = tgt
	b.speed       = 200.0
	b.dmg         = 5.0
	b.is_slow     = true
	b.slow_factor = SLOW_AMT[tower_type]
	b.slow_dur    = SLOW_DUR[tower_type]
	proj_node.add_child(b)
	b.global_position = global_position


func _fire_splash(target_pos: Vector2) -> void:
	var radius = 70.0 + level * 20.0
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and e.global_position.distance_to(target_pos) <= radius:
			e.take_damage(damage)
	var effects_node = get_tree().get_root().get_node_or_null("Main/Effects")
	if effects_node != null:
		var expl = preload("res://scenes/Explosion.tscn").instantiate()
		expl.global_position = target_pos
		effects_node.add_child(expl)


func show_range(vis: bool) -> void:
	range_ring.visible = vis


func upgrade() -> bool:
	if level >= 2:
		return false
	level += 1
	_apply_stats()
	sprite.region_rect = Rect2(tower_type * 48, level * 48, 48, 48)
	_update_range_ring()
	return true


func get_sell_value() -> int:
	var base = GameState.TOWER_COSTS[tower_type]
	var upg  = 0
	for l in range(level):
		upg += GameState.UPGRADE_COST[tower_type]
	return int((base + upg) * 0.6)


func get_upgrade_cost() -> int:
	if level >= 2:
		return -1
	return GameState.UPGRADE_COST[tower_type]
