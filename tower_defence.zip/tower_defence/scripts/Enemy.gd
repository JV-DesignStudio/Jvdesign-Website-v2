extends Node2D

signal reached_end
signal died(reward)

# Enemy types: 0=basic, 1=fast, 2=armoured, 3=boss
const CONFIGS = [
	{"hp": 60,  "speed": 80.0,  "reward": 10, "armor": 0.0,  "size": 0},
	{"hp": 30,  "speed": 160.0, "reward": 15, "armor": 0.0,  "size": 1},
	{"hp": 120, "speed": 55.0,  "reward": 25, "armor": 0.4,  "size": 2},
	{"hp": 400, "speed": 40.0,  "reward": 60, "armor": 0.2,  "size": 3},
]

@export var enemy_type: int = 0

var max_hp:     float
var hp:         float
var speed:      float
var reward:     int
var armor:      float   # % damage reduction
var path:       PackedVector2Array
var path_idx:   int    = 0
var slow_timer: float  = 0.0
var slow_factor: float = 1.0
var _frame_t:   float  = 0.0

@onready var sprite:   Sprite2D   = $Sprite
@onready var hp_bar:   ColorRect  = $HPBar/Fill
@onready var hp_bg:    ColorRect  = $HPBar/BG


func _ready() -> void:
	var cfg  = CONFIGS[enemy_type]
	max_hp   = cfg.hp
	hp       = max_hp
	speed    = cfg.speed
	reward   = cfg.reward
	armor    = cfg.armor
	# Set sprite region for this enemy type
	var sw   = 32; var sh = 32
	sprite.region_enabled = true
	sprite.region_rect    = Rect2(0, enemy_type * sh, sw * 4, sh)
	sprite.hframes        = 4
	sprite.frame          = 0
	# Scale boss
	if enemy_type == 3:
		scale = Vector2(1.5, 1.5)


func set_path(p: PackedVector2Array) -> void:
	path     = p
	path_idx = 0
	if path.size() > 0:
		position = path[0]


func _process(delta: float) -> void:
	if path.size() == 0 or path_idx >= path.size():
		return

	# Slow effect
	slow_timer = max(0, slow_timer - delta)
	var effective_speed = speed * (slow_factor if slow_timer > 0 else 1.0)

	# Walk animation
	_frame_t += delta * 8
	sprite.frame = int(_frame_t) % 4

	# Move along path
	var target = path[path_idx]
	var dist   = position.distance_to(target)
	var step   = effective_speed * delta

	if step >= dist:
		position = target
		path_idx += 1
		if path_idx >= path.size():
			reached_end.emit()
			queue_free()
	else:
		var dir = (target - position).normalized()
		position += dir * step
		# Flip sprite
		if dir.x < -0.1:
			sprite.flip_h = true
		elif dir.x > 0.1:
			sprite.flip_h = false

	# Update HP bar
	hp_bar.size.x = max(0, 28 * (hp / max_hp))
	hp_bg.visible  = true


func take_damage(amount: float) -> void:
	var actual = amount * (1.0 - armor)
	hp -= actual
	# Flash red
	modulate = Color(1.5, 0.5, 0.5)
	await get_tree().create_timer(0.08).timeout
	if is_instance_valid(self):
		modulate = Color(1, 1, 1)
	if hp <= 0:
		died.emit(reward)
		queue_free()


func apply_slow(factor: float, duration: float) -> void:
	slow_factor = factor
	slow_timer  = max(slow_timer, duration)
	modulate    = Color(0.7, 0.9, 1.2)
