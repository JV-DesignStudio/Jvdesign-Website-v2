extends Node

signal wave_started(wave_num)
signal wave_complete
signal enemy_spawned(enemy)

# Wave definitions: array of [type, count, interval]
# type: 0=basic,1=fast,2=armoured,3=boss
func get_wave_data(wave: int) -> Array:
	match wave:
		1:  return [[0,8,1.2]]
		2:  return [[0,6,1.0],[1,4,0.8]]
		3:  return [[0,8,0.9],[1,6,0.7]]
		4:  return [[0,6,0.8],[2,4,1.5]]
		5:  return [[0,8,0.7],[1,6,0.6],[3,1,0.0]]
		_:
			# Procedural: scale with wave number
			var data = []
			data.append([0, 4+wave*2, max(0.4, 1.2-wave*0.05)])
			if wave > 3: data.append([1, wave, max(0.35, 0.9-wave*0.04)])
			if wave > 5: data.append([2, wave-3, max(0.5, 1.5-wave*0.06)])
			if wave % 5 == 0: data.append([3, 1+wave/10, 2.0])
			return data

var _spawning:    bool  = false
var _wave_queue:  Array = []
var _spawn_timer: float = 0.0
var _enemies_out: int   = 0
var grid_map:     Node  = null

const EnemyScene = preload("res://scenes/Enemy.tscn")


func start_wave(wave_num: int, gmap: Node) -> void:
	if _spawning:
		return
	grid_map   = gmap
	_spawning  = true
	_enemies_out = 0
	_wave_queue  = []

	# Build flat spawn queue from wave data
	for group in get_wave_data(wave_num):
		var type  = group[0]
		var count = group[1]
		var interval = group[2]
		for i in range(count):
			_wave_queue.append({"type": type, "delay": interval if i > 0 else 0.5})

	wave_started.emit(wave_num)


func _process(delta: float) -> void:
	if not _spawning:
		return
	_spawn_timer -= delta
	if _spawn_timer > 0 or _wave_queue.is_empty():
		return

	var next = _wave_queue.pop_front()
	_spawn_timer = next.delay
	_spawn_enemy(next.type)

	if _wave_queue.is_empty():
		_spawning = false


func _spawn_enemy(type: int) -> void:
	var path = grid_map.get_enemy_path()
	if path.size() == 0:
		return
	var e = EnemyScene.instantiate()
	e.enemy_type = type
	get_tree().get_root().get_node("Main/Enemies").add_child(e)
	e.set_path(path)
	e.add_to_group("enemies")
	e.reached_end.connect(_on_enemy_reached_end.bind(e))
	e.died.connect(_on_enemy_died)
	_enemies_out += 1
	enemy_spawned.emit(e)  # Main.gd also connects its own handlers here


func _on_enemy_reached_end(_e) -> void:
	_enemies_out -= 1
	_check_wave_done()


func _on_enemy_died(_reward: int) -> void:
	_enemies_out -= 1
	_check_wave_done()


func _check_wave_done() -> void:
	if not _spawning and _enemies_out <= 0 and _wave_queue.is_empty():
		wave_complete.emit()


func enemies_remaining() -> int:
	return _enemies_out + _wave_queue.size()
