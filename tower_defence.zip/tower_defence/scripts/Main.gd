extends Node2D

const CELL = 64

@onready var grid_map:     Node2D        = $GridMap
@onready var towers_node:  Node2D        = $Towers
@onready var enemies_node: Node2D        = $Enemies
@onready var proj_node:    Node2D        = $Projectiles
@onready var effects_node: Node2D        = $Effects
@onready var wave_mgr:     Node          = $WaveManager
@onready var tile_map:     Node2D        = $TileVisual
@onready var cursor_rect:  ColorRect     = $CursorHighlight

# HUD
@onready var lbl_gold:     Label = $HUD/GoldLabel
@onready var lbl_lives:    Label = $HUD/LivesLabel
@onready var lbl_wave:     Label = $HUD/WaveLabel
@onready var lbl_score:    Label = $HUD/ScoreLabel
@onready var btn_wave:     Button= $HUD/WaveButton
@onready var msg_label:    Label = $HUD/MsgLabel
@onready var panel_tower:  Panel = $HUD/TowerPanel
@onready var lbl_tname:    Label = $HUD/TowerPanel/NameLabel
@onready var lbl_tlevel:   Label = $HUD/TowerPanel/LevelLabel
@onready var btn_upgrade:  Button= $HUD/TowerPanel/UpgradeBtn
@onready var btn_sell:     Button= $HUD/TowerPanel/SellBtn

const TowerScene = preload("res://scenes/Tower.tscn")

var selected_type:   int     = -1   # which tower type to place (-1 = none)
var selected_tower:  Node2D  = null # clicked existing tower
var _wave_active:    bool    = false
var _game_over:      bool    = false
var _hover_cell:     Vector2i = Vector2i(-1,-1)


func _ready() -> void:
	GameState.gold  = 200
	GameState.lives = 20
	GameState.wave  = 0
	GameState.score = 0

	wave_mgr.wave_started.connect(_on_wave_started)
	wave_mgr.wave_complete.connect(_on_wave_complete)
	grid_map.path_changed.connect(_rebuild_tile_visual)

	btn_wave.pressed.connect(_start_wave)
	btn_upgrade.pressed.connect(_upgrade_selected)
	btn_sell.pressed.connect(_sell_selected)
	panel_tower.hide()

	_rebuild_tile_visual()
	_refresh_hud()
	$HUD/TowerSelectBar/BtnGun.pressed.connect(select_tower_type.bind(0))
	$HUD/TowerSelectBar/BtnSlow.pressed.connect(select_tower_type.bind(1))
	$HUD/TowerSelectBar/BtnSplash.pressed.connect(select_tower_type.bind(2))
	$HUD/TowerSelectBar/BtnLaser.pressed.connect(select_tower_type.bind(3))

	# Connect enemy events via wave manager
	wave_mgr.enemy_spawned.connect(_on_enemy_spawned)

	_show_message("Place towers then press START WAVE!", 3.0)


func _process(_delta: float) -> void:
	if _game_over:
		return
	_update_cursor()


func _input(event: InputEvent) -> void:
	if _game_over:
		return

	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_handle_click(event.position)

	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
		selected_type = -1
		_deselect_tower()

	if _game_over and event is InputEventKey and event.pressed and event.keycode == KEY_R:
		get_tree().reload_current_scene()


# ── Tower type selection (called from HUD buttons) ────────────
func select_tower_type(type: int) -> void:
	selected_type = type
	_deselect_tower()


# ── Click handling ────────────────────────────────────────────
func _handle_click(mouse_pos: Vector2) -> void:
	# Ignore clicks on HUD
	if mouse_pos.y < 64:
		return

	var cell = grid_map.world_to_cell(mouse_pos)
	if not grid_map.is_in_bounds(cell):
		return

	# Click on existing tower — select it
	if grid_map.has_tower(cell):
		_select_tower(grid_map.towers[cell])
		selected_type = -1
		return

	# Place new tower
	if selected_type >= 0:
		var cost = GameState.TOWER_COSTS[selected_type]
		if GameState.gold < cost:
			_show_message("Not enough gold!", 1.5)
			return
		if grid_map.get_cell_type(cell) != 0:  # EMPTY
			return
		if grid_map.place_tower(cell):
			_spawn_tower(cell, selected_type)
			GameState.gold -= cost
			_refresh_hud()
		else:
			_show_message("Can't block the path!", 1.5)
	else:
		_deselect_tower()


func _spawn_tower(cell: Vector2i, type: int) -> void:
	var t = TowerScene.instantiate()
	t.tower_type = type
	t.level      = 0
	t.cell       = cell
	t.position   = grid_map.cell_to_world(cell)
	towers_node.add_child(t)
	grid_map.towers[cell] = t


# ── Tower selection panel ─────────────────────────────────────
func _select_tower(tower: Node2D) -> void:
	if is_instance_valid(selected_tower):
		selected_tower.show_range(false)
	selected_tower = tower
	tower.show_range(true)
	_refresh_tower_panel()
	panel_tower.show()


func _deselect_tower() -> void:
	if is_instance_valid(selected_tower):
		selected_tower.show_range(false)
	selected_tower = null
	panel_tower.hide()


func _refresh_tower_panel() -> void:
	if not is_instance_valid(selected_tower):
		return
	var names  = ["Gun", "Slow", "Splash", "Laser"]
	lbl_tname.text  = names[selected_tower.tower_type] + " Tower"
	lbl_tlevel.text = "Level %d" % (selected_tower.level + 1)
	var upg_cost    = selected_tower.get_upgrade_cost()
	if upg_cost < 0:
		btn_upgrade.text     = "MAX LEVEL"
		btn_upgrade.disabled = true
	else:
		btn_upgrade.text     = "Upgrade ($%d)" % upg_cost
		btn_upgrade.disabled = GameState.gold < upg_cost
	btn_sell.text = "Sell ($%d)" % selected_tower.get_sell_value()


func _upgrade_selected() -> void:
	if not is_instance_valid(selected_tower):
		return
	var cost = selected_tower.get_upgrade_cost()
	if cost < 0 or GameState.gold < cost:
		return
	GameState.gold -= cost
	selected_tower.upgrade()
	_refresh_hud()
	_refresh_tower_panel()


func _sell_selected() -> void:
	if not is_instance_valid(selected_tower):
		return
	GameState.gold += selected_tower.get_sell_value()
	grid_map.remove_tower(selected_tower.cell)
	selected_tower.queue_free()
	_deselect_tower()
	_refresh_hud()


# ── Wave management ───────────────────────────────────────────
func _start_wave() -> void:
	if _wave_active:
		return
	GameState.wave += 1
	_wave_active    = true
	btn_wave.disabled = true
	wave_mgr.start_wave(GameState.wave, grid_map)


func _on_wave_started(num: int) -> void:
	lbl_wave.text = "Wave %d" % num


func _on_wave_complete() -> void:
	_wave_active = false
	btn_wave.disabled = false
	# Bonus gold between waves
	var bonus = 20 + GameState.wave * 5
	GameState.gold += bonus
	_show_message("Wave complete! +$%d bonus" % bonus, 2.5)
	_refresh_hud()


# ── Enemy events ──────────────────────────────────────────────
func _on_enemy_reached_end() -> void:
	GameState.lives -= 1
	_refresh_hud()
	if GameState.lives <= 0:
		_game_over_screen()


func _on_enemy_died(reward: int) -> void:
	GameState.gold  += reward
	GameState.score += reward * 10
	_refresh_hud()


# ── Cursor highlight ──────────────────────────────────────────
func _update_cursor() -> void:
	var mp   = get_viewport().get_mouse_position()
	var cell = grid_map.world_to_cell(mp)
	if cell == _hover_cell:
		return
	_hover_cell = cell
	if grid_map.is_in_bounds(cell) and mp.y >= 64:
		cursor_rect.show()
		cursor_rect.position = grid_map.cell_to_world(cell) - Vector2(32, 32) + Vector2(0, 64)
		var _ctype = grid_map.get_cell_type(cell)
		if selected_type >= 0 and _ctype == 0:
			cursor_rect.color = Color(0.2, 1.0, 0.2, 0.3)
		elif _ctype == 1:
			cursor_rect.color = Color(1.0, 0.8, 0.2, 0.3)
		else:
			cursor_rect.color = Color(1.0, 0.2, 0.2, 0.2)
	else:
		cursor_rect.hide()


# ── Tile visual ───────────────────────────────────────────────
func _rebuild_tile_visual() -> void:
	for child in tile_map.get_children():
		child.queue_free()
	await get_tree().process_frame

	var path_cells = {}
	var raw_path = grid_map.astar.get_id_path(grid_map.START_CELL, grid_map.FINISH_CELL)
	for pt in raw_path:
		path_cells[pt] = true

	for r in range(grid_map.ROWS):
		for c in range(grid_map.COLS):
			var cell = Vector2i(c, r)
			var tile = Sprite2D.new()
			tile.texture        = load("res://sprites/tiles.png")
			tile.region_enabled = true
			tile.centered       = true
			tile.position       = grid_map.cell_to_world(cell)

			var _ctype = grid_map.get_cell_type(cell)
			if cell == grid_map.START_CELL:
				tile.region_rect = Rect2(128, 0, 64, 64)
			elif cell == grid_map.FINISH_CELL:
				tile.region_rect = Rect2(192, 0, 64, 64)
			elif path_cells.has(cell):
				tile.region_rect = Rect2(64, 0, 64, 64)
			else:
				tile.region_rect = Rect2(0, 0, 64, 64)

			tile_map.add_child(tile)


# ── HUD ───────────────────────────────────────────────────────
func _refresh_hud() -> void:
	lbl_gold.text  = "💰 $%d" % GameState.gold
	lbl_lives.text = "❤️ %d"  % GameState.lives
	lbl_wave.text  = "Wave %d" % GameState.wave
	lbl_score.text = "Score: %d" % GameState.score
	if is_instance_valid(selected_tower):
		_refresh_tower_panel()


func _show_message(text: String, duration: float = 0.0) -> void:
	msg_label.text    = text
	msg_label.visible = true
	if duration > 0:
		await get_tree().create_timer(duration).timeout
		if is_instance_valid(msg_label):
			msg_label.visible = false


func _on_enemy_spawned(enemy: Node) -> void:
	enemy.reached_end.connect(_on_enemy_reached_end)
	enemy.died.connect(_on_enemy_died)


func _game_over_screen() -> void:
	_game_over = true
	_show_message("GAME OVER!\nScore: %d\nPress R to restart" % GameState.score)
