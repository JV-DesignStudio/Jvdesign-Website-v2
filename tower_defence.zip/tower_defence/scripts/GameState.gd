extends Node

var gold:  int = 200
var lives: int = 20
var wave:  int = 0
var score: int = 0

# Tower type costs and names
const TOWER_COSTS  = [75, 100, 125, 150]
const TOWER_NAMES  = ["Gun", "Slow", "Splash", "Laser"]
const UPGRADE_COST = [50, 75, 100, 125]   # per tower type per level
