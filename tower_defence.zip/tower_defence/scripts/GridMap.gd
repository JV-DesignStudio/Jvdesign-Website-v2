extends Node2D

# Grid dimensions
const COLS     = 12
const ROWS     = 8
const CELL     = 64   # pixels per cell
const OFFSET   = Vector2(0, 64)   # leave 64px top for HUD

# Cell types
const EMPTY  = 0
const TOWER  = 1
const PATH   = 2   # reserved start→end corridor (can't build here)
const START  = 3
const FINISH = 4

var grid: Array = []          # [row][col] = cell type
var towers: Dictionary = {}   # Vector2i(col,row) → tower node

# Start and end cells (col, row)
const START_CELL  = Vector2i(0, 3)
const FINISH_CELL = Vector2i(11, 4)

# AStar2D for pathfinding
var astar: AStarGrid2D

signal path_changed


func _ready() -> void:
	_init_grid()
	_rebuild_astar()


func _init_grid() -> void:
	grid = []
	for r in range(ROWS):
		var row = []
		for c in range(COLS):
			row.append(EMPTY)
		grid.append(row)
	grid[START_CELL.y][START_CELL.x]    = START
	grid[FINISH_CELL.y][FINISH_CELL.x]  = FINISH


func _rebuild_astar() -> void:
	astar = AStarGrid2D.new()
	astar.region      = Rect2i(0, 0, COLS, ROWS)
	astar.cell_size   = Vector2(1, 1)
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
	astar.update()
	# Mark tower cells as solid
	for r in range(ROWS):
		for c in range(COLS):
			if grid[r][c] == TOWER:
				astar.set_point_solid(Vector2i(c, r), true)


func get_enemy_path() -> PackedVector2Array:
	var raw = astar.get_id_path(START_CELL, FINISH_CELL)
	var result = PackedVector2Array()
	for pt in raw:
		result.append(cell_to_world(pt))
	return result


func cell_to_world(cell: Vector2i) -> Vector2:
	return Vector2(cell.x * CELL + CELL/2, cell.y * CELL + CELL/2) + OFFSET


func world_to_cell(world: Vector2) -> Vector2i:
	var local = world - OFFSET
	return Vector2i(int(local.x / CELL), int(local.y / CELL))


func can_place(cell: Vector2i) -> bool:
	if cell.x < 0 or cell.x >= COLS or cell.y < 0 or cell.y >= ROWS:
		return false
	if grid[cell.y][cell.x] != EMPTY:
		return false
	# Simulate placing and check path still exists
	grid[cell.y][cell.x] = TOWER
	_rebuild_astar()
	var path = astar.get_id_path(START_CELL, FINISH_CELL)
	var ok   = path.size() > 0
	if not ok:
		grid[cell.y][cell.x] = EMPTY
		_rebuild_astar()
	return ok


func place_tower(cell: Vector2i) -> bool:
	if not can_place(cell):
		return false
	grid[cell.y][cell.x] = TOWER
	_rebuild_astar()
	path_changed.emit()
	return true


func remove_tower(cell: Vector2i) -> void:
	grid[cell.y][cell.x] = EMPTY
	towers.erase(cell)
	_rebuild_astar()
	path_changed.emit()


func has_tower(cell: Vector2i) -> bool:
	return towers.has(cell)


func is_in_bounds(cell: Vector2i) -> bool:
	return cell.x >= 0 and cell.x < COLS and cell.y >= 0 and cell.y < ROWS


func get_cell_type(cell: Vector2i) -> int:
	if not is_in_bounds(cell):
		return -1
	return grid[cell.y][cell.x]
