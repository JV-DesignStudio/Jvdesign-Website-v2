# 🏰 Tower Defence – Godot 4 Project

A full tower defence game with pathfinding, 4 tower types, upgrades, multiple enemy types, waves and currency.

---

## 🚀 How to Open

1. Install **Godot 4** → https://godotengine.org
2. Open Godot → **Import** → select `project.godot`
3. Press **F5** to play!

---

## 🎮 How to Play

1. **Select a tower type** from the top bar (🔫 Gun / ❄️ Slow / 💥 AOE / ⚡ Laser)
2. **Left-click** a green grass tile to place it
3. **Right-click** to cancel placement
4. **Click an existing tower** to see upgrade/sell options
5. Press **▶ START WAVE** when ready
6. Survive as many waves as possible!

---

## 🏗️ Tower Types

| Tower | Cost | Description |
|-------|------|-------------|
| 🔫 Gun | $75 | Fast single-target shots |
| ❄️ Slow | $100 | Slows enemies by 50% |
| 💥 AOE Splash | $125 | Mortar - area damage around impact |
| ⚡ Laser | $150 | Continuous beam, ignores armor |

All towers have **3 upgrade levels** — click a tower and press Upgrade!

---

## 👾 Enemy Types

| Enemy | Description |
|-------|-------------|
| 🔴 Basic | Standard — balanced speed and HP |
| 🔵 Fast | Low HP but moves very quickly |
| ⚫ Armoured | High HP with 40% damage reduction |
| 🟣 Boss | Massive HP, appears every 5 waves |

---

## 🗺️ Pathfinding

Enemies use **A* pathfinding** to find the shortest route from the green START tile to the red END tile. They will reroute around towers you place — but you **cannot block all paths**. The game prevents you from placing a tower that would completely block the route.

---

## 📁 Structure

```
tower_defence/
├── project.godot
├── sprites/
│   ├── tiles.png        ← Grass, path, start, end tiles
│   ├── towers.png       ← 4 types × 3 levels
│   ├── enemies.png      ← 4 types × 4 walk frames
│   ├── projectiles.png  ← Bullets, orbs, explosions
│   └── range.png        ← Tower range indicator
└── scripts/
    ├── Main.gd          ← Game loop, input, HUD
    ├── GridMap.gd       ← Grid state + A* pathfinding
    ├── Tower.gd         ← Targeting, shooting, upgrades
    ├── Enemy.gd         ← Path following, health, slow
    ├── WaveManager.gd   ← Wave spawning & progression
    ├── Projectile.gd    ← Homing bullets/orbs
    ├── Explosion.gd     ← AOE visual
    └── GameState.gd     ← Gold, lives, wave (autoload)
```
