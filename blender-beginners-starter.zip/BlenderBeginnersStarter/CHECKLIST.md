# Checklist - Blender Beginners

Compare your screen with the workshop and with `reference/finished-snowman.obj`.
Tick each line when it is true.

## Steps 1-2: Before we start / interface
- [ ] Blender opens and the splash screen is dismissed
- [ ] You can name the 3D Viewport, Outliner and Properties panel
- [ ] You can orbit (middle mouse), pan (Shift+middle mouse) and zoom (wheel)

## Step 3: Edit Mode
- [ ] You entered Edit Mode with Tab and left it again
- [ ] You can point at a vertex, an edge and a face
- [ ] You moved one vertex, extruded a face and tried a loop cut
- [ ] `reference/practice-cube.obj` looks like your starting cube

## Step 4: Building a scene
- [ ] At least three objects, each named in the Outliner
- [ ] One object duplicated rather than built twice

## Step 5: Colours and materials
- [ ] Every object has a material
- [ ] One material is rough, one is smooth, one is metallic

## Steps 6-7: Light and render
- [ ] A light exists and you changed its strength
- [ ] The camera frames the whole scene
- [ ] You rendered once (F12) and saved a PNG

## Step 8: Snowman
- [ ] Body, middle and head are three separate spheres at matching heights
- [ ] Nose, eyes, hat and arms added
- [ ] Compare with `reference/finished-snowman.obj` - import it and orbit both

## Step 9: Modifiers
- [ ] Mirror modifier makes the other half for you
- [ ] Array modifier repeats a shape in a row
- [ ] Subdivision Surface smooths the model
- [ ] You can remove a modifier without breaking the model

## Step 10: Animation
- [ ] Frame range is 1 to 120
- [ ] Two keyframes exist on rotation
- [ ] It plays (space bar) and loops back to frame 1

Finished all of these? Your scene is workshop-complete.
