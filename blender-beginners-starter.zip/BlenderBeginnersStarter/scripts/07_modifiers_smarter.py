# Lesson 9 - Modifiers: Work Smarter
import bpy

obj = bpy.context.view_layer.objects.active
if obj is None or obj.type != "MESH":
    obj = bpy.data.objects.get("Cube")
    bpy.context.view_layer.objects.active = obj

if "Mirror" not in obj.modifiers:
    m = obj.modifiers.new("Mirror", "MIRROR")
    m.use_axis = (True, False, False)

if "Array" not in obj.modifiers:
    a = obj.modifiers.new("Array", "ARRAY")
    a.count = 5
    a.relative_offset_displace = (1.3, 0.0, 0.0)

if "Smooth" not in obj.modifiers:
    s = obj.modifiers.new("Smooth", "SUBSURF")
    s.levels = 2
    s.render_levels = 2

print("Lesson 9 done on", obj.name, "->", [m.name for m in obj.modifiers])
