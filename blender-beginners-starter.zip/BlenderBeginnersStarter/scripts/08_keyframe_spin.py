# Lesson 10 - Bring It to Life: Simple Animation
import bpy

scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end = 120

obj = bpy.data.objects.get("Snowman_Head") or bpy.data.objects.get("Cube")
if obj is None:
    raise SystemExit("Nothing to animate yet - run 06_snowman_builder.py first.")

scene.frame_set(1)
obj.rotation_euler = (0.0, 0.0, 0.0)
obj.keyframe_insert(data_path="rotation_euler", frame=1)

scene.frame_set(120)
obj.rotation_euler = (0.0, 0.0, 6.283185)
obj.keyframe_insert(data_path="rotation_euler", frame=120)

if obj.animation_data and obj.animation_data.action:
    for fc in obj.animation_data.action.fcurves:
        for kp in fc.keyframe_points:
            kp.interpolation = "LINEAR"

scene.frame_set(1)
print("Lesson 10 done: one full spin on", obj.name, "over 120 frames. Press the space bar to play.")
