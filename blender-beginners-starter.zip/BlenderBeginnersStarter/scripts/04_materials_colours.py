# Lesson 5 - Colours & Materials
import bpy

def make_material(name, colour, roughness=0.5, metallic=0.0):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    bsdf = next((n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf:
        bsdf.inputs["Base Color"].default_value = colour
        bsdf.inputs["Roughness"].default_value = roughness
        bsdf.inputs["Metallic"].default_value = metallic
    return mat

def paint(obj_name, mat):
    obj = bpy.data.objects.get(obj_name)
    if obj is None or obj.type != "MESH":
        print("  skipped (no mesh):", obj_name)
        return
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    print("  painted:", obj_name, "->", mat.name)

paint("Cube", make_material("Sunny Yellow", (1.0, 0.8, 0.1, 1.0), roughness=0.4))
paint("Prop_1", make_material("Toy Red", (0.85, 0.12, 0.12, 1.0), roughness=0.55))
paint("Prop_2", make_material("Shiny Metal", (0.8, 0.82, 0.85, 1.0), roughness=0.25, metallic=1.0))
print("Lesson 5 done: yellow, red and metal materials assigned.")
