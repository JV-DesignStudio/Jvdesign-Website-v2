# Lesson 8 - Build Your First Model: A Snowman!
import bpy

def simple_material(name, colour, rough=0.7):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
        mat.use_nodes = True
        bsdf = next((n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
        if bsdf:
            bsdf.inputs["Base Color"].default_value = colour
            bsdf.inputs["Roughness"].default_value = rough
    return mat

def sphere(name, radius, z, mat):
    if bpy.data.objects.get(name):
        print("  already there:", name)
        return bpy.data.objects[name]
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=16,
                                         radius=radius, location=(0, 0, z))
    obj = bpy.context.object
    obj.name = name
    bpy.ops.object.shade_smooth()
    obj.data.materials.append(mat)
    print("  added:", name)
    return obj

snow = simple_material("Snow", (0.97, 0.98, 1.0, 1.0), rough=0.85)
carrot = simple_material("Carrot", (1.0, 0.45, 0.05, 1.0), rough=0.6)

sphere("Snowman_Body", 1.0, 1.0, snow)
sphere("Snowman_Middle", 0.78, 2.35, snow)
sphere("Snowman_Head", 0.58, 3.35, snow)

if not bpy.data.objects.get("Snowman_Nose"):
    bpy.ops.mesh.primitive_cone_add(radius1=0.12, depth=0.55,
                                    location=(0, -0.75, 3.35),
                                    rotation=(1.5708, 0, 0))
    nose = bpy.context.object
    nose.name = "Snowman_Nose"
    nose.data.materials.append(carrot)
    print("  added: Snowman_Nose")

print("Lesson 8 done: body, middle, head and carrot nose. Eyes, hat and arms are yours.")
