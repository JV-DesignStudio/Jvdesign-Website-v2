# Lesson 4 - Building a Scene
import bpy

def get(name):
    return bpy.data.objects.get(name)

if not get("Ground"):
    bpy.ops.mesh.primitive_plane_add(size=10, location=(0, 0, 0))
    bpy.context.object.name = "Ground"

if not get("Prop_1"):
    bpy.ops.mesh.primitive_cube_add(size=1.4, location=(2.4, 0, 0.7))
    bpy.context.object.name = "Prop_1"

if not get("Prop_2"):
    src = get("Prop_1")
    dup = src.copy()
    dup.data = src.data.copy()
    dup.name = "Prop_2"
    dup.location = (-2.4, 0, 0.7)
    bpy.context.collection.objects.link(dup)

print("Lesson 4 done:", [o.name for o in bpy.data.objects])
