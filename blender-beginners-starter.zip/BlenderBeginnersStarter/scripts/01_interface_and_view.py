# Lesson 1 + 2 - Before We Start / The Blender Interface
# Scripting tab > New > paste > Run Script (Alt+P). Nothing is deleted.
import bpy

scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end = 120

print("Scene:", scene.name)
for obj in bpy.data.objects:
    print("  object:", obj.name, "| type:", obj.type, "| location:",
          tuple(round(v, 2) for v in obj.location))

cube = bpy.data.objects.get("Cube")
if cube:
    bpy.context.view_layer.objects.active = cube
    cube.select_set(True)

print("Lesson 1/2 done: frame range 1-120, every object listed above.")
