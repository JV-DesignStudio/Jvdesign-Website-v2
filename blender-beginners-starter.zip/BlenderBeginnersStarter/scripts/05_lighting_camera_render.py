# Lesson 6 + 7 - Lighting Up Your Scene / Your First Render
import bpy
from math import radians

if not bpy.data.objects.get("Key_Light"):
    bpy.ops.object.light_add(type="SUN", location=(4, -4, 6))
    light = bpy.context.object
    light.name = "Key_Light"
    light.data.energy = 3.0
    light.rotation_euler = (radians(50), 0, radians(35))

scene = bpy.context.scene
cam = bpy.data.objects.get("Camera")
if cam is None:
    bpy.ops.object.camera_add(location=(7, -7, 5))
    cam = bpy.context.object
    cam.name = "Camera"
scene.camera = cam
cam.rotation_euler = (radians(63), 0, radians(45))

chosen = None
for engine in ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE", "CYCLES"):
    try:
        scene.render.engine = engine
        chosen = engine
        break
    except TypeError:
        continue

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080
scene.render.filepath = "//render-lesson.png"

print("Lesson 6/7 done: sun light + camera set, render engine:", chosen)
print("Press F12 for the render window, then Image > Save As to keep it.")
