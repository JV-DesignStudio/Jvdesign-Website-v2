# Lesson 3 - Edit Mode: Change the Shape
import bpy
import bmesh

obj = bpy.context.view_layer.objects.active
if obj is None or obj.type != "MESH":
    obj = bpy.data.objects.get("Cube")
    bpy.context.view_layer.objects.active = obj

bpy.ops.object.mode_set(mode="EDIT")
bm = bmesh.from_edit_mesh(obj.data)
bm.faces.ensure_lookup_table()

# poke the middle face (like pulling a point out of the surface)
bmesh.ops.poke(bm, faces=[bm.faces[len(bm.faces) // 2]])
# one round of subdivision, so there are more vertices to play with
bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
bm.faces.ensure_lookup_table()
bm.verts.ensure_lookup_table()

# lift the newest middle vertex, the same move the lesson does by hand
for v in bm.verts:
    if v.co.z > 0.99 and abs(v.co.x) < 0.01 and abs(v.co.y) < 0.01:
        v.co.z += 0.35

bmesh.update_edit_mesh(obj.data)
bpy.ops.object.mode_set(mode="OBJECT")
print("Lesson 3 done: cube poked, subdivided and one vertex moved up.")
