# Blender Beginners - Starter Template

Free companion files for the **Blender Beginners** workshop:
https://jvdesignstudio.co.uk/workshops/blender-workshop.html

You need Blender 4.0 or newer (free, no account). These files are plain text,
so they open on a locked-down school computer, a tablet or your own laptop.
Nothing here phones home and nothing is installed by the zip itself.

## What is inside

```
BlenderBeginnersStarter/
  README.md                       this file
  CHECKLIST.md                    tick off each workshop step against your work
  reference/
    finished-snowman.obj          the finished snowman (step 8), fully built
    finished-snowman.mtl          its colours
    practice-cube.obj             one clean cube to practise Edit Mode on (step 3)
    practice-cube.mtl
  scripts/
    01_interface_and_view.py      steps 1-2   name things, set the frame range
    02_edit_mode_shapes.py        step 3      poke and subdivide the cube
    03_building_a_scene.py        step 4      ground, props, a duplicate
    04_materials_colours.py       step 5      colour, roughness, metal
    05_lighting_camera_render.py  steps 6-7   sun light, camera, render settings
    06_snowman_builder.py         step 8      build the snowman in code
    07_modifiers_smarter.py       step 9      mirror, array, subdivision
    08_keyframe_spin.py           step 10     keyframe a full spin
```

## Open the reference model (compare your own work against it)

1. Unzip this folder somewhere you can find it (Downloads is fine).
2. In Blender: **File > Import > Wavefront (.obj)**.
3. Choose `reference/finished-snowman.obj` and press **Import OBJ**.
4. Orbit around it, then build your own snowman next to it and compare.

The finished model sits in the same world coordinates the workshop uses
(body at z=1, head at z=3.35), so you can check your heights as you go.

## Run a lesson script

1. Open Blender and switch to the **Scripting** tab along the top.
2. Press **New**, paste in one of the `scripts/` files, then **Run Script**
   (Alt+P with the mouse over the text editor).
3. Undo with Ctrl+Z if you do not like what it did.

Scripts are numbered in workshop order. They only add to your scene, they never
delete your work, and each one prints `Lesson N done:` in the console so you
know it ran.

## School computer notes

- Blender itself is a free download and runs offline once installed.
- The zip contains no installers and no account sign-in.
- Everything stays on the machine: renders are written next to your .blend file.

Stuck? Each script has short comments naming the workshop step it belongs to.
