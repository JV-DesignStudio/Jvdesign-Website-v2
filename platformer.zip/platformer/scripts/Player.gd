extends CharacterBody2D

# ── Tunable values (edit in the Inspector!) ──────────────────
@export var speed:       float = 180.0
@export var jump_force:  float = 420.0
@export var gravity:     float = 980.0

@onready var sprite: AnimatedSprite2D = $Sprite


func _ready() -> void:
	add_to_group("player")


func _physics_process(delta: float) -> void:
	var on_floor := is_on_floor()

	# Gravity — only applied when airborne
	if not on_floor:
		velocity.y += gravity * delta

	# ── Horizontal movement ───────────────────────────────────
	# Explicit key checks so it works without custom InputMap setup
	var dir := 0.0
	if Input.is_key_pressed(KEY_LEFT)  or Input.is_key_pressed(KEY_A):
		dir = -1.0
	if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		dir = 1.0
	velocity.x = dir * speed

	# ── Jump ─────────────────────────────────────────────────
	if on_floor and (
		Input.is_key_pressed(KEY_SPACE) or
		Input.is_key_pressed(KEY_UP)    or
		Input.is_key_pressed(KEY_W)
	):
		velocity.y = -jump_force

	move_and_slide()

	# ── Animation ─────────────────────────────────────────────
	if not is_on_floor() and velocity.y < 0:
		_play("jump")
	elif dir != 0:
		_play("walk")
		sprite.flip_h = dir < 0
	else:
		_play("idle")


func _play(anim: String) -> void:
	if sprite.animation != anim:
		sprite.play(anim)


func die() -> void:
	get_tree().get_root().get_node("Main").player_died()


func _process(_delta: float) -> void:
	# Fall off screen = death
	if position.y > 600:
		die()
