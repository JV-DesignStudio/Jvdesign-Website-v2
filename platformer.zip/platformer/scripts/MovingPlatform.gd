extends AnimatableBody2D

@export var move_distance: float = 120.0
@export var speed:         float = 60.0
@export var vertical:      bool  = false   # false = horizontal, true = vertical

var _start: Vector2
var _dir:   float = 1.0


func _ready() -> void:
	_start = position


func _physics_process(delta: float) -> void:
	var offset := _dir * speed * delta
	if vertical:
		position.y += offset
		var dist := position.y - _start.y
		if dist > move_distance or dist < 0:
			_dir *= -1
	else:
		position.x += offset
		var dist := position.x - _start.x
		if dist > move_distance or dist < 0:
			_dir *= -1
