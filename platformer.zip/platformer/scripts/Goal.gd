extends Area2D

signal reached

@onready var sprite: AnimatedSprite2D = $Sprite


func _ready() -> void:
	sprite.play("wave")
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		reached.emit()
