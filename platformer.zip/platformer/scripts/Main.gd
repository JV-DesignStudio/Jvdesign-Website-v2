extends Node2D

var coin_count := 0

@onready var coin_label:  Label  = $HUD/CoinLabel
@onready var msg_label:   Label  = $HUD/MsgLabel
@onready var player_node: CharacterBody2D = $Player


func _ready() -> void:
	# Connect all coins
	for coin in get_tree().get_nodes_in_group("coin"):
		coin.collected.connect(_on_coin_collected)

	# Connect goal
	$Goal.reached.connect(_on_goal_reached)

	_refresh_hud()


func _on_coin_collected() -> void:
	coin_count += 1
	_refresh_hud()


func _on_goal_reached() -> void:
	_show_message("🎉 You Win!  Press R to restart")


func _refresh_hud() -> void:
	coin_label.text = "Coins: %d" % coin_count


func _show_message(text: String) -> void:
	msg_label.text = text
	msg_label.visible = true
	get_tree().paused = true


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):   # Esc = quit
		get_tree().quit()
	if Input.is_key_pressed(KEY_R):
		get_tree().paused = false
		get_tree().reload_current_scene()


# Called by Player when it dies (falls off / touches enemy)
func player_died() -> void:
	_show_message("💀 You died!  Press R to restart")
