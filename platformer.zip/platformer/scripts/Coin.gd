extends Area2D

signal collected

@onready var sprite: AnimatedSprite2D = $Sprite


func _ready() -> void:
	add_to_group("coin")
	sprite.play("spin")
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		collected.emit()
		queue_free()
