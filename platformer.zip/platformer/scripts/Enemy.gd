extends CharacterBody2D

@export var patrol_distance: float = 120.0
@export var speed:           float = 80.0

var _start_x: float
var _dir:     float = 1.0

@onready var sprite: AnimatedSprite2D = $Sprite


func _ready() -> void:
	_start_x = global_position.x
	sprite.play("walk")


func _physics_process(delta: float) -> void:
	velocity.y += 980 * delta   # gravity
	velocity.x  = _dir * speed
	move_and_slide()

	# Flip at patrol edges
	var dist := global_position.x - _start_x
	if dist > patrol_distance or dist < 0:
		_dir *= -1
		sprite.flip_h = (_dir < 0)

	# Kill player on touch
	for i in get_slide_collision_count():
		var col := get_slide_collision(i)
		if col.get_collider() and col.get_collider().is_in_group("player"):
			col.get_collider().die()
