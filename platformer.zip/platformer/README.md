# 🎮 Mini Platformer – Godot 4 Starter Project

A complete beginner-friendly 2D platformer with animated sprites, coins, enemies, moving platforms, and a goal flag.

---

## 🚀 How to Open

1. Install **Godot 4** → https://godotengine.org (free)
2. Open Godot → **Import** → select `project.godot` in this folder
3. Click **Import & Edit**
4. Press **F5** to play!

---

## 🎮 Controls

| Key | Action |
|-----|--------|
| `←` `→` or `A` `D` | Move left / right |
| `Space` or `↑` | Jump |
| `R` | Restart |
| `Esc` | Quit |

---

## 📁 Project Structure

```
platformer/
├── project.godot           ← Open this in Godot
├── sprites/
│   ├── char_walk.png       ← 8-frame walk cycle
│   ├── char_idle.png       ← 2-frame idle
│   ├── char_jump.png       ← 1-frame jump pose
│   ├── coin.png            ← 8-frame spinning coin
│   ├── enemy.png           ← 6-frame enemy walk
│   └── flag.png            ← 2-frame waving flag
├── scenes/
│   └── Main.tscn           ← The game world
└── scripts/
    ├── Main.gd             ← Game manager (HUD, win/lose)
    ├── Player.gd           ← Player movement & animation
    ├── Enemy.gd            ← Enemy patrol & player kill
    ├── MovingPlatform.gd   ← Horizontal/vertical moving platforms
    ├── Coin.gd             ← Collectible coin
    └── Goal.gd             ← Win condition flag
```

---

## 🧠 How It Works

### Player (`CharacterBody2D`)
Uses Godot's built-in `move_and_slide()` with gravity applied manually each frame. Animation switches between `idle`, `walk`, and `jump` based on velocity and floor state.

### Enemies (`CharacterBody2D`)
Patrol back and forth between two points. On touching the player, they call `player.die()`.

### Moving Platforms (`AnimatableBody2D`)
Move along one axis between a start and end point, reversing direction when they reach the limit. Players ride them automatically thanks to `move_and_slide()`.

### Coins (`Area2D`)
Detect overlap with the player via `body_entered` signal. On collection they emit a `collected` signal to Main and remove themselves.

### Goal Flag (`Area2D`)
Same as coins — emits `reached` signal on player contact, triggering the win screen.

---

## 🛠️ Things to Try

- **Adjust jump height**: Select Player node → Inspector → `jump_force`
- **Change enemy patrol range**: Select Enemy → Inspector → `patrol_distance`
- **Make a platform vertical**: Select a MovPlat node → Inspector → check `vertical`
- **Add more platforms**: Duplicate a platform node in the scene tree and reposition it
- **Swap art**: Replace any PNG in `sprites/` with your own (keep the same frame sizes)
