# Phone Stand Builder - Starter Template

Free companion files for the **Phone Stand Builder** workshop:
https://jvdesignstudio.co.uk/workshops/phone-stand-builder.html

You need nothing but a browser. The starter is three ready-made stand designs
plus this guide, so you can open one, see how it is set up, then change it.

## What is inside

```
PhoneStandStarter/
  README.md                      this file
  CHECKLIST.md                   tick off each of the 11 builder steps
  designs/
    01-beginner-angled.json      step-by-step friendly angled stand
    02-cable-cradle.json         cradle style with a cable slot and grip dots
    03-showcase-foldable.json    foldable stand with a brand label
```

Each JSON file is one stand. Every setting in it maps to a control in the
builder, so you can read a value and see it on the model.

## How to open a design (2 ways)

**Way 1 - import it (no typing):**
1. Download and unzip this folder.
2. Open the Phone Stand Builder workshop page.
3. Press **⬆ Import** in the top bar and pick one of the JSON files.
4. The stand rebuilds straight away. Press **💾 Save** to keep it in this
   browser, or just keep changing it.

**Way 2 - read it beside you:**
1. Open a JSON file in any text editor.
2. Match each line to a control: `angle` is Viewing Angle, `cableSlot` is
   Cable Slot, `color` is Colour, and so on.
3. Type the same numbers into the builder and check your model looks the same.

## Which file matches which step

| File | Best for practising |
|---|---|
| 01-beginner-angled.json | steps 1-6: name, style, phone size, dimensions, angle, base |
| 02-cable-cradle.json | steps 7-9: phone lip, cable slot, grip texture |
| 03-showcase-foldable.json | steps 10-14: colour, rounded corners, brand label, stats, export |

The builder sidebar runs 14 steps, so the checklist covers every one of them.

## Recover from mistakes

- Press **📂 Load** to bring a saved stand back.
- Import the starter JSON again to return to the original settings.
- Nothing is ever deleted: the builder only changes what is on screen.

## School computer notes

- No install, no account, no upload: the files stay on the machine.
- The workshop page runs offline once loaded (it uses a local copy of the 3D
  library), so the import button works on a locked-down computer.
- Export **STL** if you ever want to 3D print your stand, or **PNG** to show
  someone what you made.
