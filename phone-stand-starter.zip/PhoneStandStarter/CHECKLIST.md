# Checklist - Phone Stand Builder

Tick a line when the control matches the starter design or your own stand.
There are 14 steps in the builder sidebar.

## Steps 1-5: shape and size
- [ ] Your stand has a name you chose (step 1)
- [ ] Stand Style picked and you can say why (step 2)
- [ ] Phone Width and Phone Thickness match your phone (step 3)
- [ ] Stand Width, Depth and Height look right in the preview (step 4)
- [ ] Viewing Angle set and the screen faces you (step 5)

## Steps 6-8: the details that hold the phone
- [ ] Base Thickness is thick enough to sit flat (step 6)
- [ ] Phone Lip high enough to grip, not hide the screen (step 7)
- [ ] Cable Slot on with a slot width that fits a cable (step 8)

## Steps 9-11: finish the look
- [ ] Grip Texture chosen (ridges, dots or smooth) (step 9)
- [ ] Colour chosen, and it is not the random one you forgot (step 10)
- [ ] Rounded Corners on with a radius you like (step 11)

## Steps 12-14: show it off
- [ ] Brand Text added or deliberately left empty (step 12)
- [ ] Stats and Preview checked: dimensions and angle read correctly (step 13)
- [ ] Export STL done, or PNG saved if you are not printing (step 14)

## Using the starter
- [ ] Imported at least one starter design and watched it rebuild
- [ ] Changed one value from the starter and can point at the difference
- [ ] Saved your own version with Save
- [ ] Exported a PNG of the finished stand

Done? Your stand is ready to show, print or improve.
