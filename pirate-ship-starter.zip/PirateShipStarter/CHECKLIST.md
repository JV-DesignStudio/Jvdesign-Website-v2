# Checklist - Pirate Ship Shipyard (22 steps)

Tick a step when its slider is set and the ship looks the way you want.

## Name and hull (steps 1-4)
- [ ] 1 Name Your Ship
- [ ] 2 Hull Shape: length, beam and depth set
- [ ] 3 Hull Curvature: bow sharpness, stern width and keel depth set
- [ ] 4 Main Deck thickness set

## Bow and stern (steps 5-7)
- [ ] 5 Bowsprit: length, thickness and angle set
- [ ] 6 Stern Castle: height and length set
- [ ] 7 Forecastle: height and length set

## Masts and sails (steps 8-12)
- [ ] 8 Main Mast: height, thickness and position set
- [ ] 9 Fore Mast: height, thickness and position set
- [ ] 10 Mizzen Mast: height, thickness and position set
- [ ] 11 Sails: width, billow and count per mast set
- [ ] 12 Crow's Nest: radius, height and position set

## Deck detail (steps 13-18)
- [ ] 13 Railings and Gunwale: height and post count set
- [ ] 14 Cannon Ports: cannon count and size set
- [ ] 15 Rudder: width and height set
- [ ] 16 Anchor scale set
- [ ] 17 Figurehead: toggle and size set
- [ ] 18 Flags and Jolly Roger: toggle, width and height set

## Finish and launch (steps 19-21)
- [ ] 19 Stern Windows: count and size set
- [ ] 20 Colors and Materials: hull, deck, sails, masts, metal, flags, trim and water set
- [ ] 21 Final Details: ropes and lanterns toggled
- [ ] 22 Set Sail: launched and exported

## Using the starter pack
- [ ] Loaded the reference ship from the title bar
- [ ] Compared at least eight of your sliders with parameters.json
- [ ] Saved your ship to a name and loaded it back
- [ ] Exported your ship as OBJ or GLB
- [ ] Printed or saved your profile card
