# Pirate Ship Shipyard - Starter Template

Free companion files for the **Pirate Ship Shipyard** workshop:
https://jvdesignstudio.co.uk/workshops/pirate-ship-builder.html

Nothing to install. Download the pack from the workshop (**📦 Starter Template**
in the title bar) and keep the files open beside the basic ship while you work.

## What is inside

```
PirateShipStarter/
  README.md                       this file
  CHECKLIST.md                    all 22 steps, ticked off in order
  reference/
    parameters.json               every slider with its range and a starting value
    reference-ship.json           a finished basic ship
```

## The basic basic ship

`reference/reference-ship.json` is one complete, working basic ship: every value filled in.
To use it, open the file and copy each value into the matching control, in order:

1. Download the pack (**📦 Starter Template**).
2. Open `reference/parameters.json` or `reference/reference-ship.json` in any text editor.
3. Work down the 22 steps. For each control, type the value into the basic shipyard.
4. Press **Save** so you have a copy you can reload later.

## The 22 values, in step order

- Name: Raven's Bane
- Hull: 16 m long, 5 m beam, 3.6 m deep
- Hull curve: bow sharpness 1.1, stern width 0.45, keel depth 1.1
- Deck: 0.25 thick
- Bowsprit: 5.5 m long, 0.12 thick, 32 degree angle
- Stern castle: 2.6 m high, 4 m long
- Forecastle: 1.6 m high, 3 m long
- Main mast: 13 m tall, 0.16 thick, position 0.02
- Fore mast: 10.5 m tall, 0.13 thick, position 0.32
- Mizzen mast: 9 m tall, 0.11 thick, position -0.34
- Sails: width 1.25, billow 0.75, 3 per mast
- Crow's nest: radius 0.6, height 0.4, at 0.8 of the mast
- Railings: 0.55 high, 18 posts
- Cannons: 8 per side, 0.085 size
- Rudder: 1.3 wide, 2.6 high
- Anchor: scale 1.0
- Figurehead: on, size 0.9
- Flags: Jolly Roger on, 2.2 wide, 1.4 high
- Stern windows: 5 windows, 0.32 size
- Colours: hull #2b1410, deck #9a6b32, sails #f0e6d2, masts #5c3d21, metal
  #c9a227, flags #111111, trim #e0b545, water #0d3a6b
- Details: rigging ropes on, lanterns on

## Why those values

`parameters.json` lists every control with the range the workshop allows, so you
can see where a slider is allowed to go. The starting values sit comfortably
inside every range, which makes them a safe first build to copy and then change.

## Recover from a bad experiment

- **Save** stores the ship in this browser under a name you choose, **Load** brings it back, and each saved ship can be deleted from the same list.
- **🎲 Random** rolls a whole new ship if you want a surprise starting point.
- The shipyard never uploads anything, so this all works on a locked down school computer.

## Take your ship further

- **⬇ OBJ** and **📦 GLB** download a real 3D model of whatever you built. Both
  open in Blender, and GLB also opens in Windows 3D Viewer and most game engines.
- **🖼️ PNG** saves a picture of your ship for a project write up.
- **💳 Card** makes a profile card you can show or print.

## School computer notes

- No install, no account, no upload: files stay on the machine.
- The sliders are plain HTML, so a mouse or a trackpad is the only input needed.
- Text files open in Notepad, TextEdit or any code editor.
